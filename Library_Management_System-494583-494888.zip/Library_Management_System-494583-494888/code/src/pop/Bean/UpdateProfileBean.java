package pop.Bean;

public class UpdateProfileBean {
	private String uname;
	private String aname;
	private String aemail;
	private String aphnum;
	public UpdateProfileBean(String uname,String aname, String aemail, String aphnum,
			String desig, String mem) {
		super();
		this.uname=uname;
		this.aname = aname;
		this.aemail = aemail;
		this.aphnum = aphnum;
	}
	public UpdateProfileBean() {
		// TODO Auto-generated constructor stub
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getAemail() {
		return aemail;
	}
	public void setAemail(String aemail) {
		this.aemail = aemail;
	}
	public String getAphnum() {
		return aphnum;
	}
	public void setAphnum(String aphnum) {
		this.aphnum = aphnum;
	}

	
}
