package pop.Bean;

public class RegisterBean {
private String name;
private String username;
private String pass;
private String mail;
private String contact;
private String Designation;
public RegisterBean(String name, String username, String pass,
		String mail, String contact)
{
	super();
	this.name = name;
	this.username = username;
	this.pass = pass;
	this.mail = mail;
	this.contact = contact;
}
public String getDesignation() {
	return Designation;
}
public void setDesignation(String designation) {
	Designation = designation;
}
public RegisterBean() {
	// TODO Auto-generated constructor stub
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
public String getMail() {
	return mail;
}
public void setMail(String mail) {
	this.mail = mail;
}
public String getContact() {
	return contact;
}
public void setContact(String contact) {
	this.contact = contact;
}

}
