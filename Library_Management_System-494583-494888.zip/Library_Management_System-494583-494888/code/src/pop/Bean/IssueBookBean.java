package pop.Bean;

import java.util.Date;

public class IssueBookBean {
private String isbn;
private String username;
private Date issuedate;
private Date returndate;

public IssueBookBean(){
	
}

public IssueBookBean(String isbn, String username, Date issueDate,
		Date returndate) {
	super();
	this.isbn = isbn;
	this.username = username;
	this.issuedate = issueDate;
	this.returndate = returndate;
}

public String getIsbn() {
	return isbn;
}

public void setIsbn(String isbn) {
	this.isbn = isbn;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public Date getIssueDate() {
	return issuedate;
}

public void setIssueDate(Date issueDate) {
	this.issuedate = issueDate;
}

public Date getReturndate() {
	return returndate;
}

public void setReturndate(Date returndate) {
	this.returndate = returndate;
}

}
