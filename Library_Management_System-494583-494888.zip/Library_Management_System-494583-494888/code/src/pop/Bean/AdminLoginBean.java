package pop.Bean;

public class AdminLoginBean {
	private String uname;
	private String pwd;

	
public AdminLoginBean(String uname, String pwd) {
		
		this.uname = uname;
		this.pwd = pwd;
		
	}
	
	public AdminLoginBean() {
	// TODO Auto-generated constructor stub
}

	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

}
