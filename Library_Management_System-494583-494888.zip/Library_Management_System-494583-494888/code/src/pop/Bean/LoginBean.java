package pop.Bean;

public class LoginBean {
private String uname;
private String pwd;

public LoginBean(String uname, String pwd) {
	super();
	this.uname = uname;
	this.pwd = pwd;
	
}
public LoginBean() {
	// TODO Auto-generated constructor stub
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}


}
