package pop.Bean;

public class ChangePasswordBean {
private String username;
private String oldpassword;
private String newpassword;
public ChangePasswordBean(String username,String oldpassword, String newpassword) {
	super();
	this.username=username;
	this.oldpassword = oldpassword;
	this.newpassword = newpassword;
}

public ChangePasswordBean() {
	// TODO Auto-generated constructor stub
}

public String getOldpassword() {
	return oldpassword;
}
public void setOldpassword(String oldpassword) {
	this.oldpassword = oldpassword;
}
public String getNewpassword() {
	return newpassword;
}
public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public void setNewpassword(String newpassword) {
	this.newpassword = newpassword;
}
}
