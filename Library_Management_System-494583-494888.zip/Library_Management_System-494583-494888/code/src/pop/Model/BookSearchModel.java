package pop.Model;

import java.util.List;
import pop.DAO.BookSearchDAO;
import pop.Bean.BookBean;

public class BookSearchModel {

public List<BookBean> searchBook(BookBean bb,String bookname)
	
	{
	System.out.println("service "+bookname);
		BookSearchDAO bsd=new BookSearchDAO();
		List<BookBean> li = bsd.searchBook(bb,bookname);
		return li;
	}
}
