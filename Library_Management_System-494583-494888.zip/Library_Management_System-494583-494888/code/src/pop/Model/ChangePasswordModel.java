package pop.Model;

import pop.Bean.ChangePasswordBean;
import pop.DAO.ChangePasswordDAO;

public class ChangePasswordModel {
	public boolean changepassword(ChangePasswordBean cpb){
		ChangePasswordDAO cpd=new ChangePasswordDAO();
		return cpd.changepassword(cpb);
}
}
