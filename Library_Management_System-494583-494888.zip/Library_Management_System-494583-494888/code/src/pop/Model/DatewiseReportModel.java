package pop.Model;

import java.util.*;

import pop.Bean.IssueBookBean;
import pop.DAO.DatewiseReportDAO;


public class DatewiseReportModel {
	public List<IssueBookBean> issueReport(String date,String month){
		DatewiseReportDAO drd=new DatewiseReportDAO();
		return drd.issueReport(date,month);
	}
}
