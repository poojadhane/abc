package pop.Model;

import pop.Bean.RegisterBean;
import pop.DAO.RegisterDAO;
public class RegisterModel {
	public boolean addUser(RegisterBean rb)
	{
		RegisterDAO rd=new RegisterDAO();
		return rd.addUser(rb);
	}
}
