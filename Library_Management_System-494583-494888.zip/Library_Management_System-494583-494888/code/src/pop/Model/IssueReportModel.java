package pop.Model;

import java.util.List;

import pop.Bean.IssueBookBean;
import pop.DAO.IssueReportDAO;

public class IssueReportModel {

	public List<IssueBookBean> viewReport(String username) {
		IssueReportDAO ird=new IssueReportDAO();
		List<IssueBookBean> issuedbooklist=ird.viewReport(username);
		return issuedbooklist;
	}


}