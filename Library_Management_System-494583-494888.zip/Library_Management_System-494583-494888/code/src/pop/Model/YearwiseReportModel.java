package pop.Model;

import java.util.List;

import pop.Bean.IssueBookBean;
import pop.DAO.YearwiseReportDAO;

public class YearwiseReportModel {
	public List<IssueBookBean> issueReport(String year){
		YearwiseReportDAO yrd=new YearwiseReportDAO();
		return yrd.issueReport(year);
	}
}
