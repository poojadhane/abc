package pop.Model;

import pop.Bean.AddBookBean;
import pop.DAO.AddBookDAO;

public class AddBookModel {
	public boolean AddBook(AddBookBean abb){
		AddBookDAO ad=new AddBookDAO();
		return ad.AddBook(abb);
	}

}
