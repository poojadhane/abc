package pop.Model;

import pop.Bean.IssueBookBean;
import pop.DAO.BookIssueDAO;

public class RequestBookModel {
	BookIssueDAO bid=new BookIssueDAO();
	public boolean checkAvail(String bookid) {
		return bid.checkAvail(bookid);
	}

	public boolean issueBooks(IssueBookBean ibb){
		return bid.issueBooks(ibb);
		
	}
}
