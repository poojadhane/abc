package pop.Model;

import pop.Bean.UpdateProfileBean;
import pop.DAO.UpdateProfileDAO;

public class UpdateProfileModel {
	public boolean updateprofile(UpdateProfileBean upb){
		UpdateProfileDAO upd=new UpdateProfileDAO();
		return upd.updateprofile(upb);
	}
}
