package pop.Model;

import java.util.List;

import pop.Bean.IssueBookBean;
import pop.DAO.ReportDAO;

public class ReportModel {
	public List<IssueBookBean> issueReport(String date,String month,String year){
		ReportDAO rd=new ReportDAO();
		return rd.issueReport(date,month,year);
	}

}
