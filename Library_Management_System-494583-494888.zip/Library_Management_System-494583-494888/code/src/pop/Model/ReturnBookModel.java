package pop.Model;

import pop.Bean.IssueBookBean;
import pop.DAO.ReturnBookDAO;

public class ReturnBookModel {
	public boolean selectBook(IssueBookBean ibb,String bookId){
		ReturnBookDAO rbd=new ReturnBookDAO();
		return rbd.selectBook(ibb,bookId);
	}

}
