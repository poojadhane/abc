package pop.Model;

import java.util.List;

import pop.Bean.IssueBookBean;
import pop.DAO.MonthwiseReportDAO;

public class MonthwiseReportModel {
	public List<IssueBookBean> issueReport(IssueBookBean ibb,String month){
		MonthwiseReportDAO mrd=new MonthwiseReportDAO();
		return mrd.issueReport(ibb,month);
	}
}
