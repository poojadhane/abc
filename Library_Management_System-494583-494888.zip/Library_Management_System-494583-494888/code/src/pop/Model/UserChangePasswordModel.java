package pop.Model;

import pop.Bean.UserChangePasswordBean;
import pop.DAO.UserChangePasswordDAO;

public class UserChangePasswordModel {
	public boolean userchangepassword(UserChangePasswordBean ucpb){
		UserChangePasswordDAO ucpd=new UserChangePasswordDAO();
		return ucpd.userchangepassword(ucpb);
}
}