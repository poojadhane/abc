package pop.Model;

import pop.Bean.AdminLoginBean;
import pop.DAO.AdminLoginDAO;

public class AdminLoginModel {
	public boolean checkadminLogin(AdminLoginBean lb)
	{
		AdminLoginDAO ld=new AdminLoginDAO();
		return ld.checkadminLogin(lb);
	}
}
