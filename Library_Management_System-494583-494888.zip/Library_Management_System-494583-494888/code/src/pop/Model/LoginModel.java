package pop.Model;

import pop.Bean.LoginBean;
import pop.DAO.LoginDAO;

public class LoginModel {
	public boolean checkLogin(LoginBean lb)
	{
		LoginDAO ld=new LoginDAO();
		return ld.checkLogin(lb);
	}

}
