package pop.Model;

import pop.Bean.RemoveBookBean;
import pop.DAO.RemoveBookDAO;

public class RemoveBookModel {
	public boolean RemoveBook(RemoveBookBean rbb){
		RemoveBookDAO rd=new RemoveBookDAO();
		return rd.RemoveBook(rbb);
}
}
