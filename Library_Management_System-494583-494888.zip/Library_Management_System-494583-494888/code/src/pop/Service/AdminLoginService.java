package pop.Service;

import pop.Bean.AdminLoginBean;
import pop.Model.AdminLoginModel;

public class AdminLoginService {
	public boolean checkadminLogin(AdminLoginBean lb)
	{
		AdminLoginModel lm = new AdminLoginModel();
		return lm.checkadminLogin(lb);
		
	}
}
