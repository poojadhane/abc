package pop.Service;

import pop.Bean.IssueBookBean;
import pop.Model.ReturnBookModel;

public class ReturnBookService {
	public boolean selectBook(IssueBookBean ibb,String bookId){
		ReturnBookModel rbd=new ReturnBookModel();
		return rbd.selectBook(ibb,bookId);
	}

}
