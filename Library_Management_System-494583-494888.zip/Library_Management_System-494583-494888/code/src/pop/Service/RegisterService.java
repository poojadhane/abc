package pop.Service;

import pop.Bean.RegisterBean;
import pop.Model.RegisterModel;

public class RegisterService {
	public boolean addUser(RegisterBean rb){
		
		RegisterModel rm = new RegisterModel();
		return rm.addUser(rb);
		
	}


}
