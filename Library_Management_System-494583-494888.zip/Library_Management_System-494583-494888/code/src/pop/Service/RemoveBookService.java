package pop.Service;

import pop.Bean.RemoveBookBean;
import pop.Model.RemoveBookModel;

public class RemoveBookService {
	public boolean RemoveBook(RemoveBookBean rbb)
	{
		RemoveBookModel rbm = new RemoveBookModel();
		return rbm.RemoveBook(rbb);		
	}
}
