package pop.Service;

import pop.Bean.LoginBean;
import pop.Model.LoginModel;

public class LoginService {
	public boolean checkLogin(LoginBean lb)
	{
		LoginModel lm = new LoginModel();
		return lm.checkLogin(lb);
		
	}

}
