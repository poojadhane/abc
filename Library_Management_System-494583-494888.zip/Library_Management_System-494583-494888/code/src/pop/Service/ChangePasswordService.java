package pop.Service;

import pop.Bean.ChangePasswordBean;
import pop.Model.ChangePasswordModel;

public class ChangePasswordService {
	public boolean changepassword(ChangePasswordBean cpb)
	{
		ChangePasswordModel cpm = new ChangePasswordModel();
		return cpm.changepassword(cpb);		
	}

}
