package pop.Service;

import pop.Bean.AddBookBean;
import pop.Model.AddBookModel;

public class AddBookService {
	public boolean AddBook(AddBookBean abb)
	{
		AddBookModel abm = new AddBookModel();
		return abm.AddBook(abb);
		
	}

}
