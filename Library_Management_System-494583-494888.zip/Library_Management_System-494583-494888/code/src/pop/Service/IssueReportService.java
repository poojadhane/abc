package pop.Service;

import java.util.List;

import pop.Bean.IssueBookBean;
import pop.Model.IssueReportModel;
public class IssueReportService {
	public List<IssueBookBean> viewReport(String username) {
		IssueReportModel irm=new IssueReportModel();
		return irm.viewReport(username);
	}

}
