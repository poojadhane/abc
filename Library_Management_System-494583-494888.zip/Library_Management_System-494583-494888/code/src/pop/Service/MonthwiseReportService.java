package pop.Service;

import java.util.List;

import pop.Bean.IssueBookBean;
import pop.Model.MonthwiseReportModel;

public class MonthwiseReportService {
	public List<IssueBookBean> issueReport(IssueBookBean ibb,String month){
		MonthwiseReportModel mrm=new MonthwiseReportModel();
		return mrm.issueReport(ibb,month);
	}

}
