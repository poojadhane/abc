package pop.Service;

import pop.Bean.IssueBookBean;
import pop.Model.RequestBookModel;

public class RequestBookService {
	RequestBookModel rbm=new RequestBookModel();
public boolean checkAvail(String bookid) {			
		return rbm.checkAvail(bookid);
	}
	public boolean issueBooks(IssueBookBean ibb){
		return rbm.issueBooks(ibb);		
	}

}
