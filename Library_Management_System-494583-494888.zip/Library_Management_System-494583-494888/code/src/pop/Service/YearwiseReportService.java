package pop.Service;

import java.util.List;

import pop.Bean.IssueBookBean;
import pop.Model.YearwiseReportModel;

public class YearwiseReportService {
	public List<IssueBookBean> issueReport(String year){
		YearwiseReportModel yrm=new YearwiseReportModel();
		return yrm.issueReport(year);
	}
}
