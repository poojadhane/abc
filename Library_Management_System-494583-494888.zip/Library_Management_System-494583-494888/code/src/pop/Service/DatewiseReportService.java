package pop.Service;

import java.util.List;

import pop.Bean.IssueBookBean;
import pop.Model.DatewiseReportModel;

public class DatewiseReportService {
	public List<IssueBookBean> issueReport(String date,String month){
		DatewiseReportModel drm=new DatewiseReportModel();
		return drm.issueReport(date,month);
	}

}
