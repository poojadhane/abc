package pop.Service;

import pop.Bean.UpdateProfileBean;
import pop.Model.UpdateProfileModel;

public class UpdateProfileService {
	public boolean updateprofile(UpdateProfileBean upb){
	UpdateProfileModel upm = new UpdateProfileModel();
	return upm.updateprofile(upb);
	}
}
