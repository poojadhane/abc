package pop.Service;

import java.util.List;

import pop.Bean.IssueBookBean;
import pop.Model.ReportModel;

public class ReportService {

	public List<IssueBookBean> issueReport(String date, String month, String year) {
		ReportModel rm=new ReportModel();
		return rm.issueReport(date,month,year);
	}

}
