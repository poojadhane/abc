package pop.Service;

import pop.Bean.UserChangePasswordBean;
import pop.Model.UserChangePasswordModel;

public class UserChangePasswordService {
	public boolean userchangepassword(UserChangePasswordBean ucpb)
	{
		UserChangePasswordModel ucpm = new UserChangePasswordModel();
		return ucpm.userchangepassword(ucpb);		
	}

}
