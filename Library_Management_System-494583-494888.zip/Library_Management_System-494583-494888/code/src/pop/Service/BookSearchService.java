package pop.Service;

import java.util.List;

import pop.Bean.BookBean;
import pop.Model.BookSearchModel;

public class BookSearchService {
	public List<BookBean> searchBook(BookBean bb,String bookname)
	{
		BookSearchModel bsm = new BookSearchModel();
		return bsm.searchBook(bb,bookname);		
	}

}
