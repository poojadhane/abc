package pop.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import pop.Bean.UpdateProfileBean;
import pop.DB.DBcon;

public class UpdateProfileDAO {
		public boolean updateprofile(UpdateProfileBean upb){
			boolean b=false;
			Connection con=null;
			PreparedStatement ps=null;
			ResultSet rs=null;
			
			try{
				con = DBcon.getDBCon();
				System.out.println("connection established");
				
				ps=con.prepareStatement("update admin set ausername=?,email=?,contact=? where adname=?");
				ps.setString(1, upb.getAname());
				ps.setString(2, upb.getAemail());
				ps.setString(3, upb.getAphnum());
				ps.setString(4, upb.getUname());

				rs=ps.executeQuery();
				
				while(rs.next()){
					b=true;
					}
				return b;
				} 
				catch (SQLException e) {
					e.printStackTrace();
				}
			return b;
			}


		}


