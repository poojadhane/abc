package pop.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import pop.Bean.UserChangePasswordBean;
import pop.DB.DBcon;

public class UserChangePasswordDAO {
	public boolean userchangepassword(UserChangePasswordBean ucpb){
		boolean b=false;
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;

		try{
			con = DBcon.getDBCon();
			System.out.println("connection established");			
			ps=con.prepareStatement("update userreg set password=? where username=? and password=?");
			ps.setString(1,ucpb.getNewpassword());
			ps.setString(2,ucpb.getUsername());
			ps.setString(3,ucpb.getOldpassword());		
			rs=ps.executeQuery();			
			while(rs.next()){
				b=true;
				}
			return b;
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
		return b;
		}

}
