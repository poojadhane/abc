package pop.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import pop.Bean.BookBean;
import pop.DB.DBcon;

public class BookSearchDAO {
	public List<BookBean> searchBook(BookBean bb,String bookname) {
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List <BookBean> li=null;

		
		try{
			String title=bookname;
			con = DBcon.getDBCon();
			ps=con.prepareStatement("select * from books where title=?");
			ps.setString(1,title);
			
			 rs = ps.executeQuery();
			System.out.println(rs);
			
			li=new ArrayList<BookBean>();
			
			while(rs.next()){
				BookBean rbb=new BookBean();
				rbb.setIsbn(rs.getString(1));
				rbb.setTitle(rs.getString(2));
				rbb.setAuthor(rs.getString(3));
				rbb.setPublisher(rs.getString(4));
				rbb.setCategory(rs.getString(5));
				rbb.setPrice(rs.getInt(6));
				
				
				li.add(rbb);
			}
			
		//	System.out.println(li);
		}catch(Exception e){
			e.printStackTrace();
		}
		return li;
		
	}
}
