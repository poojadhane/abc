package pop.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import pop.Bean.IssueBookBean;
import pop.DB.DBcon;

public class MonthwiseReportDAO {

	public List<IssueBookBean> issueReport(IssueBookBean ibb, String month) {
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List <IssueBookBean> issuelist=null;
		
		try{
			String mon=month;
			issuelist=new ArrayList<IssueBookBean>();
			con = DBcon.getDBCon();
			ps=con.prepareStatement("select * from issuedbooks where to_char(issuedate,'MON')=?");
			ps.setString(1,mon);
			
			 rs = ps.executeQuery();
			
			while(rs.next()){
				IssueBookBean bb=new IssueBookBean();
				bb.setIsbn(rs.getString(1));
				bb.setUsername(rs.getString(2));
				/*bb.setIssueDate(rs.getDate(3));
				bb.setReturndate(rs.getDate(4));*/
				issuelist.add(bb);
			}
		
	}catch(Exception e){
		e.printStackTrace();
	}
		return issuelist;
	}

}
