package pop.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import pop.Bean.AdminLoginBean;
import pop.DB.DBcon;

public class AdminLoginDAO {
	public boolean checkadminLogin(AdminLoginBean alb){
		boolean b=false;
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try{
		con = DBcon.getDBCon();
		System.out.println("connection established");
		
		ps=con.prepareStatement("select * from admin where adname=? and apass=?");
		ps.setString(1,alb.getUname());
		ps.setString(2,alb.getPwd());
		rs=ps.executeQuery();
		System.out.println(rs);
		if(rs.next()){
			b=true;
			return b;
		}
		} 
		catch(Exception e){
			e.printStackTrace();
		}
		
		return b;
	}

}
