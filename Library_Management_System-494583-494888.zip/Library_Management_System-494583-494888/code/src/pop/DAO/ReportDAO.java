package pop.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import pop.Bean.IssueBookBean;
import pop.DB.DBcon;

public class ReportDAO {
	public List<IssueBookBean> issueReport(String date,String month,String year) {
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List <IssueBookBean> issuelist=null;
		
		try{
			String dt=date;
			String mo=month;
			String yy=year;
			issuelist=new ArrayList<IssueBookBean>();
			con = DBcon.getDBCon();
			ps=con.prepareStatement("select * from issuedbooks where to_char(issuedate,'DD')=? and to_char(issuedate,'MON')=? and to_char(issuedate,'YY')=?");
			ps.setString(1,dt);
			ps.setString(2, mo);
			ps.setString(3, yy);
			
			 rs = ps.executeQuery();
			
			while(rs.next()){
				IssueBookBean bb=new IssueBookBean();
				bb.setIsbn(rs.getString(1));
				bb.setUsername(rs.getString(2));
				/*bb.setIssueDate(rs.getDate(3));
				bb.setReturndate(rs.getDate(4));*/
				issuelist.add(bb);
			}
		
	}catch(Exception e){
		e.printStackTrace();
	}
		return issuelist;
	}
}
