package pop.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;

import pop.Bean.RemoveBookBean;
import pop.DB.DBcon;

public class RemoveBookDAO {
	public boolean RemoveBook(RemoveBookBean rbb){
		boolean b = false;
		
		try{
			 Connection con = DBcon.getDBCon();
			PreparedStatement ps = con.prepareStatement("delete from books where isbn=? and title=?");
			ps.setString(1, rbb.getIsbn());
			ps.setString(2, rbb.getTitle());
			int result = ps.executeUpdate();
			System.out.println(result);
			
	    if(result>0){
	    	b = true;
	    }
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		System.out.println(b);
		return b;
		
}

}
