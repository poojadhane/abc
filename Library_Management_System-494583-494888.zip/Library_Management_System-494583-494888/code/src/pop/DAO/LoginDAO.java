package pop.DAO;

import java.sql.*;
import pop.Bean.LoginBean;
import pop.DB.DBcon;
public class LoginDAO {
	public boolean checkLogin(LoginBean lb){
		boolean b=false;
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try{
		con = DBcon.getDBCon();
		System.out.println("connection established");
		
		ps=con.prepareStatement("select * from userreg where username=? and password=?");
		ps.setString(1,lb.getUname());
		ps.setString(2,lb.getPwd());
		rs=ps.executeQuery();
		System.out.println(rs);
		if(rs.next()){
			b=true;
			return b;
		}
		} 
		catch(Exception e){
			e.printStackTrace();
		}
		
		return b;
	}
}
