package pop.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.Date;

import pop.Bean.IssueBookBean;
import pop.DB.DBcon;

public class ReturnBookDAO {
	public boolean selectBook(IssueBookBean bb,String bookid) {
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;		
		try{
			String bnum=bookid;
			con = DBcon.getDBCon();
			ps=con.prepareStatement("select * from issuedbooks where isbn=?");
			ps.setString(1,bnum);
			
			 rs = ps.executeQuery();
			System.out.println(rs);
			while(rs.next()){
				String isbn=rs.getString(1);
				String uname=rs.getString(2);
				Date issue=rs.getDate(3);
				Date returndate=rs.getDate(4);
				ps=con.prepareStatement("insert into returnedbooks values(?,?,?,?)");
				
				ps.setString(1, isbn);
				ps.setString(2, uname);
				ps.setDate(3, (java.sql.Date) issue);;
				ps.setDate(4, (java.sql.Date) returndate);
				int res=ps.executeUpdate();
				
				if(res>0){
					ps=con.prepareStatement("delete from issuedbooks where isbn=?");
					ps.setString(1,bookid);
					
					int result = ps.executeUpdate();
					if(result>0){
					System.out.println("returned");
					return true;
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
}

		