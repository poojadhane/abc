package pop.DAO;

import java.sql.*;
import pop.Bean.RegisterBean;
import pop.DB.DBcon;
public class RegisterDAO {
	public boolean addUser(RegisterBean rb){
		boolean b = false;		
		try{			
	  Connection con = DBcon.getDBCon();	
	  PreparedStatement ps = con.prepareStatement("insert into userreg values(?,?,?,?,?,?)");
	  	ps.setString(1, rb.getName());
	  	ps.setString(2, rb.getUsername());
	  	ps.setString(3, rb.getPass());
	  	ps.setString(4, rb.getMail());
	  	ps.setString(5, rb.getContact());	  	  	
	  	ps.setString(6, rb.getDesignation());
	  int result = ps.executeUpdate();
	    if(result==1){
	    	b = true;
	    }
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return b;
		}
}
