package pop.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import pop.Bean.ChangePasswordBean;
import pop.DB.DBcon;

public class ChangePasswordDAO {
	public boolean changepassword(ChangePasswordBean cpb){
		boolean b=false;
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;

		try{
			con = DBcon.getDBCon();
			System.out.println("connection established");			
			ps=con.prepareStatement("update admin set apass=? where adname=? and apass=?");
			ps.setString(1,cpb.getNewpassword());
			ps.setString(2,cpb.getUsername());
			ps.setString(3,cpb.getOldpassword());		
			rs=ps.executeQuery();			
			while(rs.next()){
				b=true;
				}
			return b;
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
		return b;
		}
}
