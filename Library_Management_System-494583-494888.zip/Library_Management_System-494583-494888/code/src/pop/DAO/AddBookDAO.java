package pop.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;

//import com.beans.AddBookBean;
import pop.Bean.AddBookBean;
import pop.DB.DBcon;


public class AddBookDAO {
	public boolean AddBook(AddBookBean abb){
		boolean b = false;
		
		try{
			 Connection con = DBcon.getDBCon();
			PreparedStatement ps = con.prepareStatement("insert into books values(?,?,?,?,?,?,?)");
			ps.setString(1, abb.getIsbn());
			ps.setString(2, abb.getTitle());
			ps.setString(3, abb.getAuthor());
			ps.setString(4, abb.getPublisher());
			ps.setString(5, abb.getCategory());
			ps.setString(6, abb.getPrice());
			ps.setString(7, abb.getQuantity());

			int result = ps.executeUpdate();
			System.out.println(result);
			
	    if(result>0){
	    	b = true;
	    }
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		System.out.println(b);
		return b;
		
}
}