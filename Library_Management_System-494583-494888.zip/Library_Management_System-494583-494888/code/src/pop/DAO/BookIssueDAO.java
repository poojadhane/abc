package pop.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import pop.Bean.IssueBookBean;
import pop.DB.DBcon;

public class BookIssueDAO {
	boolean result=false;
	public boolean checkAvail(String bookid) {
		Connection con=null;
		PreparedStatement ps=null;	
		
		try{
			con = DBcon.getDBCon();		
			ps=con.prepareStatement("select * from books where isbn=? and isbn not in (select isbn from issuedbooks)");			
			ps.setString(1, bookid);					
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				result=true;
				System.out.println("book available status = true");
			}					
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;	
	}

	public boolean issueBooks(IssueBookBean ibb) {
		try{
			
			Connection con=null;
			PreparedStatement ps=null;
				   
			con = DBcon.getDBCon();		
			ps=con.prepareStatement("insert into issuedbooks values(?,?,?,?)");
			ps.setString(1,ibb.getIsbn());
			ps.setString(2,ibb.getUsername());
			ps.setDate(3,(java.sql.Date) ibb.getIssueDate());
			ps.setDate(4,(java.sql.Date) ibb.getReturndate());
			
			int i=ps.executeUpdate();
			if(i>0)
			{
				result=true;
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return result;

}
}