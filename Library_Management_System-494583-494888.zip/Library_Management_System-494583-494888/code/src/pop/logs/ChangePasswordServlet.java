package pop.logs;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pop.Bean.ChangePasswordBean;
import pop.Service.ChangePasswordService;

/**
 * Servlet implementation class ChangePasswordServlet
 */
@WebServlet("/ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /** 
     * @see HttpServlet#HttpServlet()
     */
    public ChangePasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
        @SuppressWarnings("unused")
		PrintWriter out = response.getWriter();
        String aname=request.getParameter("aname");
        String opass=request.getParameter("opass");
        String pass=request.getParameter("pass");
        String rpass=request.getParameter("rpass");
        ChangePasswordBean cpb=new ChangePasswordBean();
        if(pass.equals(rpass))
        {
           	cpb.setUsername(aname);
        	cpb.setOldpassword(opass);
        	cpb.setNewpassword(pass);
            ChangePasswordService cps=new ChangePasswordService();
            boolean result=cps.changepassword(cpb);
            if(result)
            {
            request.getRequestDispatcher("index.jsp").forward(request, response);
            request.setAttribute("successmsg","PASSWORD CHANGED!!  relogin");
            }            
            else
            {
            	request.getRequestDispatcher("admin.jsp").forward(request, response);
            	request.setAttribute("errormsg","PASSWORD NOT CHANGED!! Try Again");
            }
        }
        else 
       {
        	request.getRequestDispatcher("admin.jsp").forward(request, response);
        	request.setAttribute("errormsg","PASSWORD NOT CHANGED!! Try Again");
       }
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
