package pop.logs;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import pop.DB.DBcon;

@WebServlet("/ForgotpasswordServlet")
public class ForgotpasswordServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ForgotpasswordServlet() {
        super();
       
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
	@SuppressWarnings("unused")
	boolean b=false;
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	PrintWriter out =response.getWriter();
	
	String user=request.getParameter("username");
	String pass=request.getParameter("pass");
	String rpass=request.getParameter("rpass");
	try{
		con = DBcon.getDBCon();
		System.out.println("connection established");
		response.setContentType("text/html;charset=UTF-8");
		if(pass.equals(rpass))
		{
			b=true;
		}
		if(b=true)
		{
		ps=con.prepareStatement("update userreg set pass=? where username=?");
		ps.setString(1,pass);
		ps.setString(2,user);
		rs=ps.executeQuery();
		}
		out.println("<html><body>Password change Success <br> <a href='index.html'>Click here</a>To go to homepage</body></html>");
		while(rs.next()){
			b=true;
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
