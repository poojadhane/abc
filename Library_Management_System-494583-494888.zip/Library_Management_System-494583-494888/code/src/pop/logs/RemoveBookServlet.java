package pop.logs;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pop.Bean.RemoveBookBean;
import pop.Service.RemoveBookService;

/**
 * Servlet implementation class RemoveBookServlet
 */
@WebServlet("/RemoveBookServlet")
public class RemoveBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveBookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");	
		String isbn=request.getParameter("isbn");
		String title=request.getParameter("title");
		
		RemoveBookBean rbb=new RemoveBookBean();
	    rbb.setIsbn(isbn);
	    rbb.setTitle(title);
	    RemoveBookService rbs=new RemoveBookService();
	    boolean result=rbs.RemoveBook(rbb);
	    if(result)
	    {	request.getRequestDispatcher("admin.jsp").forward(request, response);
	    	request.setAttribute("successmsg","Book removed");
	    }
	    else
	    {
	    	request.setAttribute("errormsg","Book not removed");
	    }
	}

}
