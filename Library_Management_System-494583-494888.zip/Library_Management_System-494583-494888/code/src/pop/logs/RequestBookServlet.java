package pop.logs;

import java.io.IOException;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pop.Bean.IssueBookBean;
import pop.Service.RequestBookService;

@WebServlet("/RequestBookServlet")
public class RequestBookServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	RequestDispatcher rd=null;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String username=request.getParameter("uname");
		String isbn=request.getParameter("isbn");
		IssueBookBean ibb=new IssueBookBean();
		
			RequestBookService rbs = new RequestBookService();
			boolean isAvail = rbs.checkAvail(isbn);
			
			java.util.Date date = new java.util.Date();
			 long t = date.getTime();
			java.sql.Date issueDate = new java.sql.Date(t);
			
			Calendar cal = Calendar.getInstance();
		     
		        cal.setTime(date);
		        cal.add(Calendar.DATE, 7);
		        java.util.Date utilDate = cal.getTime();
		        java.sql.Date returnDate = new java.sql.Date(utilDate.getTime());
		        ibb.setIsbn(isbn);
		        ibb.setUsername(username);
		        ibb.setIssueDate(issueDate);
		        ibb.setReturndate(returnDate);
		        System.out.println(isbn+username+issueDate+""+returnDate);
		        System.out.println(isAvail);
				if(isAvail)
				{
					boolean flag=rbs.issueBooks(ibb);
					System.out.println(flag);
					if(flag){
						System.out.println(issueDate+""+returnDate);
						    rd = request.getRequestDispatcher("RequestSuccess.jsp");
						    rd.forward(request, response);
						
					}
					else		
					{
						 rd = request.getRequestDispatcher("UserOperationFailure.jsp");
						  rd.forward(request, response);
					
					}
	         }
				else{
	        	 rd = request.getRequestDispatcher("UserOperationFailure.jsp");
	        	 rd.forward(request, response);
	}
}
}


