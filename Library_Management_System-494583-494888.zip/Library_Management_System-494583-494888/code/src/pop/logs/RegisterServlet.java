package pop.logs;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pop.Bean.RegisterBean;
import pop.Service.RegisterService;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
    public RegisterServlet() {
        super();
       
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
 
        String name = request.getParameter("cname");
        String username = request.getParameter("uname");
        String pass = request.getParameter("upwd");
        String rpass = request.getParameter("cupwd");
        String mail = request.getParameter("cemail");
        String contact = request.getParameter("cphnum");  
        String Designation=request.getParameter("cdesig");
        
        if(pass.equals(rpass))
        {
        	RegisterBean rb=new RegisterBean();
        	rb.setName(name);
        	rb.setUsername(username);
        	rb.setPass(pass);
        	rb.setMail(mail);
        	rb.setContact(contact);
        	rb.setDesignation(Designation);
        	
        	RegisterService rs=new RegisterService();
        	boolean result=rs.addUser(rb);
        	
         if(result)
          {
            request.getRequestDispatcher("Success.jsp").forward(request, response);;
          }            
        else
        {
        	out.println("<p>Not registered</p>");
        
        }
        }
        else 
        {
        	out.println("<p>Password mismatch</p>");
        	out.println("<a href='index.jsp'>Click here to Register again</a>");
        }
        }      
         
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	doGet(request,response);
    }
}
