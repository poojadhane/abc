package pop.logs;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pop.Bean.UpdateProfileBean;
import pop.Service.UpdateProfileService;

@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProfileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
    	response.setContentType("text/html;charset=UTF-8");
    	String uname=request.getParameter("uname");
    	String aname=request.getParameter("aname");
    	String aemail=request.getParameter("aemail");
    	String aphnum=request.getParameter("aphnum");  
    	try
    	{
    		UpdateProfileBean upb=new UpdateProfileBean();
    		upb.setUname(uname);
    		upb.setAname(aname);
    		upb.setAemail(aemail);    	
    		upb.setAphnum(aphnum);
    		
    		UpdateProfileService ups=new UpdateProfileService();
    		boolean result=ups.updateprofile(upb);
    		if(result)
    		{
    			request.getRequestDispatcher("admin.jsp").forward(request, response);
    		}
    		else
    		{
    			request.getRequestDispatcher("index.jsp").forward(request, response);
    		}
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }

}
