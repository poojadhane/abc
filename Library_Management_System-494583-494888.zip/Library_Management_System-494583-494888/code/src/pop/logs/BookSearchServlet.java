package pop.logs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import pop.Bean.BookBean;
import pop.Service.BookSearchService;

@WebServlet("/BookSearchServlet")
public class BookSearchServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
   
    public BookSearchServlet() {
        super();
       
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	String bookname = request.getParameter(("bname"));
    	RequestDispatcher rd=null;
    	List<BookBean> li=new ArrayList<BookBean>();
		BookBean bb=new BookBean();
		System.out.println(bookname);
	
		BookSearchService bss=new BookSearchService();
		li=bss.searchBook(bb,bookname);
		if(!li.isEmpty())
		{		
		rd = request.getRequestDispatcher("SearchBook.jsp");
		request.setAttribute("li",li);
		rd.forward(request, response);
		}
		else{
			rd = request.getRequestDispatcher("SearchBook.jsp");
			 request.setAttribute("errormsg","BOOK NOT found");
			  rd.forward(request, response);
		}
    }
}
