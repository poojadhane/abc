package pop.logs;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pop.Bean.AdminLoginBean;
import pop.Service.AdminLoginService;

@WebServlet("/AdminloginServlet")
public class AdminloginServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
       
   
    public AdminloginServlet() {
        super();
       
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
 
        String adname = request.getParameter("admin");
        String adpass = request.getParameter("apass");
        try
        {
        AdminLoginBean lb=new AdminLoginBean();
        lb.setUname(adname);
        lb.setPwd(adpass);
        
        AdminLoginService ls=new AdminLoginService();
    	boolean result=ls.checkadminLogin(lb);
    	if(result)
        {
          request.getRequestDispatcher("admin.jsp").forward(request, response);
        }
       
        }
        catch(Exception se)
        {
            out.println(se);
        }
 
      }
  }