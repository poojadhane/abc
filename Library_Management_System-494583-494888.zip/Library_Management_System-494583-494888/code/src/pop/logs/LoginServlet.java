package pop.logs;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pop.Bean.LoginBean;
import pop.Service.LoginService;



@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
private static final long serialVersionUID = 1L;       
   
    public LoginServlet() {
        super();       
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
 
        String uname = request.getParameter("username");
        String pass = request.getParameter("pass");
        try
        {
        LoginBean lb=new LoginBean();
        lb.setUname(uname);
        lb.setPwd(pass);
        
        LoginService ls=new LoginService();
    	boolean result=ls.checkLogin(lb);
    	if(result)
        {
          request.getRequestDispatcher("user.jsp").forward(request, response);
        }
    	else
    	{
    		request.getRequestDispatcher("user.jsp").forward(request, response);
    	}
       
        }
        catch(Exception se)
        {
            out.println(se);
        }
 
      }
  }
