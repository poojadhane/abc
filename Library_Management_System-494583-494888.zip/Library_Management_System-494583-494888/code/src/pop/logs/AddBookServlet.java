package pop.logs;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pop.Bean.AddBookBean;
import pop.Service.AddBookService;


/**
 * Servlet implementation class AddBookServlet
 */
@WebServlet("/AddBookServlet")
public class AddBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddBookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");	
		String isbn=request.getParameter("isbn");
		String title=request.getParameter("title");
		String author=request.getParameter("author");
		String publisher=request.getParameter("publisher");
		String category=request.getParameter("category");
		String price=request.getParameter("price");
		String quantity=request.getParameter("quantity");
							
		AddBookBean abb=new AddBookBean();
	    abb.setIsbn(isbn);
	    abb.setTitle(title);
	    abb.setAuthor(author);
	    abb.setPublisher(publisher);
	    abb.setCategory(category);
	    abb.setPrice(price);
	    abb.setQuantity(quantity);
			
	    AddBookService abs=new AddBookService();
	    boolean result=abs.AddBook(abb);
	    if(result)
	    {	request.getRequestDispatcher("admin.jsp").forward(request, response);
	    	request.setAttribute("successmsg","Book added");
	    }
	    else
	    {
	    	request.setAttribute("errormsg","Book not added");
	    }
			
			
		}

}
