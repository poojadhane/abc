package pop.logs;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pop.Bean.UserChangePasswordBean;
import pop.Service.UserChangePasswordService;

/**
 * Servlet implementation class UserChangePasswordServlet
 */
@WebServlet("/UserChangePasswordServlet")
public class UserChangePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserChangePasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
        @SuppressWarnings("unused")
		PrintWriter out = response.getWriter();
        String uname=request.getParameter("uname");
        String opass=request.getParameter("opass");
        String pass=request.getParameter("pass");
        String rpass=request.getParameter("rpass");
        UserChangePasswordBean ucpb=new UserChangePasswordBean();
        if(pass.equals(rpass))
        {
           	ucpb.setUsername(uname);
        	ucpb.setOldpassword(opass);
        	ucpb.setNewpassword(pass);
            UserChangePasswordService ucps=new UserChangePasswordService();
            boolean result=ucps.userchangepassword(ucpb);
            if(result)
            {
            request.getRequestDispatcher("index.jsp").forward(request, response);
            request.setAttribute("successmsg","PASSWORD CHANGED!!  relogin");
            }            
            else
            {
            	request.getRequestDispatcher("user.jsp").forward(request, response);
            	request.setAttribute("errormsg","PASSWORD NOT CHANGED!! Try Again");
            }
        }
        else 
       {
        	request.getRequestDispatcher("user.jsp").forward(request, response);
        	request.setAttribute("errormsg","PASSWORD NOT CHANGED!! Try Again");
       }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
