package pop.DB;
import java.sql.Connection;
import java.sql.DriverManager;

public class DBcon {
	public static Connection getDBCon(){
		Connection con = null;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@10.30.130.65:1521:orcl";
		String uname = "user2";
		String pass = "oracle";
		con = DriverManager.getConnection(url,uname,pass);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		System.out.println("connection made ");
		return con;
	}
}
