#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify all boundaries for parameters that are
 #          having range of valid values.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $f_float;
 my $i_integer;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex         = 1200; # ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex   = 1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "MPA";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_MPA.xls");
     
 }
 sub Run() 
 { 
 
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write STRATEGY for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write STRATEGY for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("N", $o_STRATEGYInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write STRATEGY for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("N", $o_STRATEGYInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write STRATEGY for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("C", $o_ALERTKEYInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ALERT KEY for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("C", $o_ALERTKEYInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ALERT KEY for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("N", $o_ALERTKEYInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ALERT KEY for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("N", $o_ALERTKEYInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ALERT KEY for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CONTROL_MODE for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CONTROL_MODE for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CONTROL_MODE for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CONTROL_MODE for out of range value");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR_MODE for minimum range value");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR_MODE for maximum range value");
    }		
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("N", $o_ACTUATOR_MODEInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ACTUATOR_MODE for OUT range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ACTUATOR_MODE for OUT range value");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write HOST_COMMAND_ESD for minimum range value");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write HOST_COMMAND_ESD for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write HOST_COMMAND_ESD for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write HOST_COMMAND_ESD for out of range value");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write JOG_CONTROL for minimum range value");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write JOG_CONTROL for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write JOG_CONTROL for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write JOG_CONTROL for out of range value");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write DISABLE_LOW_POWER_MODE for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write DISABLE_LOW_POWER_MODE for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISABLE_LOW_POWER_MODE for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISABLE_LOW_POWER_MODE for out of range value");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write OPEN_TORQUE_LIMIT for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write OPEN_TORQUE_LIMIT for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OPEN_TORQUE_LIMIT for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OPEN_TORQUE_LIMIT for out of range value");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR_COMMAND for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR_COMMAND for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write ACTUATOR_COMMAND for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write ACTUATOR_COMMAND for out of range value");
    }  

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SETPOINT for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $i_integer = pack("C", 100);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SETPOINT for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write SETPOINT for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $i_integer = pack("C", 101);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write SETPOINT for out of range value");
    }  

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write User Home Port for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("C", 7);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write User Home Port for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write User Home Port for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("C", 8);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write User Home Port for out of range value");
    }	
	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Home Port Label for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Home Port Label for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write Home Port Label for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write Home Port Label for out of range value");
    }	
	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("n", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write disable ports for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("n", 6);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write disable ports for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write disable ports for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("n", 7);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write disable ports for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  my $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write Home Port Calibration for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Home Port Calibration for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Home Port Calibration for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Home Port Calibration for out of range value");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write Port 1 Calibration for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Port 1 Calibration for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 1 Calibration for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 1 Calibration for out of range value");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,3, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write Port 2 Calibration for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,3, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Port 2 Calibration for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,3, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 2 Calibration for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,3, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 2 Calibration for out of range value");
    }	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write Port 3 Calibration for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Port 3 Calibration for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 3 Calibration for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 3 Calibration for out of range value");
    }	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write Port 4 Calibration for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Port 4 Calibration for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 4 Calibration for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 4 Calibration for out of range value");
    }	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,6, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write Port 5 Calibration for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,6, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Port 5 Calibration for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,6, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 5 Calibration for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,6, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 5 Calibration for out of range value");
    }	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,7, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write Port 6 Calibration for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,7, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Port 6 Calibration for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,7, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 6 Calibration for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,7, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 6 Calibration for out of range value");
    }		

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,8, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write Port 7 Calibration for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,8, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Port 7 Calibration for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,8, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 7 Calibration for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index,8, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Port 7 Calibration for out of range value");
    }	
}
sub Teardown()
{
  Log("Teardown ADVT test script....");
}