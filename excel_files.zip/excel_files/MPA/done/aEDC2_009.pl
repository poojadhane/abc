#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify RW access each TB block parameter according to the modes defined in 
 #          parameter table.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex = ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "MPA";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE.xls");
     

  #Schedule TB block to execute
  #Any FB won't go to AUTO mode unless scheduled to execute

  my $i_OdIndexFbStartEntry = $ff_tools::hostapi::OD_INDEX_FB_START_ENTRY;
  my $o_FBSched             = new ff_tools::od::fbap::fb_schedule();
  $o_FBSched->block_starting_time = 0;
  $o_FBSched->FB_index            = $o_TBInfo->od_index;
  $o_FBSched->VfdId               = 0x01;
  ff_tools::hostapi::api::Write($i_DutMibVcrId, $i_OdIndexFbStartEntry , 0, length($o_FBSched->data), $o_FBSched->data);
}
 sub Run() 
 { 
 
  my $o_ModeblkInfo = $o_RBInfo->get_param_info("MODE_BLK");
  my $o_TBModeblkInfo = $o_TBInfo->get_param_info("MODE_BLK");
  my @i_allowed_mode = (OOS,AUTO,MAN);
  my @i_allow_mode_string = ("OS","AUTO","MAN");
  my $o_RBBlkMode = new ff_tools::od::fbap::blocks::mode_blk();
  $o_RBBlkMode = ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, AUTO);
  if (!(ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, AUTO)))
  {
    fail("Unable to set RB in AUTO mode");
  }
  for (my $i=0; $i<=length(@i_allowed_mode); $i++)
  {
    if (!(ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_TBBlkIndex + $o_TBModeblkInfo->parameter_index, $i_allowed_mode[$i])))
    {
      fail("Unable to set TB in %s mode", $i_allow_mode_string[$i]);
    }

    my $o_TAGDESCInfo = $o_TBInfo->get_param_info("TAG DESC");
    if ($o_TAGDESCInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TAGDESCInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to TAG DESC");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TAGDESCInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to TAG DESC");
      }
    }

    my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
    if ($o_STRATEGYInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to STRATEGY");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to STRATEGY");
      }
    }

    my $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
    if ($o_ALERTKEYInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ALERT KEY");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ALERT KEY");
      }
    }

    my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
    if ($o_CONTROL_MODEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toCONTROL_MODE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toCONTROL_MODE");
      }
    }

    my $o_ENABLE_RDMSInfo = $o_TBInfo->get_param_info("ENABLE_RDMS");
    if ($o_ENABLE_RDMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_RDMSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ENABLE_RDMS");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_RDMSInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ENABLE_RDMS");
      }
    }

    my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    if ($o_ACTUATOR_MODEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ACTUATOR_MODE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ACTUATOR_MODE");
      }
    }

    my $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
    if ($o_CONFIGURATION_COMMANDSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toCONFIGURATION_COMMANDS");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toCONFIGURATION_COMMANDS");
      }
    }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to JOG_CONTROL");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to JOG_CONTROL");
      }
    }

    my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
    if ($o_CONTROL_PARAM_2Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISPLAY_LOW_POWER_MODE");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to DISPLAY_LOW_POWER_MODE");
      }
    }

    my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
    if ($o_HOST_COMMAND_ESDInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to VALUE");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toHOST_COMMAND_ESD");
      }
    }

    my $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
    if ($o_PORT_INFOInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to USER_HOME_PORT");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toPORT_INFO");
      }
    }

    $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
    if ($o_PORT_INFOInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to HOME_PORT_LABEL");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toPORT_INFO");
      }
    }

    $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
    if ($o_PORT_INFOInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to NUMBER_OF_PORTS");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toPORT_INFO");
      }
    }

    $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
    if ($o_PORT_INFOInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISABLE_PORTS");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toPORT_INFO");
      }
    }

    my $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
    if ($o_ESD_ENABLES_AND_ACTIONInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ESD_ACTION");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toESD_ENABLES_AND_ACTION");
      }
    }

    my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
    if ($o_TORQUE_LIMITInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPEN_TORQUE_LIMIT");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toTORQUE_LIMIT");
      }
    }

    my $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
    if ($o_MPA_PORT_CAL_DATAInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to Home_Port_Calibration");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toMPA_PORT_CAL_DATA");
      }
    }

    $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
    if ($o_MPA_PORT_CAL_DATAInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to Port_1_Calibration");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toMPA_PORT_CAL_DATA");
      }
    }

    $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
    if ($o_MPA_PORT_CAL_DATAInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to Port_2_Calibration");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toMPA_PORT_CAL_DATA");
      }
    }

    $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
    if ($o_MPA_PORT_CAL_DATAInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to Port_3_Calibration");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toMPA_PORT_CAL_DATA");
      }
    }

    $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
    if ($o_MPA_PORT_CAL_DATAInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to Port_4_Calibration");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toMPA_PORT_CAL_DATA");
      }
    }

    $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
    if ($o_MPA_PORT_CAL_DATAInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to Port_5_Calibration");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toMPA_PORT_CAL_DATA");
      }
    }

    $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
    if ($o_MPA_PORT_CAL_DATAInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 7);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to Port_6_Calibration");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 7, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toMPA_PORT_CAL_DATA");
      }
    }

    $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
    if ($o_MPA_PORT_CAL_DATAInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 8);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to Port_7_Calibration");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 8, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toMPA_PORT_CAL_DATA");
      }
    }

    my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
    if ($o_ACTUATOR_COMMANDInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ACTUATOR_COMMAND");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ACTUATOR_COMMAND");
      }
    }

    #my $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT")
    #if ($o_DEFAULT_SETPOINTInfo->mode_for_write =~ $i_allow_mode_string[$i])
    #{
  #$rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1);
     # if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      #{
      #  fail("Expected confirm positive for read to DEFAULT_SETPOINT_1");
     # }
  #ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      #if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
     # {
      #  fail("Expected confirm positive for write toDEFAULT_SETPOINT");
     # }
    #}

    #my $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT")
   # if ($o_DEFAULT_SETPOINTInfo->mode_for_write =~ $i_allow_mode_string[$i])
   # {
  #$rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 2);
   #   if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    #  {
    #    fail("Expected confirm positive for read to DEFAULT_SETPOINT_2");
    #  }
 # ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
   #   if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
   #   {
    #    fail("Expected confirm positive for write toDEFAULT_SETPOINT");
    #  }
   # }

    my $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
    if ($o_SETPOINTInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to SETPOINT");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to SETPOINT");
      }
    }
  }
}


sub Teardown()
{
  Log("Teardown ADVT test script....");
}