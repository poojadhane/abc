#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify that ST_REV incremented if any of the TB block Static parameter is written with
 #          same value or changed and ST_REV do not increment if Dynamic or Non-Volatile parameter is changed.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $i_StatRev;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex         = 1200; # ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex   = 1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "MPA";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_MPA.xls");
     
 sub Run() 
 { 
 
  my $o_StatRevInfo = $o_TBInfo->get_param_info("ST_REV");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0); 
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  $stRev_Temp = $i_StatRev;

  my $o_TagdescInfo = $o_TBInfo->get_param_info("TAG_DESC");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TagdescInfo->parameter_index, 0);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TagdescInfo->parameter_index,0,length($rh_Result->{"Confirm"}->Data),$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0); 
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
    fail("ST_REV could not incremented for change in tag desc");
  }
  $stRev_Temp = $i_StatRev;  

  my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->test_value);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in STRATEGY");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT KEY");
  $i_integer = pack("C", $o_ALERTKEYInfo->test_value);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in ALERT KEY");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->test_value);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in CONTROL_MODE");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->test_value);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  != $stRev_Temp)
  {
   fail("ST_REV incremented for change in ACTUATOR_MODE");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
  $i_integer = pack("C", $o_CONFIGURATION_COMMANDSInfo->test_value);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  != $stRev_Temp)
  {
   fail("ST_REV incremented for change in CONFIGURATION_COMMANDS");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in JOG_CONTROL");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 3);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in DISPLAY_LOW_POWER_MODE");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in VALUE");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in USER_HOME_PORT");
  }
  $stRev_Temp = $i_StatRev; 

  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in HOME_PORT_LABEL");
  }
  $stRev_Temp = $i_StatRev; 

  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 3);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in NUMBER_OF_PORTS");
  }
  $stRev_Temp = $i_StatRev; 

  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO")
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 4);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in DISABLE_PORTS");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in ESD_ACTION");
  }
  $stRev_Temp = $i_StatRev; 


  my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in OPEN_TORQUE_LIMIT");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 1);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in Home_Port_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 2);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in Port_1_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 3);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in Port_2_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 4);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in Port_3_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 5);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in Port_4_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 6);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in Port_5_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 7);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 7, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in Port_6_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 8);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 8, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_ResourceBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   fail("ST_REV could not incremented for change in Port_7_Calibration");
  }
  $stRev_Temp = $i_StatRev; 
  
  
  my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  != $stRev_Temp)
  {
   fail("ST_REV incremented for change in ACTUATOR_COMMAND");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  != $stRev_Temp)
  {
   fail("ST_REV incremented for change in SETPOINT");
  }
  $stRev_Temp = $i_StatRev;     
}
sub Teardown()
{
  Log("Teardown ADVT test script....");
}