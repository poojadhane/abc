#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify that all Static & Non-volatile parameters retains
 #          there previously written value after power reset.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;
use constant RESTART_WITH_PROCESSOR             => 4;
use constant MIB_PROFILE_NO                     => 0x4D47;
use constant FBAP_PROFILE_NO                    => 0;
use constant OD_VERSION                         => 1;
use constant ABORT_REASON                       => 0x01;   
 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $i_integer;
 my $f_float;
 my $o_STRATEGYInfo;
 my $o_ALERT_KEYInfo;
 my $o_CONTROL_MODEInfo;
 my $o_CONFIGURATION_COMMANDSInfo;
 my $o_ACTUATOR_MODEInfo;
 my $o_CONTROL_PARAM_1Info;
 my $o_CONTROL_PARAM_2Info;
 my $o_HOST_COMMAND_ESDInfo;
 my $o_PORT_INFOInfo;
 my $o_ESD_ENABLES_AND_ACTIONInfo;
 my $o_TORQUE_LIMITInfo;
 my $o_MPA_PORT_CAL_DATAInfo;
  my $o_ACTUATOR_COMMANDInfo;
 my $o_DEFAULT_SETPOINTInfo;
 my $o_SETPOINTInfo; 
 
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = 1200; #ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex = 1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "MPA";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_MPA.xls");
     
   my $o_ModeblkInfo = $o_RBInfo->get_param_info("MODE_BLK");
   my $o_RBlkMode = new ff_tools::od::fbap::blocks::mode_blk();
   $o_RBlkMode    = ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, OOS);
   if (!(ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, OOS)))
   {
     print("\n-> Test FAILED :Unable to set RB in OOS mode");
   }

  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toSTRATEGY");
  }

  $o_ALERT_KEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("C", $o_ALERT_KEYInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT_KEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toALERT_KEY");
  }

  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCONTROL_MODE");
  }

  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toACTUATOR_MODE");
  }

  $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
  $i_integer = pack("C", $o_CONFIGURATION_COMMANDSInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCONFIGURATION_COMMANDS");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCONTROL_PARAM_1");
  }

  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCONTROL_PARAM_2");
  }

  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toHOST_COMMAND_ESD");
  }

  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("C", 7);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toPORT_INFO");
  }

  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toPORT_INFO");
  }

  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toESD_ENABLES_AND_ACTION");
  }

  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 85)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toTORQUE_LIMIT");
  }
$ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 75)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMPA_PORT_CAL_DATA");
  }
$ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 75)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMPA_PORT_CAL_DATA");
  }
$ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 75)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 3, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMPA_PORT_CAL_DATA");
  }
$ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 75)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMPA_PORT_CAL_DATA");
  }
$ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 75)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMPA_PORT_CAL_DATA");
  }
$ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 75)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 6, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMPA_PORT_CAL_DATA");
  }
$ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 75)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 7, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMPA_PORT_CAL_DATA");
  }
$ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack("V", pack("f", 75)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 8, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMPA_PORT_CAL_DATA");
  }
  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ACTUATOR_COMMAND value");
  }   
  
  $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $i_integer = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to SETPOINT value");
  } 

  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 50)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toDEFAULT_SETPOINT");
  }   
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 60)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toDEFAULT_SETPOINT");
  }   
#======================================================Power Cycle=====================================================================================
  my $o_RBRestartParamInfo = $o_RBInfo->get_param_info("RESTART");
  my $s_ProcRestart = pack("C", RESTART_WITH_PROCESSOR);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId,$o_RBInfo->od_index + $o_RBRestartParamInfo->parameter_index,0,length($s_ProcRestart),$s_ProcRestart);

  ff_tools::hostapi::api::Abort($i_DutFbapVcrId,   ABORT_REASON);
  ff_tools::hostapi::api::Abort($i_DutMibVcrId,    ABORT_REASON);
  ff_tools::hostapi::api::WaitForInd($ff_tools::hostapi::SERVICE_CODE_SM_NEW_NODE_EVENT, 1000);
  ff_tools::hostapi::api::Initiate($i_DutFbapVcrId,  OD_VERSION, MIB_PROFILE_NO);
  ff_tools::hostapi::api::Initiate($i_DutMibVcrId, OD_VERSION, FBAP_PROFILE_NO);
#=======================================================================================================================================================
 }
 sub Run() 
 { 
 

  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0);
  my $i_STRATEGY = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_STRATEGY != $o_STRATEGYInfo->test_value)
  {
    print("\n-> Test FAILED :Parameter STRATEGY Could not Retain value");
  }

  $o_ALERT_KEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT_KEYInfo->parameter_index, 0);
  my $i_ALERT_KEY = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ALERT_KEY!= $o_ALERT_KEYInfo->test_value)
  {
    print("\n-> Test FAILED :Parameter ALERT_KEY Could not Retain value");
  }

  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0);
  my $i_CONTROL_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_MODE != $o_CONTROL_MODEInfo->test_value)
  {
    print("\n-> Test FAILED :Parameter CONTROL_MODE Could not Retain value");
  }

  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0);
  my $i_ACTUATOR_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ACTUATOR_MODE == $o_ACTUATOR_MODEInfo->test_value)
  {
    print("\n-> Test FAILED :Dynamic Parameter ACTUATOR_MODE Could Retain value");
  }

  $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0);
  my $i_CONFIGURATION_COMMANDS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONFIGURATION_COMMANDS == $o_CONFIGURATION_COMMANDSInfo->test_value)
  {
    print("\n-> Test FAILED :Dynamic Parameter CONFIGURATION_COMMANDS Could Retain value");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6);
  my $i_CONTROL_PARAM_1 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_1 != 1)
  {
    print("\n-> Test FAILED :Parameter CONTROL_PARAM_1 Could not Retain value");
  }

  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 3);
  my $i_CONTROL_PARAM_2 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_2 != 1)
  {
    print("\n-> Test FAILED :Parameter CONTROL_PARAM_2 Could not Retain value");
  }

  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 2);
  my $i_ACTUATOR_COMMAND = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ACTUATOR_COMMAND != 0)
  {
    print("\n-> Test FAILED :Parameter ACTUATOR_COMMAND Could not Retain value");
  }

  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 2);
  my $i_HOST_COMMAND_ESD = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_HOST_COMMAND_ESD != 1)
  {
    print("\n-> Test FAILED :Parameter HOST_COMMAND_ESD Could not Retain value");
  }

  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1);
  my $i_PORT_INFO = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_PORT_INFO != 7)
  {
    print("\n-> Test FAILED :Parameter PORT_INFO Could not Retain value");
  }

  $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2);
   $i_PORT_INFO = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_PORT_INFO != 1)
  {
    print("\n-> Test FAILED :Parameter PORT_INFO Could not Retain value");
  }

  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2);
  my $i_ESD_ENABLES_AND_ACTION = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ESD_ENABLES_AND_ACTION != 3)
  {
    print("\n-> Test FAILED :Parameter ESD_ENABLES_AND_ACTION Could not Retain value");
  }

  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1);
  my $i_DEFAULT_SETPOINT = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_DEFAULT_SETPOINT != 50)
  {
    print("\n-> Test FAILED :Parameter DEFAULT_SETPOINT Could not Retain value");
  }

  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 2);
   $i_DEFAULT_SETPOINT = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_DEFAULT_SETPOINT != 60)
  {
    print("\n-> Test FAILED :Parameter DEFAULT_SETPOINT Could not Retain value");
  }

  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2);
  my $i_TORQUE_LIMIT = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_TORQUE_LIMIT != 85)
  {
    print("\n-> Test FAILED :Parameter TORQUE_LIMIT Could not Retain value");
  }

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 1);
  my $i_MPA_PORT_CAL_DATA = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_MPA_PORT_CAL_DATA != 75)
  {
    print("\n-> Test FAILED :Parameter MPA_PORT_CAL_DATA Could not Retain value");
  }

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 2);
   $i_MPA_PORT_CAL_DATA = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_MPA_PORT_CAL_DATA != 75)
  {
    print("\n-> Test FAILED :Parameter MPA_PORT_CAL_DATA Could not Retain value");
  }

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 3);
   $i_MPA_PORT_CAL_DATA = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_MPA_PORT_CAL_DATA != 75)
  {
    print("\n-> Test FAILED :Parameter MPA_PORT_CAL_DATA Could not Retain value");
  }

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 4);
   $i_MPA_PORT_CAL_DATA = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_MPA_PORT_CAL_DATA != 75)
  {
    print("\n-> Test FAILED :Parameter MPA_PORT_CAL_DATA Could not Retain value");
  }

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 5);
   $i_MPA_PORT_CAL_DATA = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_MPA_PORT_CAL_DATA != 75)
  {
    print("\n-> Test FAILED :Parameter MPA_PORT_CAL_DATA Could not Retain value");
  }

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 6);
   $i_MPA_PORT_CAL_DATA = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_MPA_PORT_CAL_DATA!= 75)
  {
    print("\n-> Test FAILED :Parameter MPA_PORT_CAL_DATA Could not Retain value");
  }

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 7);
   $i_MPA_PORT_CAL_DATA = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_MPA_PORT_CAL_DATA != 75)
  {
    print("\n-> Test FAILED :Parameter MPA_PORT_CAL_DATA Could not Retain value");
  }

  $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 8);
   $i_MPA_PORT_CAL_DATA = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_MPA_PORT_CAL_DATA != 75)
  {
    print("\n-> Test FAILED :Parameter MPA_PORT_CAL_DATA Could not Retain value");
  }

  $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 2);
  my $i_SETPOINT = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
  if ($i_SETPOINT != 100)
  {
    print("\n-> Test FAILED :Parameter SETPOINT Could not Retain value");
  }
  }
  
  
sub Teardown()
{
  Log("Teardown ADVT test script....");
}  