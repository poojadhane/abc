#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify that ST_REV incremented if any of the TB block Static parameter is written with
 #          same value or changed and ST_REV do not increment if Dynamic or Non-Volatile parameter is changed.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;
 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $stRev_Temp;
 my $i_integer;
 my $f_float;
 my $i_StatRev;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = 1200; #ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex = 1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "MPA";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_MPA.xls");
     
  } 
  sub Run() 
 { 
 
   my $o_StatRevInfo = $o_TBInfo->get_param_info("ST_REV");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
  $stRev_Temp = $i_StatRev; 

 my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->test_value);
 $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in STRATEGY");
  }
  $stRev_Temp = $i_StatRev; 

 my $o_ALERT_KEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("C", $o_ALERT_KEYInfo->test_value);
$rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT_KEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in ALERT_KEY");
  }
  $stRev_Temp = $i_StatRev; 

 my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->test_value);
$rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in CONTROL_MODE");
  }
  $stRev_Temp = $i_StatRev; 



 my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->test_value);
 $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  != $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV incremented for change in ACTUATOR_MODE");
  }
  $stRev_Temp = $i_StatRev; 

 my $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
  $i_integer = pack("C", $o_CONFIGURATION_COMMANDSInfo->test_value);
 $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  != $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV incremented for change in CONFIGURATION_COMMANDS");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C",1 );
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6 , length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in CONTROL_PARAM_1  JOG_CONTROL");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C",1 );
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 3 , length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in CONTROL_PARAM_2 DISPLAY_LOW_POWER_MODE");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C",1 );
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 2 , length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in HOST_COMMAND_ESD VALUE");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("C",7 );
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1 , length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in PORT_INFO USER_HOME_PORT");
  }
  $stRev_Temp = $i_StatRev; 

   $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("C",1 );
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2 , length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in PORT_INFO HOME_PORT_LABEL");
  }
  $stRev_Temp = $i_StatRev; 
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;
   $o_PORT_INFOInfo = $o_TBInfo->get_param_info("PORT_INFO");
  $i_integer = pack("n",2 );
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 4 , length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in PORT_INFO DISABLE_PORTS");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("C",3 );
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2 , length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in ESD_ACTION");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack ("V", pack ("f",85 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in TORQUE_LIMIT OPEN_TORQUE_LIMIT");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack ("V", pack ("f",75 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 1 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in MPA_PORT_CAL_DATA Home_Port_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

   $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack ("V", pack ("f",75 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 2 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in MPA_PORT_CAL_DATA Port_1_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

   $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack ("V", pack ("f",75 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 3 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in MPA_PORT_CAL_DATA Port_2_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

   $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack ("V", pack ("f",75 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 4 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in MPA_PORT_CAL_DATA Port_3_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

   $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack ("V", pack ("f",75 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 5 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in MPA_PORT_CAL_DATA Port_4_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

   $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack ("V", pack ("f",75 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 6 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in MPA_PORT_CAL_DATA Port_5_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

   $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack ("V", pack ("f",75 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 7 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in MPA_PORT_CAL_DATA Port_6_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

   $o_MPA_PORT_CAL_DATAInfo = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  $f_float = pack("N", unpack ("V", pack ("f",75 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 8 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  <= $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV could not incremented for change in MPA_PORT_CAL_DATA Port_7_Calibration");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("C",0 );
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 2 , length($i_integer) ,$i_integer);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  != $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV incremented for change in ACTUATOR_COMMAND VALUE");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack ("V", pack ("f",87 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  != $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV incremented for change in DEFAULT_SETPOINT_1");
  }
  $stRev_Temp = $i_StatRev; 

   $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack ("V", pack ("f",17 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 2 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  != $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV incremented for change in DEFAULT_SETPOINT_2");
  }
  $stRev_Temp = $i_StatRev; 

  my $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $f_float = pack("N", unpack ("V", pack ("f",100 )));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 2 , length($f_float) ,$f_float);
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
   $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev  != $stRev_Temp)
  {
   print("\n-> Test FAILED :ST_REV incremented for change in SETPOINT VALUE");
  }
  $stRev_Temp = $i_StatRev; 
}
sub Teardown()
{
  Log("Teardown ADVT test script....");
}