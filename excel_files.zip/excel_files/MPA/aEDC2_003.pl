#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify that each MPA actuator block parameters are initialized with an initial value defined
 #          in Parameter Table when RESTART with Defaults parameter in resource Blocks is selected.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;
 use blk_parameter::DS_69;
 use blk_parameter::DS_73;
 use blk_parameter::DS_72;
 use blk_parameter::DS_256;
 use blk_parameter::DS_258;
 use blk_parameter::DS_260;
 use blk_parameter::DS_66;
 use blk_parameter::DS_261;
 use blk_parameter::Array_1;
 use blk_parameter::Array_2;
 use blk_parameter::DS_263;
 use blk_parameter::DS_264;
 use blk_parameter::DS_265;
 use blk_parameter::DS_266;
 use blk_parameter::DS_267;
 use blk_parameter::DS_259;
 use blk_parameter::DS_268;
 use blk_parameter::DS_269;
 use blk_parameter::DS_270;
 use blk_parameter::DS_271;
 use blk_parameter::DS_272;
 use blk_parameter::DS_65;
 use blk_parameter::DS_68;
 use constant RESTART_WITH_DEFAULT               => 3;
 use constant MIB_PROFILE_NO                     => 0x4D47;
 use constant FBAP_PROFILE_NO                    => 0;
 use constant OD_VERSION                         => 1;
 use constant ABORT_REASON                       => 0x01;
 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
#================================== Test case =================================#
sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex = ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("RB_DB.xls");
     
   $o_TBInfo->blk_name = "MPA";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("MPA_DB.xls");
     
   my $o_RBRestartParamInfo = $o_RBInfo->get_param_info("RESTART"); 
   my $s_ProcRestart = pack("C", RESTART_WITH_DEFAULT);
   ff_tools::hostapi::api::Write($i_DutFbapVcrId,$o_RBInfo->od_index + $o_RBRestartParamInfo->parameter_index,0,length($s_ProcRestart),$s_ProcRestart);
   ff_tools::hostapi::api::Abort($i_DutFbapVcrId,   ABORT_REASON);
   ff_tools::hostapi::api::Abort($i_DutMibVcrId,    ABORT_REASON);
   
   ff_tools::hostapi::api::WaitForInd($ff_tools::hostapi::SERVICE_CODE_SM_NEW_NODE_EVENT, 1000);
 
   ff_tools::hostapi::api::Initiate($i_DutFbapVcrId,  OD_VERSION, MIB_PROFILE_NO);
   ff_tools::hostapi::api::Initiate($i_DutMibVcrId, OD_VERSION, FBAP_PROFILE_NO);
 }
 sub Run() 
 { 
 
   my $o_ST REV= $o_TBInfo->get_param_info("ST REV"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ST REV->parameter_index, 0);
   my  $i_ST REV = unpack("n", $rh_Result->{"Confirm"}->Data);
   if ($i_ST REV != $o_ST REV->default_value)
   {
     fail("Wrong default value for ST REV"); 

   }


   my $o_TAG DESC= $o_TBInfo->get_param_info("TAG DESC"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TAG DESC->parameter_index, 0);
   my  $i_TAG DESC = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_TAG DESC != $o_TAG DESC->default_value)
   {
     fail("Wrong default value for TAG DESC"); 

   }


   my $o_STRATEGY= $o_TBInfo->get_param_info("STRATEGY"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGY->parameter_index, 0);
   my  $i_STRATEGY = unpack("n", $rh_Result->{"Confirm"}->Data);
   if ($i_STRATEGY != $o_STRATEGY->default_value)
   {
     fail("Wrong default value for STRATEGY"); 

   }


   my $o_ALERT KEY= $o_TBInfo->get_param_info("ALERT KEY"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT KEY->parameter_index, 0);
   my  $i_ALERT KEY = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ALERT KEY != $o_ALERT KEY->default_value)
   {
     fail("Wrong default value for ALERT KEY"); 

   }


   my $o_FIRMWARE_DATE= $o_TBInfo->get_param_info("FIRMWARE_DATE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_DATE->parameter_index, 0);
   my  $i_FIRMWARE_DATE = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_FIRMWARE_DATE != $o_FIRMWARE_DATE->default_value)
   {
     fail("Wrong default value for FIRMWARE_DATE"); 

   }


   my $o_FF_FUNCTION_TYPE= $o_TBInfo->get_param_info("FF_FUNCTION_TYPE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FF_FUNCTION_TYPE->parameter_index, 0);
   my  $i_FF_FUNCTION_TYPE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_FF_FUNCTION_TYPE != $o_FF_FUNCTION_TYPE->default_value)
   {
     fail("Wrong default value for FF_FUNCTION_TYPE"); 

   }


   my $o_COMPATIBILITY_NUMBER= $o_TBInfo->get_param_info("COMPATIBILITY_NUMBER"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_COMPATIBILITY_NUMBER->parameter_index, 0);
   my  $i_COMPATIBILITY_NUMBER = unpack("n", $rh_Result->{"Confirm"}->Data);
   if ($i_COMPATIBILITY_NUMBER != $o_COMPATIBILITY_NUMBER->default_value)
   {
     fail("Wrong default value for COMPATIBILITY_NUMBER"); 

   }


   my $o_CONTROL_MODE= $o_TBInfo->get_param_info("CONTROL_MODE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODE->parameter_index, 0);
   my  $i_CONTROL_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_CONTROL_MODE != $o_CONTROL_MODE->default_value)
   {
     fail("Wrong default value for CONTROL_MODE"); 

   }


   my $o_ACTUATOR_MODE= $o_TBInfo->get_param_info("ACTUATOR_MODE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODE->parameter_index, 0);
   my  $i_ACTUATOR_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ACTUATOR_MODE != $o_ACTUATOR_MODE->default_value)
   {
     fail("Wrong default value for ACTUATOR_MODE"); 

   }


   my $o_FIELD_DIAGNOSTIC_CODE= $o_TBInfo->get_param_info("FIELD_DIAGNOSTIC_CODE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIELD_DIAGNOSTIC_CODE->parameter_index, 0);
   my  $i_FIELD_DIAGNOSTIC_CODE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_FIELD_DIAGNOSTIC_CODE != $o_FIELD_DIAGNOSTIC_CODE->default_value)
   {
     fail("Wrong default value for FIELD_DIAGNOSTIC_CODE"); 

   }


   my $o_MAXIMUM_TORQUE= $o_TBInfo->get_param_info("MAXIMUM_TORQUE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUE->parameter_index, 0);
   my  $f_MAXIMUM_TORQUE = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_MAXIMUM_TORQUE != $o_MAXIMUM_TORQUE->default_value)
   {
     fail("Wrong default value for MAXIMUM_TORQUE"); 

   }


   my $o_CONFIGURATION_COMMANDS= $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDS->parameter_index, 0);
   my  $i_CONFIGURATION_COMMANDS = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_CONFIGURATION_COMMANDS != $o_CONFIGURATION_COMMANDS->default_value)
   {
     fail("Wrong default value for CONFIGURATION_COMMANDS"); 

   }


   my $o_CONTROL_PARAM_1Info= $o_TBInfo->get_param_info("CONTROL_PARAM_1"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 6);
   my  $i_JOG_CONTROL = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_JOG_CONTROL != 1)
 
   {
     fail("Wrong default value for JOG_CONTROL"); 

   }


   my $o_CONTROL_PARAM_2Info= $o_TBInfo->get_param_info("CONTROL_PARAM_2"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 3);
   my  $i_DISPLAY_LOW_POWER_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISPLAY_LOW_POWER_MODE != 1)
 
   {
     fail("Wrong default value for DISPLAY_LOW_POWER_MODE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 1);
   my  $i_VOLTAGE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_VOLTAGE != 460)
 
   {
     fail("Wrong default value for VOLTAGE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 3);
   my  $i_THREE_PHASE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_THREE_PHASE != 1)
 
   {
     fail("Wrong default value for THREE_PHASE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 5);
   my  $i_NETWORK_ADAPTER = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_NETWORK_ADAPTER != 7)
 
   {
     fail("Wrong default value for NETWORK_ADAPTER"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 8);
   my  $i_MOTOR_TYPE_MOTOR = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_MOTOR_TYPE_MOTOR != 0x20202020202020202020)
 
   {
     fail("Wrong default value for MOTOR_TYPE_MOTOR"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 9);
   my  $i_HORSE_POWER = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_HORSE_POWER != 0x2020202020)
 
   {
     fail("Wrong default value for HORSE_POWER"); 

   }


   my $o_PORT_INFOInfo= $o_TBInfo->get_param_info("PORT_INFO"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 1);
   my  $i_USER_HOME_PORT = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_USER_HOME_PORT != 0)
 
   {
     fail("Wrong default value for USER_HOME_PORT"); 

   }


   my $o_PORT_INFOInfo= $o_TBInfo->get_param_info("PORT_INFO"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 2);
   my  $i_HOME_PORT_LABEL = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_HOME_PORT_LABEL != 0)
 
   {
     fail("Wrong default value for HOME_PORT_LABEL"); 

   }


   my $o_PORT_INFOInfo= $o_TBInfo->get_param_info("PORT_INFO"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 3);
   my  $i_NUMBER_OF_PORTS = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_NUMBER_OF_PORTS != 8)
 
   {
     fail("Wrong default value for NUMBER_OF_PORTS"); 

   }


   my $o_PORT_INFOInfo= $o_TBInfo->get_param_info("PORT_INFO"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PORT_INFOInfo->parameter_index, 4);
   my  $i_DISABLE_PORTS = unpack("n", $rh_Result->{"Confirm"}->Data);
   if ($i_DISABLE_PORTS != 0)
 
   {
     fail("Wrong default value for DISABLE_PORTS"); 

   }


   my $o_TORQUE_LIMITInfo= $o_TBInfo->get_param_info("TORQUE_LIMIT"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2);
   my  $f_OPEN_TORQUE_LIMIT = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_OPEN_TORQUE_LIMIT != 77)
 
   {
     fail("Wrong default value for OPEN_TORQUE_LIMIT"); 

   }


   my $o_MPA_PORT_CAL_DATAInfo= $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 1);
   my  $f_HOME_PORT_CALIBRATION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_HOME_PORT_CALIBRATION != 0)
 
   {
     fail("Wrong default value for HOME_PORT_CALIBRATION"); 

   }


   my $o_MPA_PORT_CAL_DATAInfo= $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 2);
   my  $f_PORT_1_CALIBRATION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_PORT_1_CALIBRATION != 512)
 
   {
     fail("Wrong default value for PORT_1_CALIBRATION"); 

   }


   my $o_MPA_PORT_CAL_DATAInfo= $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 3);
   my  $f_PORT_2_CALIBRATION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_PORT_2_CALIBRATION != 1024)
 
   {
     fail("Wrong default value for PORT_2_CALIBRATION"); 

   }


   my $o_MPA_PORT_CAL_DATAInfo= $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 4);
   my  $f_PORT_3_CALIBRATION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_PORT_3_CALIBRATION != 1536)
 
   {
     fail("Wrong default value for PORT_3_CALIBRATION"); 

   }


   my $o_MPA_PORT_CAL_DATAInfo= $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 5);
   my  $f_PORT_4_CALIBRATION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_PORT_4_CALIBRATION != 2048)
 
   {
     fail("Wrong default value for PORT_4_CALIBRATION"); 

   }


   my $o_MPA_PORT_CAL_DATAInfo= $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 6);
   my  $f_PORT_5_CALIBRATION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_PORT_5_CALIBRATION != 2560)
 
   {
     fail("Wrong default value for PORT_5_CALIBRATION"); 

   }


   my $o_MPA_PORT_CAL_DATAInfo= $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 7);
   my  $f_PORT_6_CALIBRATION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_PORT_6_CALIBRATION != 3072)
 
   {
     fail("Wrong default value for PORT_6_CALIBRATION"); 

   }


   my $o_MPA_PORT_CAL_DATAInfo= $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MPA_PORT_CAL_DATAInfo->parameter_index, 8);
   my  $f_PORT_7_CALIBRATION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_PORT_7_CALIBRATION != 3584)
 
   {
     fail("Wrong default value for PORT_7_CALIBRATION"); 

   }


}


sub Teardown()
{
  Log("Teardown ADVT test script....");
}