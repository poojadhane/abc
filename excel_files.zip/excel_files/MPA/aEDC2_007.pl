#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify that TB block static parameters should not be writable if the device is locked using software write lock as defined in 
 #          parameter table.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;
 use blk_parameter::DS_69;
 use blk_parameter::DS_73;
 use blk_parameter::DS_72;
 use blk_parameter::DS_66;
 use blk_parameter::Array_1;
 use blk_parameter::Array_2;
 use blk_parameter::DS_65;
 use blk_parameter::DS_68;
 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $i_actmode;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex = ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "MPA";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE.xls");
     
}
 sub Run() 
 { 
 

      my $o_MAXIMUM__HYDRAULIC_CIRCUIT_PRESSUREInfo = $o_TBInfo->get_param_info("MAXIMUM__HYDRAULIC_CIRCUIT_PRESSURE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM__HYDRAULIC_CIRCUIT_PRESSUREInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to MAXIMUM__HYDRAULIC_CIRCUIT_PRESSURE");
      }
      $f_float = pack("f", $o_MAXIMUM__HYDRAULIC_CIRCUIT_PRESSUREInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM__HYDRAULIC_CIRCUIT_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to MAXIMUM__HYDRAULIC_CIRCUIT_PRESSURE");
      }

      my $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo = $o_TBInfo->get_param_info("MAXIMUM_SELF_CALIBRATION_PRESSURE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to MAXIMUM_SELF_CALIBRATION_PRESSURE");
      }
      $f_float = pack("f", $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to MAXIMUM_SELF_CALIBRATION_PRESSURE");
      }

      my $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo = $o_TBInfo->get_param_info("SELF_CALIBRATION_STROKE_COUNT_RANGE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to SELF_CALIBRATION_STROKE_COUNT_RANGE");
      }
      $i_integer = pack("C", $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to SELF_CALIBRATION_STROKE_COUNT_RANGE");
      }

      my $o_ACTUATOR_FULLY_OPEN_TIMEInfo = $o_TBInfo->get_param_info("ACTUATOR_FULLY_OPEN_TIME");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_FULLY_OPEN_TIMEInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ACTUATOR_FULLY_OPEN_TIME");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_FULLY_OPEN_TIMEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ACTUATOR_FULLY_OPEN_TIME");
      }

      my $o_ACTUATOR_FULLY_CLOSE_TIMEInfo = $o_TBInfo->get_param_info("ACTUATOR_FULLY_CLOSE_TIME");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_FULLY_CLOSE_TIMEInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ACTUATOR_FULLY_CLOSE_TIME");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_FULLY_CLOSE_TIMEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ACTUATOR_FULLY_CLOSE_TIME");
      }

      my $o_CUSTOM_CHARACTERIZATION_TYPEInfo = $o_TBInfo->get_param_info("CUSTOM_CHARACTERIZATION_TYPE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CUSTOM_CHARACTERIZATION_TYPEInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to CUSTOM_CHARACTERIZATION_TYPE");
      }
      $i_integer = pack("C", $o_CUSTOM_CHARACTERIZATION_TYPEInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CUSTOM_CHARACTERIZATION_TYPEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to CUSTOM_CHARACTERIZATION_TYPE");
      }

      my $o_TARGET_TRAVELInfo = $o_TBInfo->get_param_info("TARGET_TRAVEL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TARGET_TRAVELInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to TARGET_TRAVEL");
      }
      $i_integer = pack("C", $o_TARGET_TRAVELInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TARGET_TRAVELInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to TARGET_TRAVEL");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

      my $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ESD_DELAY");
      }
      $i_integer = pack("C", $o_ESD_DELAYInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ESD_DELAY");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

      my $o_STROKE_TIMEInfo = $o_TBInfo->get_param_info("STROKE_TIME");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIMEInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to STROKE_TIME");
      }
      $i_integer = pack("n", $o_STROKE_TIMEInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIMEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to STROKE_TIME");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

      my $o_ENABLE_ACCUMULATORInfo = $o_TBInfo->get_param_info("ENABLE_ACCUMULATOR");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_ACCUMULATORInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_ACCUMULATOR");
      }
      $i_integer = pack("C", $o_ENABLE_ACCUMULATORInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_ACCUMULATORInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_ACCUMULATOR");
      }

      my $o_TORQUE_OUT_OF_RANGEInfo = $o_TBInfo->get_param_info("TORQUE_OUT_OF_RANGE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_OUT_OF_RANGEInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to TORQUE_OUT_OF_RANGE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_OUT_OF_RANGEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to TORQUE_OUT_OF_RANGE");
      }

      my $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALVE_STALL_DELAY_TIME");
      }
      $f_float = pack("f", $o_VALVE_STALL_DELAY_TIMEInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALVE_STALL_DELAY_TIME");
      }

      my $o_SELF_CALIBRATION_STATUSInfo = $o_TBInfo->get_param_info("SELF_CALIBRATION_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STATUSInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to SELF_CALIBRATION_STATUS");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STATUSInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to SELF_CALIBRATION_STATUS");
      }

      my $o_PRESSURE_UNITInfo = $o_TBInfo->get_param_info("PRESSURE_UNIT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PRESSURE_UNITInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to PRESSURE_UNIT");
      }
      $i_integer = pack("C", $o_PRESSURE_UNITInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PRESSURE_UNITInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to PRESSURE_UNIT");
      }

      my $o_OPEN_TORQUE_PROFILEInfo = $o_TBInfo->get_param_info("OPEN_TORQUE_PROFILE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_TORQUE_PROFILEInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to OPEN_TORQUE_PROFILE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_TORQUE_PROFILEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to OPEN_TORQUE_PROFILE");
      }

      my $o_CLOSE_TORQUE_PROFILEInfo = $o_TBInfo->get_param_info("CLOSE_TORQUE_PROFILE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_TORQUE_PROFILEInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to CLOSE_TORQUE_PROFILE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_TORQUE_PROFILEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to CLOSE_TORQUE_PROFILE");
      }

      my $o_ARCHIVED_OPEN_TORQUE_PROFILEInfo = $o_TBInfo->get_param_info("ARCHIVED_OPEN_TORQUE_PROFILE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ARCHIVED_OPEN_TORQUE_PROFILEInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ARCHIVED_OPEN_TORQUE_PROFILE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ARCHIVED_OPEN_TORQUE_PROFILEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ARCHIVED_OPEN_TORQUE_PROFILE");
      }

      my $o_ARCHIVED_CLOSE_TORQUE_PROFILEInfo = $o_TBInfo->get_param_info("ARCHIVED_CLOSE_TORQUE_PROFILE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ARCHIVED_CLOSE_TORQUE_PROFILEInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ARCHIVED_CLOSE_TORQUE_PROFILE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ARCHIVED_CLOSE_TORQUE_PROFILEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ARCHIVED_CLOSE_TORQUE_PROFILE");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

      my $o_LANGUAGE_SELECTIONInfo = $o_TBInfo->get_param_info("LANGUAGE_SELECTION");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LANGUAGE_SELECTIONInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LANGUAGE_SELECTION");
      }
      $i_integer = pack("C", $o_LANGUAGE_SELECTIONInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LANGUAGE_SELECTIONInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LANGUAGE_SELECTION");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

      my $o_ENABLE_SELF_CALIBRATIONInfo = $o_TBInfo->get_param_info("ENABLE_SELF_CALIBRATION");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_SELF_CALIBRATIONInfo->parameter_index, 0);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_SELF_CALIBRATION");
      }
      $i_integer = pack("C", $o_ENABLE_SELF_CALIBRATIONInfo->test_value)
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_SELF_CALIBRATIONInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_SELF_CALIBRATION");
      }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_LOG_JAM");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_LOG_JAM");
      }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to REMOTE_CONTROL_SIGNAL");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to REMOTE_CONTROL_SIGNAL");
      }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LOCAL_CONTROL_SIGNAL");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LOCAL_CONTROL_SIGNAL");
      }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to BACKSEAT");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to BACKSEAT");
      }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to SEATING");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to SEATING");
      }

    my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LED_COLOR");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LED_COLOR");
      }

    my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_LOW_BATTERY_ALARM");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_LOW_BATTERY_ALARM");
      }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to POSITION_CONTROL_BANDWIDTH");
      }
      $f_float = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to POSITION_CONTROL_BANDWIDTH");
      }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to SPEED_CONTROL_BANDWIDTH");
      }
      $f_float = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to SPEED_CONTROL_BANDWIDTH");
      }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to MODULATION_DELAY");
      }
      $f_float = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to MODULATION_DELAY");
      }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LOST_ANALOG_INPUT_ACTION");
      }
      $i_integer = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LOST_ANALOG_INPUT_ACTION");
      }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_LOST_ANALOG_INPUT_1_ALARM");
      }
      $i_integer = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_LOST_ANALOG_INPUT_1_ALARM");
      }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_LOST_ANALOG_INPUT_2_ALARM");
      }
      $i_integer = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_LOST_ANALOG_INPUT_2_ALARM");
      }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ANALOG_OUTPUT_1_SOURCE");
      }
      $i_integer = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ANALOG_OUTPUT_1_SOURCE");
      }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ANALOG_OUTPUT_2_SOURCE");
      }
      $i_integer = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ANALOG_OUTPUT_2_SOURCE");
      }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LOST_ANALOG_INPUT_2_ACTION");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LOST_ANALOG_INPUT_2_ACTION");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to FREQUENCY");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to FREQUENCY");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to AUXILIARY_CONTROL_MODULE_(ACM)");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to AUXILIARY_CONTROL_MODULE_(ACM)");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 6);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to STARTER_TYPE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to STARTER_TYPE");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 7);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to TORQUE_SPRING");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 7, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to TORQUE_SPRING");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 10);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RPM");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 10, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RPM");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 11);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RUNNING_AMPS");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 11, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RUNNING_AMPS");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 12);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to STALLED_AMPS");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 12, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to STALLED_AMPS");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 13);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to WORM_GEAR");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 13, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to WORM_GEAR");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 14);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DRIVE_SLEEVE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 14, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DRIVE_SLEEVE");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 15);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_AUXILIARY_RELAY_MODULE_(ARM)");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 15, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_AUXILIARY_RELAY_MODULE_(ARM)");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 16);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_REVERSE_MOTOR_ROTATION");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 16, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_REVERSE_MOTOR_ROTATION");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 17);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ACTUATOR_TYPE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 17, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ACTUATOR_TYPE");
      }

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 18);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to APD_GEAR_RATIO");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 18, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to APD_GEAR_RATIO");
      }

    my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

    my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      $i_integer = pack("n", 2);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LIMIT_SWITCH_OPEN");
      }
      $f_float = pack("n", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 3, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LIMIT_SWITCH_OPEN");
      }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LIMIT_SWITCH_CLOSE");
      }
      $f_float = pack("n", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 4, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LIMIT_SWITCH_CLOSE");
      }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LIMIT_SWITCH_A_TRIGGER_POINT");
      }
      $f_float = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LIMIT_SWITCH_A_TRIGGER_POINT");
      }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LIMIT_SWITCH_B_TRIGGER_POINT");
      }
      $f_float = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LIMIT_SWITCH_B_TRIGGER_POINT");
      }

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_FUNCTIONS0");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS0");
      }

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_FUNCTIONS1");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS1");
      }

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_FUNCTIONS2");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS2");
      }

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_FUNCTIONS3");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS3");
      }

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 5);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_FUNCTIONS4");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS4");
      }

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 6);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_FUNCTIONS5");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS5");
      }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RELAY_SETTINGS0");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RELAY_SETTINGS0");
      }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RELAY_SETTINGS1");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RELAY_SETTINGS1");
      }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RELAY_SETTINGS2");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RELAY_SETTINGS2");
      }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RELAY_SETTINGS3");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RELAY_SETTINGS3");
      }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RELAY_SETTINGS4");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RELAY_SETTINGS4");
      }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RELAY_FUNCTIONS0");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RELAY_FUNCTIONS0");
      }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RELAY_FUNCTIONS1");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RELAY_FUNCTIONS1");
      }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RELAY_FUNCTIONS2");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RELAY_FUNCTIONS2");
      }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RELAY_FUNCTIONS3");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RELAY_FUNCTIONS3");
      }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to RELAY_FUNCTIONS4");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to RELAY_FUNCTIONS4");
      }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ON_TIME");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ON_TIME");
      }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to OFF_TIME");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to OFF_TIME");
      }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ON_TIME");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ON_TIME");
      }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to OFF_TIME");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to OFF_TIME");
      }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to START_POSITION");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to START_POSITION");
      }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to STOP_POSITION");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to STOP_POSITION");
      }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 6);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DUTY_CYCLE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DUTY_CYCLE");
      }

    my $o_PST_PARAMETERSInfo = $o_TBInfo->get_param_info("PST_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to START_POSITION");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to START_POSITION");
      }

    my $o_PST_PARAMETERSInfo = $o_TBInfo->get_param_info("PST_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to END_POSITION");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to END_POSITION");
      }

    my $o_PST_PARAMETERSInfo = $o_TBInfo->get_param_info("PST_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to TRAVEL_LIMIT");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to TRAVEL_LIMIT");
      }

    my $o_PST_PARAMETERSInfo = $o_TBInfo->get_param_info("PST_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to PAUSE_TIME");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to PAUSE_TIME");
      }

    my $o_ACCESS_PRIVILLEGEInfo = $o_TBInfo->get_param_info("ACCESS_PRIVILLEGE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCESS_PRIVILLEGEInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ACCESS_PRIVILLEGE_1");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCESS_PRIVILLEGEInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ACCESS_PRIVILLEGE_1");
      }

    my $o_ACCESS_PRIVILLEGEInfo = $o_TBInfo->get_param_info("ACCESS_PRIVILLEGE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCESS_PRIVILLEGEInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ACCESS_PRIVILLEGE_2");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCESS_PRIVILLEGEInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ACCESS_PRIVILLEGE_2");
      }

    my $o_ACCESS_PRIVILLEGEInfo = $o_TBInfo->get_param_info("ACCESS_PRIVILLEGE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCESS_PRIVILLEGEInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ACCESS_PRIVILLEGE_3");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCESS_PRIVILLEGEInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ACCESS_PRIVILLEGE_3");
      }

    my $o_ACCESS_PRIVILLEGEInfo = $o_TBInfo->get_param_info("ACCESS_PRIVILLEGE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCESS_PRIVILLEGEInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ACCESS_PRIVILLEGE_4");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCESS_PRIVILLEGEInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ACCESS_PRIVILLEGE_4");
      }

      my $o_ESD_PARAMSInfo = $o_TBInfo->get_param_info("ESD_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_PARAMSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to PST_STATUS");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_PARAMSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to PST_STATUS");
      }

      my $o_ESD_PARAMSInfo = $o_TBInfo->get_param_info("ESD_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_PARAMSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ESD_STATUS");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_PARAMSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ESD_STATUS");
      }

      my $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      $i_integer = pack("C", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_ANALOG_OUTPUT_2Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_2Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      $i_integer = pack("C", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_2Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_ANALOG_INPUT_1Info = $o_TBInfo->get_param_info("ANALOG_INPUT_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_INPUT_1Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_INPUT_1Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_ANALOG_INPUT_2Info = $o_TBInfo->get_param_info("ANALOG_INPUT_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_INPUT_2Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_INPUT_2Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_HYDRAULIC_PRESSUREInfo = $o_TBInfo->get_param_info("HYDRAULIC_PRESSURE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HYDRAULIC_PRESSUREInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HYDRAULIC_PRESSUREInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_ACCUMULATOR_PRESSUREInfo = $o_TBInfo->get_param_info("ACCUMULATOR_PRESSURE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCUMULATOR_PRESSUREInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCUMULATOR_PRESSUREInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_DISCRETE_INPUT_1Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_1Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_1Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_DISCRETE_INPUT_2Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_2Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_2Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_DISCRETE_INPUT_3Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_3");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_3Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_3Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_DISCRETE_INPUT_4Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_4");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_4Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_4Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_DISCRETE_INPUT_5Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_5");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_5Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_5Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_DISCRETE_INPUT_6Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_6");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_6Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_6Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      $i_integer = pack("C", NA);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      $i_integer = pack("C", NA);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_RELAY_3_STATUSInfo = $o_TBInfo->get_param_info("RELAY_3_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      $i_integer = pack("C", NA);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_RELAY_4_STATUSInfo = $o_TBInfo->get_param_info("RELAY_4_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      $i_integer = pack("C", NA);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }

      my $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to VALUE");
      }
      $i_integer = pack("C", NA);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to VALUE");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_LOG_JAM");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_LOG_JAM");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to REMOTE_CONTROL_SIGNAL");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to REMOTE_CONTROL_SIGNAL");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LOCAL_CONTROL_SIGNAL");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LOCAL_CONTROL_SIGNAL");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to BACKSEAT");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to BACKSEAT");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to SEATING");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to SEATING");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LED_COLOR");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LED_COLOR");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_LOW_BATTERY_ALARM");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_LOW_BATTERY_ALARM");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to POSITION_CONTROL_BANDWIDTH");
      }
      $f_float = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to POSITION_CONTROL_BANDWIDTH");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to SPEED_CONTROL_BANDWIDTH");
      }
      $f_float = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to SPEED_CONTROL_BANDWIDTH");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to MODULATION_DELAY");
      }
      $f_float = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to MODULATION_DELAY");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LOST_ANALOG_INPUT_2_ACTION");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LOST_ANALOG_INPUT_2_ACTION");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LOST_ANALOG_INPUT_ACTION");
      }
      $i_integer = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LOST_ANALOG_INPUT_ACTION");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_LOST_ANALOG_INPUT_1_ALARM");
      }
      $i_integer = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_LOST_ANALOG_INPUT_1_ALARM");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_LOST_ANALOG_INPUT_2_ALARM");
      }
      $i_integer = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_LOST_ANALOG_INPUT_2_ALARM");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ANALOG_OUTPUT_1_SOURCE");
      }
      $i_integer = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ANALOG_OUTPUT_1_SOURCE");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ANALOG_OUTPUT_2_SOURCE");
      }
      $i_integer = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ANALOG_OUTPUT_2_SOURCE");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LIMIT_SWITCH_OPEN");
      }
      $f_float = pack("n", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 3, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LIMIT_SWITCH_OPEN");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LIMIT_SWITCH_CLOSE");
      }
      $f_float = pack("n", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 4, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LIMIT_SWITCH_CLOSE");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LIMIT_SWITCH_A_TRIGGER_POINT");
      }
      $f_float = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LIMIT_SWITCH_A_TRIGGER_POINT");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to LIMIT_SWITCH_B_TRIGGER_POINT");
      }
      $f_float = pack("n", 6);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LIMIT_SWITCH_B_TRIGGER_POINT");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_SETTINGS0");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_SETTINGS0");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_SETTINGS1");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_SETTINGS1");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_SETTINGS2");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_SETTINGS2");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_SETTINGS3");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_SETTINGS3");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 5);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_SETTINGS4");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_SETTINGS4");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 6);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to DISCRETE_INPUT_SETTINGS5");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 6, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_SETTINGS5");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_SPEED_CONTROL");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to START_POSITION");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to START_POSITION");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to STOP_POSITION");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 3, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to STOP_POSITION");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_SPEED_CONTROL");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to START_POSITION");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to START_POSITION");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 3);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to STOP_POSITION");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 3, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to STOP_POSITION");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ENABLE_SPEED_CONTROL");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to ON_TIME");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ON_TIME");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to OFF_TIME");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to OFF_TIME");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_BLUETOOTH_PARAMSInfo = $o_TBInfo->get_param_info("BLUETOOTH_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index, 2);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to BLUETOOTH_NAME");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to BLUETOOTH_NAME");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 4);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to MANUFACTURE_DATE");
      }
      $s_string = pack("n", NA);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 4, length($s_string) ,$s_string);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to MANUFACTURE_DATE");
      }
    my $o_ActuatormodeInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    $i_actmode = pack("n", 3);
    $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ActuatormodeInfo->parameter_index, 0, length($i_actmode) ,$i_actmode);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
        fail("Expected confirm positive for write to Actuator mode setpoint enum");
    }

    my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 1);
      if ($rh_Result->{"Confirm"}->Data != 0)
      {
        fail("Expected zero value for read to CLOSE_TORQUE_LIMIT");
      }
      $f_float = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 1, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to CLOSE_TORQUE_LIMIT");
      }
}


sub Teardown()
{
  Log("Teardown ADVT test script....");
}