#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify RW access each TB block parameter as defined in 
 #          parameter table.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $i_integer;
 my $f_float;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = 1200;
   $i_ResourceBlkIndex = 1000;
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "TEC2000";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE1.xls");
     
}
 sub Run() 
 { 
      my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ACTUATOR_MODE");
      }
      $i_integer = pack("C", $o_ACTUATOR_MODEInfo->test_value);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ACTUATOR_MODE");
      }

      $ff_tools::hostapi::api::InclOnCnfNeg = 0;	  
      my $o_ST_REVInfo = $o_TBInfo->get_param_info("ST_REV");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ST_REVInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ST_REV");
      } 

      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ST_REVInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        print("\n-> Test FAILED :Expected confirm negative for write to ST_REV");
      }	  

      my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to STRATEGY");
      }
      $i_integer = pack("n", $o_STRATEGYInfo->test_value);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to STRATEGY");
      }
	  
	  my $o_TagdescInfo = $o_TBInfo->get_param_info("TAG_DESC");
	  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TagdescInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to TAG_DESC");
      }
      my $s_FBtag ='TEC_2000                        ';
      $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId,$i_TBBlkIndex + $o_TagdescInfo->parameter_index, 0, length( $s_FBtag), $s_FBtag);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to TAG_DESC");
      } 	  

      my $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ALERT KEY");
      }
      $i_integer = pack("C", $o_ALERTKEYInfo->test_value);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ALERT KEY");
      }

      my $o_UPDATE_EVT = $o_TBInfo->get_param_info("UPDATE_EVT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_UPDATE_EVT->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to UPDATE_EVT");
      }
      my $o_BLOCK_ALM = $o_TBInfo->get_param_info("BLOCK_ALM");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLOCK_ALM->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to BLOCK_ALM");
      }
      my $o_TRANSDUCER_DIRECTORY = $o_TBInfo->get_param_info("TRANSDUCER_DIRECTORY");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TRANSDUCER_DIRECTORY->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to TRANSDUCER_DIRECTORY");
      }	  
	  
      my $o_TRANSDUCER_TYPE = $o_TBInfo->get_param_info("TRANSDUCER_TYPE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TRANSDUCER_TYPE->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to TRANSDUCER_TYPE");
      }
      $i_integer = pack("n", $o_TRANSDUCER_TYPE->test_value);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TRANSDUCER_TYPE->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        print("\n-> Test FAILED :Expected confirm negative for write to TRANSDUCER_TYPE");
      }
	  
      my $o_XD_ERROR = $o_TBInfo->get_param_info("XD_ERROR");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_XD_ERROR->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to XD_ERROR");
      }
      $i_integer = pack("C", $o_XD_ERROR->test_value);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_XD_ERROR->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to XD_ERROR");
      }	 

      my $o_COLLECTION_DIRECTORY = $o_TBInfo->get_param_info("COLLECTION_DIRECTORY");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_COLLECTION_DIRECTORY->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to COLLECTION_DIRECTORY");
      }	  

#==================UPPPER PART MODIFIED========================

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 1);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Voltage");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Voltage");
    }
	
    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 2);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Frequency");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Frequency");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 3);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Three Phase");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Three Phase");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 4);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Auxiliary Control Module");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Auxiliary Control Module");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 5);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Network Adapter");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Network Adapter");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 6);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Starter Type");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Starter Type");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 7);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Torque Spring");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 7, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Torque Spring");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 8);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Motor Type (MPA) / Motor");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 8, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Motor Type (MPA) / Motor");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 9);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Horse Power");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 9, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Horse Power");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 10);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to RPM");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 10, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to RPM");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 11);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Running Amps");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 11, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Running Amps");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 12);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Stalled Amps");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 12, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Stalled Amps");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 13);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Worm Gear");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 13, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Worm Gear");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 14);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Drive Sleeve");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 14, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Drive Sleeve");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 15);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Enable Auxiliary Relay Module (ARM)");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 15, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Enable Auxiliary Relay Module (ARM)");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 16);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Enable Reverse Motor Rotation");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 16, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Enable Reverse Motor Rotation");
    }

     $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 17);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Actuator Type");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 17, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Actuator Type");
    }

    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 18);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to APD Gear Ratio");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 18, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to APD Gear Ratio");
    }


#======================================FACTORY SOFTWARE=============================

    my $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Tag");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for write to Tag");
    }
	
    $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Serial Number");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Serial Number");
    }

    $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 3);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Model");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Model");
    }

     $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 4);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to Manufacture Date");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to Manufacture Date");
    }	



#====================================================FIRMWARE REVISION====================

    my $o_FIRMWARE_REVISIONInfo = $o_TBInfo->get_param_info("FIRMWARE_REVISION");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 1);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to CCM Revision");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to CCM Revision");
    }
	
    $o_FIRMWARE_REVISIONInfo = $o_TBInfo->get_param_info("FIRMWARE_REVISION");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 2);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to LDM Revision");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to LDM Revision");
    }

    $o_FIRMWARE_REVISIONInfo = $o_TBInfo->get_param_info("FIRMWARE_REVISION");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 3);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to RDM 1 Revision");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to RDM 1 Revision");
    }

    $o_FIRMWARE_REVISIONInfo = $o_TBInfo->get_param_info("FIRMWARE_REVISION");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 4);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to RDM 2  Revision");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to RDM 2  Revision");
    }

    $o_FIRMWARE_REVISIONInfo = $o_TBInfo->get_param_info("FIRMWARE_REVISION");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 5);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to ACM Revision");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to ACM Revision");
    }
	
    $o_FIRMWARE_REVISIONInfo = $o_TBInfo->get_param_info("FIRMWARE_REVISION");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 6);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to APD Revision");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to APD Revision");
    }	

	
#=====================================================================================================	

    my $o_FIRMWARE_DATE = $o_TBInfo->get_param_info("FIRMWARE_DATE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_DATE->parameter_index, 0);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to FIRMWARE_DATE");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_DATE->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to FIRMWARE_DATE");
    }
	
    my $o_FF_FUNCTION_TYPE = $o_TBInfo->get_param_info("FF_FUNCTION_TYPE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FF_FUNCTION_TYPE->parameter_index, 0);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to FF_FUNCTION_TYPE");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FF_FUNCTION_TYPE->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to FF_FUNCTION_TYPE");
    }	
	
    my $o_SOFTWARE_VERSION_ID = $o_TBInfo->get_param_info("SOFTWARE_VERSION_ID");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SOFTWARE_VERSION_ID->parameter_index, 0);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to SOFTWARE_VERSION_ID");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SOFTWARE_VERSION_ID->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to SOFTWARE_VERSION_ID");
    }	
	
    my $o_COMPATIBILITY_NUMBER = $o_TBInfo->get_param_info("COMPATIBILITY_NUMBER");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_COMPATIBILITY_NUMBER->parameter_index, 0);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to COMPATIBILITY_NUMBER");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_COMPATIBILITY_NUMBER->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to COMPATIBILITY_NUMBER");
    }	

	  
      my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to CONTROL_MODE");
      }
      $i_integer = pack("C", $o_CONTROL_MODEInfo->test_value);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to CONTROL_MODE");
      }	 

    my $o_LIMIT_SWITCH_STATUS = $o_TBInfo->get_param_info("LIMIT_SWITCH_STATUS");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_STATUS->parameter_index, 0);
    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
    {
      print("\n-> Test FAILED :Expected confirm positive for read to LIMIT_SWITCH_STATUS");
    }
    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_STATUS->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
    if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
      print("\n-> Test FAILED :Expected confirm negative for write to LIMIT_SWITCH_STATUS");
    }	  



      my $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to CONFIGURATION_COMMANDS");
      }


    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOG_JAM");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOG_JAM");
      }

    $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to REMOTE_CONTROL_SIGNAL");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to REMOTE_CONTROL_SIGNAL");
      }

    $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toLOCAL_CONTROL_SIGNAL");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LOCAL_CONTROL_SIGNAL");
      }

    $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to BACKSEAT");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to BACKSEAT");
      }

    $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to SEATING");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to SEATING");
      }

    my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LED_COLOR");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LED_COLOR");
      }

    $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOW_BATTERY_ALARM");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOW_BATTERY_ALARM");
      }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to POSITION_CONTROL_BANDWIDTH");
      }
      $f_float = pack("N", unpack("V", pack("f", 5)));
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to POSITION_CONTROL_BANDWIDTH");
      }

    $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to SPEED_CONTROL_BANDWIDTH");
      }
      $f_float = pack("N", unpack("V", pack("f", 10)));
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to SPEED_CONTROL_BANDWIDTH");
      }

    $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to MODULATION_DELAY");
      }
      $f_float = pack("N", unpack("V", pack("f", 20)));
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to MODULATION_DELAY");
      }
	  
    my $o_ENABLE_RDMS = $o_TBInfo->get_param_info("ENABLE_RDMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_RDMS->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_RDMS");
      }
      $i_integer = pack("n", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_RDMS->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_RDMS");
      }

    my $o_ANALOG_CONTROL_SOURCE = $o_TBInfo->get_param_info("ANALOG_CONTROL_SOURCE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCE->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_CONTROL_SOURCE");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCE->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_CONTROL_SOURCE");
      }	  

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LOST_ANALOG_INPUT_ACTION");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LOST_ANALOG_INPUT_ACTION");
      }

    $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOST_ANALOG_INPUT_1_ALARM");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOST_ANALOG_INPUT_1_ALARM");
      }

    $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOST_ANALOG_INPUT_2_ALARM");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOST_ANALOG_INPUT_2_ALARM");
      }

    $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_OUTPUT_1_SOURCE");
      }
      $i_integer = pack("C", 2);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_1_SOURCE");
      }

    $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toANALOG_OUTPUT_2_SOURCE");
      }
      $i_integer = pack("C", 2);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 6, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_2_SOURCE");
      }
	  
    my $o_DISCRETE_INPUTS_SETTINGS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_SETTINGS0");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS0");
      }	  
	  
      $o_DISCRETE_INPUTS_SETTINGS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_SETTINGS1");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS1");
      }	

      $o_DISCRETE_INPUTS_SETTINGS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_SETTINGS2");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS2");
      }	

      $o_DISCRETE_INPUTS_SETTINGS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_SETTINGS3");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS3");
      }	

      $o_DISCRETE_INPUTS_SETTINGS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_SETTINGS4");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS4");
      }	

      $o_DISCRETE_INPUTS_SETTINGS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_SETTINGS5");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index, 6, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS5");
      }	

      my $o_DISCRETE_INPUTS_FUNCTIONS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_FUNCTIONS");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        print("\n-> Test FAILED :Expected confirm negative for write to DISCRETE_INPUTS_FUNCTIONS");
      }	

      $o_DISCRETE_INPUTS_FUNCTIONS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_FUNCTIONS");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        print("\n-> Test FAILED :Expected confirm negative for write to DISCRETE_INPUTS_FUNCTIONS");
      }	

      $o_DISCRETE_INPUTS_FUNCTIONS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_FUNCTIONS");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        print("\n-> Test FAILED :Expected confirm negative for write to DISCRETE_INPUTS_FUNCTIONS");
      }	

      $o_DISCRETE_INPUTS_FUNCTIONS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_FUNCTIONS3");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        print("\n-> Test FAILED :Expected confirm negative for write to DISCRETE_INPUTS_FUNCTIONS3");
      }	

      $o_DISCRETE_INPUTS_FUNCTIONS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_FUNCTIONS4");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        print("\n-> Test FAILED :Expected confirm negative for write to DISCRETE_INPUTS_FUNCTIONS4");
      }	

      $o_DISCRETE_INPUTS_FUNCTIONS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUTS_FUNCTIONS5");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        print("\n-> Test FAILED :Expected confirm negative for write to DISCRETE_INPUTS_FUNCTIONS5");
      }		  
	  

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toLIMIT_SWITCH_A_TRIGGER_POINT");
      }
      $f_float = pack("N", unpack("V", pack("f", 10)));
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toLIMIT_SWITCH_A_TRIGGER_POINT");
      }

    $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toLIMIT_SWITCH_B_TRIGGER_POINT");
      }
      $f_float = pack("N", unpack("V", pack("f", 20)));
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toLIMIT_SWITCH_B_TRIGGER_POINT");
      }
	  
    my $o_ESD_DELAY = $o_TBInfo->get_param_info("ESD_DELAY");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAY->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ESD_DELAY");
      }
      $i_integer = pack("C", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAY->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ESD_DELAY");
      }	  
	  
    my $o_ESD_OVERRIDES = $o_TBInfo->get_param_info("ESD_OVERRIDES");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_OVERRIDES->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ESD_OVERRIDES");
      }
      $i_integer = pack("n", 2);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_OVERRIDES->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ESD_OVERRIDES");
      }	  
	  
    my $o_ESD_ENABLES_AND_ACTION = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTION->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ESD_ENABLES_AND_ACTION");
      }
      $i_integer = pack("n", 2);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTION->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ESD_ENABLES_AND_ACTION");
      }	 

    $o_ESD_ENABLES_AND_ACTION = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTION->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ESD_ENABLES_AND_ACTION");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTION->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ESD_ENABLES_AND_ACTION");
      }	 	  

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toRELAY_SETTINGS0");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toRELAY_SETTINGS0");
      }

    $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS1");
      }
      $i_integer = pack("C", 2);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS1");
      }

    $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toRELAY_SETTINGS2");
      }
      $i_integer = pack("C", 3);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS2");
      }

    $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toRELAY_SETTINGS3");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toRELAY_SETTINGS3");
      }

    $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toRELAY_SETTINGS4");
      }
      $i_integer = pack("C", 2);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toRELAY_SETTINGS4");
      }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toRELAY_FUNCTIONS0");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS0");
      }

    $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toRELAY_FUNCTIONS1");
      }
      $i_integer = pack("C", 2);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS1");
      }

    $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toRELAY_FUNCTIONS2");
      }
      $i_integer = pack("C", 3);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS2");
      }

    $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toRELAY_FUNCTIONS3");
      }
      $i_integer = pack("C", 4);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS3");
      }

    $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toRELAY_FUNCTIONS4");
      }
      $i_integer = pack("C", 5);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS4");
      }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_SPEED_CONTROL");
      }

      $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to START_POSITION");
      }
      $f_float = pack("f", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to START_POSITION");
      }
	  
      $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to STOP_POSITION");
      }
      $f_float = pack("f", 66);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to STOP_POSITION");
      }

      $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ON_TIME");
      }
      $f_float = pack("f", 60);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ON_TIME");
      }

      $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to OFF_TIME");
      }
      $f_float = pack("f", 60);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to OFF_TIME");
      }	  
	  
      $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DUTY_CYCLE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DUTY_CYCLE");
      }	  

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_SPEED_CONTROL");
      }

      $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to START_POSITION");
      }
      $f_float = pack("f", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to START_POSITION");
      }
	  
      $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to STOP_POSITION");
      }
      $f_float = pack("f", 66);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to STOP_POSITION");
      }	  

      $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ON_TIME");
      }
      $f_float = pack("f", 30);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ON_TIME");
      }

      $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to OFF_TIME");
      }
      $f_float = pack("f", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to OFF_TIME");
      }
	  
      $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DUTY_CYCLE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DUTY_CYCLE");
      }	
#=============================anti water hammer=========================================	  

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_SPEED_CONTROL");
      }
	  
      $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to START_POSITION");
      }
      $f_float = pack("f", 10);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to START_POSITION");
      }
	  
      $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to STOP_POSITION");
      }
      $f_float = pack("f", 0);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to STOP_POSITION");
      }	  

      $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ON_TIME");
      }
      $f_float = pack("f", 30);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ON_TIME");
      }

      $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to OFF_TIME");
      }
      $f_float = pack("f", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to OFF_TIME");
      }
	  
      $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DUTY_CYCLE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 6, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DUTY_CYCLE");
      }		  
	  
#=======================================================================================	  

      my $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toDEFAULT_SETPOINT_1");
      }
      $f_float = pack("f", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toDEFAULT_SETPOINT_1");
      }
	  
    my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to CLOSE_TORQUE_LIMIT");
      }
      $f_float = pack("f", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to CLOSE_TORQUE_LIMIT");
      }	  

      $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toOPEN_TORQUE_LIMIT");
      }
      $f_float = pack("f", 30);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toOPEN_TORQUE_LIMIT");
      }
	  
    my $o_MAXIMUM_TORQUE = $o_TBInfo->get_param_info("MAXIMUM_TORQUE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUE->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to MAXIMUM_TORQUE");
      }
      $f_float = pack("f", 30);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUE->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to MAXIMUM_TORQUE");
      }	 

    my $o_TORQUE_OUT_OF_RANGE = $o_TBInfo->get_param_info("TORQUE_OUT_OF_RANGE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_OUT_OF_RANGE->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to TORQUE_OUT_OF_RANGE");
      }
      $f_float = pack("f", 30);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_OUT_OF_RANGE->parameter_index, 0, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        print("\n-> Test FAILED :Expected confirm negative for write to TORQUE_OUT_OF_RANGE");
      }	

    my $o_STROKE_TIME = $o_TBInfo->get_param_info("STROKE_TIME");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIME->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to STROKE_TIME");
      }
      $f_float = pack("n", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIME->parameter_index, 0, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to STROKE_TIME");
      }	  
	  
	  

    my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to HOST_COMMAND_ESD");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to HOST_COMMAND_ESD");
      }
	  
    my $o_ENABLE_PST = $o_TBInfo->get_param_info("ENABLE_PST");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PST->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_PST");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PST->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_PST");
      }	  

      my $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to SETPOINT");
      }
      $i_integer = pack("C", 100);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to SETPOINT");
      }

      my $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_1_STATUS");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_1_STATUS");
      }

      my $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_2_STATUS");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_2_STATUS");
      }

      my $o_RELAY_3_STATUSInfo = $o_TBInfo->get_param_info("RELAY_3_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_3_STATUS");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_3_STATUS");
      }

      my $o_RELAY_4_STATUSInfo = $o_TBInfo->get_param_info("RELAY_4_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_4_STATUS");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_4_STATUS");
      }

      my $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_5_STATUS");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_5_STATUS");
      }

      my $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_OUTPUT_1");
      }
      $i_integer = pack("C", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_1");
      }

      my $o_ANALOG_OUTPUT_2Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_2Info->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_OUTPUT_2");
      }
      $i_integer = pack("C", 50);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_2Info->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_2");
      }

      my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ACTUATOR_COMMAND");
      }
      $i_integer = pack("C", 1);
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ACTUATOR_COMMAND");
      }
}


sub Teardown()
{
  Log("Teardown ADVT test script....");
}