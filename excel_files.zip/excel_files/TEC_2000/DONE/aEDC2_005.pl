#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify that all Static & Non-volatile parameters retains
 #          there previously written value after power reset.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;
 use constant RESTART_WITH_PROCESSOR             => 4;
 use constant MIB_PROFILE_NO                     => 0x4D47;
 use constant FBAP_PROFILE_NO                    => 0;
 use constant OD_VERSION                         => 1;
 use constant ABORT_REASON                       => 0x01;  

 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $o_STRATEGYInfo;
 my $o_ALERTKEYInfo;
 my $o_FACTORY_SOFTWAREInfo;
 my $o_CONTROL_MODEInfo;
 my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo;
 my $o_ESD_DELAYInfo;
 my $o_ESD_ENABLES_AND_ACTIONInfo;
 my $o_HOST_COMMAND_ESDInfo;
 my $o_ENABLE_PSTInfo;
 my $o_CONTROL_PARAM_1Info;
 my $o_CONTROL_PARAM_2Info;
 my $o_MODULATION_PARAMETERSInfo;
 my $o_ANALOG_CONTROL_SOURCEInfo;
 my $o_ANALOG_PARAMSInfo;
 my $o_DISCRETE_INPUTS_SETTINGSInfo;
 my $o_RELAY_SETTINGSInfo;
 my $o_RELAY_FUNCTIONSInfo;
 my $o_MAXIMUM_TORQUEInfo;
 my $o_STROKE_TIMEInfo;
 my $o_ACTUATOR_MODEInfo;
 my $i_integer;
 my $f_float;
 my $o_OPEN_SPEED_CONTROLInfo;
 my $o_CLOSE_SPEED_CONTROLInfo;
 my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo;
 my $o_DEFAULT_SETPOINTInfo;
 my $o_TORQUE_LIMITInfo;
 my $o_CONFIGURATION_COMMANDSInfo;
 my $o_ACTUATOR_COMMANDInfo;
 my $o_SETPOINTInfo;
 
 
 
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex         = 1200; #ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex =  1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "TEC_2000";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE1.xls");
     
   my $o_ModeblkInfo = $o_RBInfo->get_param_info("MODE_BLK");
   my $o_RBlkMode = new ff_tools::od::fbap::blocks::mode_blk();
   $o_RBlkMode    = ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, OOS);
   if (!(ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, OOS)))
   {
     print("\n-> Test FAILED :Unable to set RB in OOS mode");
   }

  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to STRATEGY");
  }

  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("C", $o_ALERTKEYInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ALERT KEY");
  }
  
  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ACTUATOR_MODE");
  }  
  
#================================factory software===================================
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  my $s_string = 'FF              ';
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1, length($s_string) ,$s_string);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to TAG");
  } 
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  $s_string = '1234      ';
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2, length($s_string) ,$s_string);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to Serial Number");
  }
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  $s_string = 'TEC2000';
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 3, length($s_string) ,$s_string);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to Model");
  }
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  $s_string = '25-sep-14  ';
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 4, length($s_string) ,$s_string);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to Manufacture Date");
  }  
  
  #============================================================================================

  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to CONTROL_MODE");
  }

  #$o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
  #$i_integer = pack("C", $o_CONFIGURATION_COMMANDSInfo->test_value);
  #$rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  #if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  #{
  #  print("\n-> Test FAILED :Expected confirm positive for write to CONFIGURATION_COMMANDS");
  #}

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to CONTROL_PARAM_1");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to CONTROL_PARAM_1");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to CONTROL_PARAM_1");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to CONTROL_PARAM_1");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to CONTROL_PARAM_1");
  }

  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCONTROL_PARAM_2");
  }

  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCONTROL_PARAM_2");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMODULATION_PARAMETERS");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMODULATION_PARAMETERS");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMODULATION_PARAMETERS");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_PARAMS");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toANALOG_PARAMS");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_PARAMS");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_PARAMS");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 6, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_PARAMS");
  }

  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 6)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to LIMIT_SWITCH_TRIGGER_POINTS");
  }

  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 6)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toLIMIT_SWITCH_TRIGGER_POINTS");
  }
  
#=================esd delay==========================================
  $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $i_integer = pack("C", 50);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ESD_DELAY");
  }
#================================================================  
  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ESD_ACTION");
  }

  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to HOST_COMMAND_ESD");
  }
    $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ENABLE_PSTInfo = $o_TBInfo->get_param_info("ENABLE_PST");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PSTInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_PST");
  }  

  $o_ANALOG_CONTROL_SOURCEInfo = $o_TBInfo->get_param_info("ANALOG_CONTROL_SOURCE");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_CONTROL_SOURCE");
  } 
  
#======================================discrete input settings==========================
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS0");
  }
  
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS1");
  }

  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS2");
  }

  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS3");
  }

  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS4");
  }

  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUTS_SETTINGS5");
  }  

#====================================================================================  
  
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_SETTINGS");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_SETTINGS");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_SETTINGS");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_SETTINGS");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_SETTINGS");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS");
  }
  
  $o_MAXIMUM_TORQUEInfo = $o_TBInfo->get_param_info("MAXIMUM_TORQUE");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUEInfo->parameter_index, 0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to MAXIMUM_TORQUE");
  }  

  $o_STROKE_TIMEInfo = $o_TBInfo->get_param_info("STROKE_TIME");
  $i_integer = pack("n", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIMEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to STROKE_TIME");
  }  
  
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toOPEN_SPEED_CONTROL");
  }

  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toOPEN_SPEED_CONTROL");
  }

  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCLOSE_SPEED_CONTROL");
  }

  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCLOSE_SPEED_CONTROL");
  }

  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toANTI_WATER_HAMMER_SPEED_CONTROL");
  }

  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toDEFAULT_SETPOINT");
  }

  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to TORQUE_LIMIT");
  }
  
  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ACTUATOR_COMMAND value");
  }   
  
  $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $i_integer = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to SETPOINT value");
  }  
 
 
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_1 value \n ");
    } 
#======================================================Power Cycle=====================================================================================
  my $o_RBRestartParamInfo = $o_RBInfo->get_param_info("RESTART");
  my $s_ProcRestart = pack("C", RESTART_WITH_PROCESSOR);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId,$o_RBInfo->od_index + $o_RBRestartParamInfo->parameter_index,0,length($s_ProcRestart),$s_ProcRestart);

  ff_tools::hostapi::api::Abort($i_DutFbapVcrId,   ABORT_REASON);
  ff_tools::hostapi::api::Abort($i_DutMibVcrId,    ABORT_REASON);
  ff_tools::hostapi::api::WaitForInd($ff_tools::hostapi::SERVICE_CODE_SM_NEW_NODE_EVENT, 1000);
  ff_tools::hostapi::api::Initiate($i_DutFbapVcrId,  OD_VERSION, MIB_PROFILE_NO);
  ff_tools::hostapi::api::Initiate($i_DutMibVcrId, OD_VERSION, FBAP_PROFILE_NO);
#=======================================================================================================================================================
}
 sub Run() 
 { 
 

  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0);
  my $i_STRATEGY = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_STRATEGY!= $o_STRATEGYInfo->test_value)
  {
    print("\n-> Test FAILED :Parameter STRATEGY Could not Retain value");
  }

  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0);
  my $i_ALERTKEY = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ALERTKEY != $o_ALERTKEYInfo->test_value)
  {
    print("\n-> Test FAILED :Parameter ALERT KEY Could not Retain value");
  }
  
 #=================================Factory software=====================================
  #$o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  #$rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 1);
  #if ($rh_Result->{"Confirm"}->Data ne "FF              ")
  #{
  #  print("\n-> Test FAILED :Parameter TAG Could not Retain value");
  #}
  
  #$o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  #$rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 2);
  #if ($rh_Result->{"Confirm"}->Data ne "1234      ")
  #{
  #  print("\n-> Test FAILED :Parameter serial number Could not Retain value");
  #}

 # $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
 # $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 3);
 # if ($rh_Result->{"Confirm"}->Data ne "TEC2000")
 # {
 #   print("\n-> Test FAILED :Parameter model Could not Retain value");
 # }

  #$o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  #$rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 4);
  #if ($rh_Result->{"Confirm"}->Data ne "25-sep-14  ")
  #{
   # print("\n-> Test FAILED :Parameter manufacture date Could not Retain value");
  #}  
#==============================================================================================  

  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0);
  my $i_CONTROL_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_MODE != $o_CONTROL_MODEInfo->test_value)
  {
    print("\n-> Test FAILED :Parameter CONTROL_MODE Could not Retain value");
  }

  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0);
  my $i_ACTUATOR_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ACTUATOR_MODE == $o_ACTUATOR_MODEInfo->test_value)
  {
    print("\n-> Test FAILED :Dynamic Parameter ACTUATOR_MODE Could Retain value");
  }

  $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0);
  my $i_CONFIGURATION_COMMANDS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONFIGURATION_COMMANDS == $o_CONFIGURATION_COMMANDSInfo->test_value)
  {
    print("\n-> Test FAILED :Dynamic Parameter CONFIGURATION_COMMANDS Could Retain value");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,1);
  my $i_CONTROL_PARAM_1 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_1 != 1)
  {
    print("\n-> Test FAILED :Parameter ENABLE_LOG_JAM Could not Retain value");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,2);
  $i_CONTROL_PARAM_1 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_1 != 1)
  {
    print("\n-> Test FAILED :Parameter REMOTE_CONTROL_SIGNAL Could not Retain value");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,3);
  $i_CONTROL_PARAM_1 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_1 != 1)
  {
    print("\n-> Test FAILED :Parameter LOCAL_CONTROL_SIGNAL Could not Retain value");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,4);
  $i_CONTROL_PARAM_1 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_1 != 1)
  {
    print("\n-> Test FAILED :Parameter BACKSEAT Could not Retain value");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,5);
  $i_CONTROL_PARAM_1 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_1 != 1)
  {
    print("\n-> Test FAILED :Parameter SEATING Could not Retain value");
  }

  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,1);
  my $i_CONTROL_PARAM_2 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_2 != 1)
  {
    print("\n-> Test FAILED :Parameter LED_COLOR Could not Retain value");
  }

  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,2);
  $i_CONTROL_PARAM_2 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_2 != 1)
  {
    print("\n-> Test FAILED :Parameter ENABLE_LOW_BATTERY_ALARM Could not Retain value");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,1);
  my $f_MODULATION_PARAMETERS = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_MODULATION_PARAMETERS != 5)
  {
    print("\n-> Test FAILED :Parameter POSITION_CONTROL_BANDWIDTH Could not Retain value");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,2);
  $f_MODULATION_PARAMETERS = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_MODULATION_PARAMETERS != 5)
  {
    print("\n-> Test FAILED :Parameter SPEED_CONTROL_BANDWIDTH Could not Retain value");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,3);
  $f_MODULATION_PARAMETERS = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_MODULATION_PARAMETERS != 5)
  {
    print("\n-> Test FAILED :Parameter MODULATION_DELAY Could not Retain value");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1);
  my $i_ANALOG_PARAMS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ANALOG_PARAMS != 1)
  {
    print("\n-> Test FAILED :Parameter LOST_ANALOG_INPUT_ACTION Could not Retain value");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3);
  $i_ANALOG_PARAMS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ANALOG_PARAMS != 1)
  {
    print("\n-> Test FAILED :Parameter ENABLE_LOST_ANALOG_INPUT_1_ALARM Could not Retain value");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,4);
  $i_ANALOG_PARAMS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ANALOG_PARAMS != 1)
  {
    print("\n-> Test FAILED :Parameter ENABLE_LOST_ANALOG_INPUT_2_ALARM Could not Retain value");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5);
  $i_ANALOG_PARAMS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ANALOG_PARAMS != 1)
  {
    print("\n-> Test FAILED :Parameter ANALOG_OUTPUT_1_SOURCE Could not Retain value");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,6);
  $i_ANALOG_PARAMS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ANALOG_PARAMS != 1)
  {
    print("\n-> Test FAILED :Parameter ANALOG_OUTPUT_2_SOURCE Could not Retain value");
  }

  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,1);
  my $f_LIMIT_SWITCH_TRIGGER_POINTS = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_LIMIT_SWITCH_TRIGGER_POINTS != 6)
  {
    print("\n-> Test FAILED :Parameter LIMIT_SWITCH_A_TRIGGER_POINT Could not Retain value");
  }

  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,2);
  $f_LIMIT_SWITCH_TRIGGER_POINTS = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_LIMIT_SWITCH_TRIGGER_POINTS != 6)
  {
    print("\n-> Test FAILED :Parameter LIMIT_SWITCH_B_TRIGGER_POINT Could not Retain value");
  }
  
  $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index,0);
  my $i_ESD = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ESD != 50)
  {
    print("\n-> Test FAILED :Parameter ESD_DELAY Could not Retain value");
  }
  
  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index,2);
  my $i_ESD_ACTION = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ESD_ACTION != 2)
  {
    print("\n-> Test FAILED :Parameter ESD_ACTION Could not Retain value");
  } 

  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index,1);
  my $i_hostcmd = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_hostcmd != 1)
  {
    print("\n-> Test FAILED :Parameter HOST_COMMAND_ESD Could not Retain value");
  }  
  
  $o_ENABLE_PSTInfo = $o_TBInfo->get_param_info("ENABLE_PST");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PSTInfo->parameter_index,0);
  my $i_ENABLE_PST = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ENABLE_PST != 1)
  {
    print("\n-> Test FAILED :Parameter ENABLE_PST Could not Retain value");
  } 
 
  $o_ANALOG_CONTROL_SOURCEInfo = $o_TBInfo->get_param_info("ANALOG_CONTROL_SOURCE");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCEInfo->parameter_index,0);
  my $i_ANALOG_CONTROL_SOURCE = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ANALOG_CONTROL_SOURCE != 1)
  {
    print("\n-> Test FAILED :Parameter ANALOG_CONTROL_SOURCE Could not Retain value");
  }
  
#=================================discrete settings=======================================
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,1);
  my $i_DISCRETE_INPUTS_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_DISCRETE_INPUTS_SETTINGS != 1)
  {
    print("\n-> Test FAILED :Parameter DISCRETE_INPUTS_SETTINGS0 Could not Retain value");
  }
  
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,2);
  $i_DISCRETE_INPUTS_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_DISCRETE_INPUTS_SETTINGS != 1)
  {
    print("\n-> Test FAILED :Parameter DISCRETE_INPUTS_SETTINGS1 Could not Retain value");
  }

  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,3);
  $i_DISCRETE_INPUTS_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_DISCRETE_INPUTS_SETTINGS != 1)
  {
    print("\n-> Test FAILED :Parameter DISCRETE_INPUTS_SETTINGS2 Could not Retain value");
  }

  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,4);
  $i_DISCRETE_INPUTS_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_DISCRETE_INPUTS_SETTINGS != 1)
  {
    print("\n-> Test FAILED :Parameter DISCRETE_INPUTS_SETTINGS3 Could not Retain value");
  }

  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,5);
  $i_DISCRETE_INPUTS_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_DISCRETE_INPUTS_SETTINGS != 1)
  {
    print("\n-> Test FAILED :Parameter DISCRETE_INPUTS_SETTINGS4 Could not Retain value");
  }

  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,6);
  $i_DISCRETE_INPUTS_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_DISCRETE_INPUTS_SETTINGS != 1)
  {
    print("\n-> Test FAILED :Parameter DISCRETE_INPUTS_SETTINGS5 Could not Retain value");
  }  

#=========================================================================================  
 
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,1);
  my $i_RELAY_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_SETTINGS != 1)
  {
    print("\n-> Test FAILED :Parameter RELAY_SETTINGS0 Could not Retain value");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,2);
  $i_RELAY_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_SETTINGS != 1)
  {
    print("\n-> Test FAILED :Parameter RELAY_SETTINGS1 Could not Retain value");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,3);
  $i_RELAY_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_SETTINGS != 1)
  {
    print("\n-> Test FAILED :Parameter RELAY_SETTINGS2 Could not Retain value");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,4);
  $i_RELAY_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_SETTINGS != 1)
  {
    print("\n-> Test FAILED :Parameter RELAY_SETTINGS3 Could not Retain value");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,5);
  $i_RELAY_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_SETTINGS != 1)
  {
    print("\n-> Test FAILED :Parameter RELAY_SETTINGS4 Could not Retain value");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,1);
  my $i_RELAY_FUNCTIONS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_FUNCTIONS != 1)
  {
    print("\n-> Test FAILED :Parameter RELAY_FUNCTIONS0 Could not Retain value");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,2);
  $i_RELAY_FUNCTIONS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_FUNCTIONS != 1)
  {
    print("\n-> Test FAILED :Parameter RELAY_FUNCTIONS1 Could not Retain value");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,3);
  $i_RELAY_FUNCTIONS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_FUNCTIONS != 1)
  {
    print("\n-> Test FAILED :Parameter RELAY_FUNCTIONS2 Could not Retain value");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,4);
  $i_RELAY_FUNCTIONS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_FUNCTIONS != 1)
  {
    print("\n-> Test FAILED :Parameter RELAY_FUNCTIONS3 Could not Retain value");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,5);
  $i_RELAY_FUNCTIONS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_FUNCTIONS != 1)
  {
    print("\n-> Test FAILED :Parameter RELAY_FUNCTIONS4 Could not Retain value");
  }

  $o_MAXIMUM_TORQUEInfo = $o_TBInfo->get_param_info("MAXIMUM_TORQUE");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUEInfo->parameter_index,0);
  my $f_MAXIMUM_TORQUE = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_MAXIMUM_TORQUE != 1)
  {
    print("\n-> Test FAILED :Parameter MAXIMUM_TORQUE Could not Retain value");
  }  
  
   $o_STROKE_TIMEInfo = $o_TBInfo->get_param_info("STROKE_TIME");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIMEInfo->parameter_index,0);
  $i_RELAY_FUNCTIONS = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_FUNCTIONS != 1)
  {
    print("\n-> Test FAILED :Parameter STROKE_TIME Could not Retain value");
  } 
  
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,4);
  my $f_OPEN_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_OPEN_SPEED_CONTROL != 1)
  {
    print("\n-> Test FAILED :Parameter ON_TIME Could not Retain value");
  }

  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,5);
  $f_OPEN_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_OPEN_SPEED_CONTROL!= 1)
  {
    print("\n-> Test FAILED :Parameter OFF_TIME Could not Retain value");
  }

  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,4);
  my $f_CLOSE_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_CLOSE_SPEED_CONTROL!= 1)
  {
    print("\n-> Test FAILED :Parameter ON_TIME Could not Retain value");
  }

  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,5);
  $f_CLOSE_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_CLOSE_SPEED_CONTROL!= 1)
  {
    print("\n-> Test FAILED :Parameter OFF_TIME Could not Retain value");
  }

  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,2);
  my $f_ANTI_WATER_HAMMER_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_ANTI_WATER_HAMMER_SPEED_CONTROL!= 1)
  {
    print("\n-> Test FAILED :Parameter START_POSITION Could not Retain value");
  }

  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,1);
  my $f_DEFAULT_SETPOINT = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_DEFAULT_SETPOINT!= 1)
  {
    print("\n-> Test FAILED :Parameter DEFAULT_SETPOINT_1 Could not Retain value");
  }

  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2);
  my $f_TORQUE_LIMIT = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_TORQUE_LIMIT!= 1)
  {
    print("\n-> Test FAILED :Parameter OPEN_TORQUE_LIMIT Could not Retain value");
  }
  
  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index,2);
  my $i_ACTUATOR_COMMAND = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_TORQUE_LIMIT != 0)
  {
    print("\n-> Test FAILED :Parameter ACTUATOR_COMMAND Could not Retain value");
  }
  
   $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index,2);
  my $f_SETPOINT = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_SETPOINT != 100)
  {
    print("\n-> Test FAILED :Parameter SETPOINT Could not Retain value");
  }
  
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index,2);  
  my $f_ANALOG_OUTPUT_1 = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
    if ($f_ANALOG_OUTPUT_1 != 100)
  {
    print("\n-> Test FAILED :Parameter ANALOG_OUTPUT_1 Could  Retain value");
  }
  
  
  }
  
sub Teardown()
{
  Log("Teardown ADVT test script....");
} 	  