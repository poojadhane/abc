#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify all boundaries for parameters that are
 #          having range of valid values.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $i_integer;
 my $f_float;
 
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex         = 1200; # ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex   = 1000; # ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "TEC_2000";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE1.xls");
 }
 sub Run() 
 { 
 
  my $o_StatRevInfo = $o_TBInfo->get_param_info("ST_REV");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_StatRevInfo->parameter_index, 0);
  my $i_StatRev = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_StatRev < 0 &&   $i_StatRev > 65535)
  {
    print("\n-> Test FAILED :ST_REV parameter has out of range value");
  }
  
  my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write STRATEGY for minimum range value");
    }


  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write STRATEGY for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("N", $o_STRATEGYInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write STRATEGY for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("N", $o_STRATEGYInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write STRATEGY for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("C", $o_ALERTKEYInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ALERT KEY for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("C", $o_ALERTKEYInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ALERT KEY for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("N", $o_ALERTKEYInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ALERT KEY for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("N", $o_ALERTKEYInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ALERT KEY for out of range value");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  my $o_TRANSDUCER_TYPEInfo = $o_TBInfo->get_param_info("TRANSDUCER_TYPE");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TRANSDUCER_TYPEInfo->parameter_index, 0);
  my $i_TRANSDUCER_TYPE = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_TRANSDUCER_TYPE < $o_TRANSDUCER_TYPEInfo->min_range_value &&   $i_TRANSDUCER_TYPE > $o_TRANSDUCER_TYPEInfo->max_range_value)
  {
    print("\n-> Test FAILED :TRANSDUCER_TYPE parameter has out of range value");
  }	
  
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;  
  my $o_XD_ERRORInfo = $o_TBInfo->get_param_info("XD_ERROR");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_XD_ERRORInfo->parameter_index, 0);
  my $i_XD_ERROR = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_XD_ERROR < $o_XD_ERRORInfo->min_range_value &&   $i_XD_ERROR > $o_XD_ERRORInfo->max_range_value)
  {
    print("\n-> Test FAILED :XD_ERROR parameter has out of range value");
  }	  
  
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;  
  my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR_MODE for minimum range value");
    }  
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR MODE for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("N", $o_ACTUATOR_MODEInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ACTUATOR MODE for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ACTUATOR MODE for out of range value");
    }	
  
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;  
    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 1);
    my $i_facthard = unpack("C", $rh_Result->{"Confirm"}->Data);
    if ($i_facthard < 0 &&   $i_facthard > 14)
    {
      print("\n-> Test FAILED :Voltage parameter has out of range value");
    }	

	  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 2);
    $i_facthard = unpack("C", $rh_Result->{"Confirm"}->Data);
    if ($i_facthard < 0 &&   $i_facthard > 2)
    {
      print("\n-> Test FAILED :Frequency parameter has out of range value");
    }

	  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 3);
    $i_facthard = unpack("C", $rh_Result->{"Confirm"}->Data);
    if ($i_facthard < 0 &&   $i_facthard > 1)
    {
      print("\n-> Test FAILED :Three Phase parameter has out of range value");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 4);
    $i_facthard = unpack("C", $rh_Result->{"Confirm"}->Data);
    if ($i_facthard < 0 &&   $i_facthard > 3)
    {
      print("\n-> Test FAILED :Auxiliary Control Module parameter has out of range value");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 5);
    $i_facthard = unpack("C", $rh_Result->{"Confirm"}->Data);
    if ($i_facthard < 0 &&   $i_facthard > 11)
    {
      print("\n-> Test FAILED :Network Adapter parameter has out of range value");
    }	

	  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 6);
    $i_facthard = unpack("C", $rh_Result->{"Confirm"}->Data);
    if ($i_facthard < 0 &&   $i_facthard > 4)
    {
      print("\n-> Test FAILED :Starter Type parameter has out of range value");
    }	

	  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
    $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
    $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 7);
    $i_facthard = unpack("C", $rh_Result->{"Confirm"}->Data);
    if ($i_facthard < 0 &&   $i_facthard > 9)
    {
      print("\n-> Test FAILED :Torque Spring parameter has out of range value");
    }			
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CONTROL_MODE for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CONTROL_MODE for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("N", $o_CONTROL_MODEInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CONTROL_MODE for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CONTROL_MODE for out of range value");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ENABLE_LOG_JAM for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ENABLE_LOG_JAM for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOG_JAM for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOG_JAM for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write REMOTE_CONTROL_SIGNAL for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write REMOTE_CONTROL_SIGNAL for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write REMOTE_CONTROL_SIGNAL for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write REMOTE_CONTROL_SIGNAL for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LOCAL_CONTROL_SIGNAL for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LOCAL_CONTROL_SIGNAL for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOCAL_CONTROL_SIGNAL for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOCAL_CONTROL_SIGNAL for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write BACKSEAT for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write BACKSEAT for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write BACKSEAT for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write BACKSEAT for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write SEATING for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SEATING for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SEATING for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SEATING for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LED_COLOR for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LED_COLOR for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LED_COLOR for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LED_COLOR for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ENABLE_LOW_BATTERY_ALARM for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ENABLE_LOW_BATTERY_ALARM for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOW_BATTERY_ALARM for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOW_BATTERY_ALARM for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 0.1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write POSITION_CONTROL_BANDWIDTH for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write POSITION_CONTROL_BANDWIDTH for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("d", -0.9);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write POSITION_CONTROL_BANDWIDTH for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 6)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write POSITION_CONTROL_BANDWIDTH for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 0.5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write SPEED_CONTROL_BANDWIDTH for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 10)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SPEED_CONTROL_BANDWIDTH for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SPEED_CONTROL_BANDWIDTH for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 11)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SPEED_CONTROL_BANDWIDTH for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,3, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write MODULATION_DELAY for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 25)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,3, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write MODULATION_DELAY for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,3, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write MODULATION_DELAY for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 25)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,3, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write MODULATION_DELAY for out of range value");
    }
	
  my $o_ANALOG_CONTROL_SOURCEInfo = $o_TBInfo->get_param_info("ANALOG_CONTROL_SOURCE");
  $i_integer = pack("C", $o_ANALOG_CONTROL_SOURCEInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ANALOG_CONTROL_SOURCE for minimum range value");
    }  
	

  $o_ANALOG_CONTROL_SOURCEInfo = $o_TBInfo->get_param_info("ANALOG_CONTROL_SOURCE");
  $i_integer = pack("C", $o_ANALOG_CONTROL_SOURCEInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ANALOG_CONTROL_SOURCE for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_CONTROL_SOURCEInfo = $o_TBInfo->get_param_info("ANALOG_CONTROL_SOURCE");
  $i_integer = pack("N", $o_ANALOG_CONTROL_SOURCEInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ANALOG_CONTROL_SOURCE for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_ANALOG_CONTROL_SOURCEInfo = $o_TBInfo->get_param_info("ANALOG_CONTROL_SOURCE");
  $i_integer = pack("C", $o_ANALOG_CONTROL_SOURCEInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ANALOG_CONTROL_SOURCE for out of range value");
    }	


  my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LOST_ANALOG_INPUT_ACTION for minimum range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could not Write LOST_ANALOG_INPUT_ACTION for maximum range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOST_ANALOG_INPUT_ACTION for out of range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOST_ANALOG_INPUT_ACTION for out of range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ENABLE_LOST_ANALOG_INPUT_1_ALARM for minimum range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ENABLE_LOST_ANALOG_INPUT_1_ALARM for maximum range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOST_ANALOG_INPUT_1_ALARM for out of range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOST_ANALOG_INPUT_1_ALARM for out of range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ENABLE_LOST_ANALOG_INPUT_2_ALARM for minimum range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ENABLE_LOST_ANALOG_INPUT_2_ALARM for maximum range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOST_ANALOG_INPUT_2_ALARM for out of range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOST_ANALOG_INPUT_2_ALARM for out of range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_1_SOURCE for minimum range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_1_SOURCE for maximum range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ANALOG_OUTPUT_1_SOURCE for out of range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ANALOG_OUTPUT_1_SOURCE for out of range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_2_SOURCE for minimum range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_2_SOURCE for maximum range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ANALOG_OUTPUT_2_SOURCE for out of range value");
    }


  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ANALOG_OUTPUT_2_SOURCE for out of range value");
    }


  my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_A_TRIGGER_POINT for minimum range value");
    }


  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_A_TRIGGER_POINT for maximum range value");
    }


  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_A_TRIGGER_POINT for out of range value");
    }


  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_A_TRIGGER_POINT for out of range value");
    }


  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_B_TRIGGER_POINT for minimum range value");
    }


  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_B_TRIGGER_POINT for maximum range value");
    }


  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_B_TRIGGER_POINT for out of range value");
    }


  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_B_TRIGGER_POINT for out of range value");
    }
	
  my $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $i_integer = pack("C", $o_ESD_DELAYInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ESD_DELAY for minimum range value");
    }


  $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $i_integer = pack("C", $o_ESD_DELAYInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ESD_DELAY for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $i_integer = pack("N", $o_ESD_DELAYInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ESD_DELAY for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $i_integer = pack("C", $o_ESD_DELAYInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ESD_DELAY for out of range value");
    }	
	
  my $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ESD_ACTION for minimum range value");
    }


  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ESD_ACTION for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ESD_ACTION for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ESD_ACTION for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write HOST_COMMAND_ESD for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write HOST_COMMAND_ESD for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write HOST_COMMAND_ESD for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write HOST_COMMAND_ESD for out of range value");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  my $o_ENABLE_PSTInfo = $o_TBInfo->get_param_info("ENABLE_PST");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PSTInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ENABLE_PST for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ENABLE_PSTInfo = $o_TBInfo->get_param_info("ENABLE_PST");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PSTInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ENABLE_PST for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ENABLE_PSTInfo = $o_TBInfo->get_param_info("ENABLE_PST");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PSTInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_PST for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_ENABLE_PSTInfo = $o_TBInfo->get_param_info("ENABLE_PST");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PSTInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_PST for out of range value");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS0 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS0 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS0 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS0 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS1 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS1 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS1 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS1 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS2 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS2 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS2 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS2 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS3 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS3 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS3 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS3 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS4 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 5);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS4 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS4 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 6);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS4 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS0 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 48);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS0 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS0 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 49);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS0 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS1 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 48);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS1 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS1 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 49);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS1 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS2 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 48);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS2 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS2 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 49);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS2 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS3 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 48);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS3 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS3 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 49);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS3 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS4 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 48);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS4 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS4 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 49);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS4 for out of range value");
    }

#========================Added==============================================

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write Enable speed control for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("C",1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Enable speed control for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Enable speed control for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Enable speed control for out of range value");
	
#=================================================================================================	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
   $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0.5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ON_TIME for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 10)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ON_TIME for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ON_TIME for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 11)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ON_TIME for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0.5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write OFF_TIME for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 10)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write OFF_TIME for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OFF_TIME for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 11)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OFF_TIME for out of range value");
    }
	
	
#==============================Added==============================================================

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write Enable speed control for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("C",1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Enable speed control for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Enable speed control for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Enable speed control for out of range value");
	}
	
#======================================================================================

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
   $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0.5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ON_TIME for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 10)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ON_TIME for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ON_TIME for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 11)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could not Write ON_TIME for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0.5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write OFF_TIME for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 10)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write OFF_TIME for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OFF_TIME for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 11)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OFF_TIME for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write START_POSITION for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 30)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write START_POSITION for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write START_POSITION for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 31)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write START_POSITION for out of range value");
    }
	
	
#===============================Added=============================================================

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write Enable speed control for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("C",1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Enable speed control for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Enable speed control for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Enable speed control for out of range value");

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0.5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ON_TIME for minimum range value of ANTI_WATER_HAMMER_SPEED_CONTROL");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 10)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ON_TIME for maximum range value of ANTI_WATER_HAMMER_SPEED_CONTROL");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ON_TIME for out of range value of ANTI_WATER_HAMMER_SPEED_CONTROL");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 11)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could not Write ON_TIME for out of range value of ANTI_WATER_HAMMER_SPEED_CONTROL");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0.5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write OFF_TIME for minimum range value of ANTI_WATER_HAMMER_SPEED_CONTROL");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 10)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write OFF_TIME for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OFF_TIME for out of range value of ANTI_WATER_HAMMER_SPEED_CONTROL");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 11)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OFF_TIME for out of range value of ANTI_WATER_HAMMER_SPEED_CONTROL");
    }

#=================================================================================================	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write DEFAULT_SETPOINT_1 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write DEFAULT_SETPOINT_1 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DEFAULT_SETPOINT_1 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DEFAULT_SETPOINT_1 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write CLOSE_TORQUE_LIMIT for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CLOSE_TORQUE_LIMIT for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CLOSE_TORQUE_LIMIT for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CLOSE_TORQUE_LIMIT for out of range value");
    }
	
	  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write OPEN_TORQUE_LIMIT for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write OPEN_TORQUE_LIMIT for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OPEN_TORQUE_LIMIT for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OPEN_TORQUE_LIMIT for out of range value");
    }	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write DISCRETE_INPUTS_SETTINGS0 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write DISCRETE_INPUTS_SETTINGS0 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS0 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS0 for out of range value");
    }
	  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write DISCRETE_INPUTS_SETTINGS1 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write DISCRETE_INPUTS_SETTINGS1 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS1 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS1 for out of range value");
    }
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS2 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write DISCRETE_INPUTS_SETTINGS2 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS2 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS2 for out of range value");
    }
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write DISCRETE_INPUTS_SETTINGS3 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write DISCRETE_INPUTS_SETTINGS3 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS3 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS3 for out of range value");
    }

	  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write DISCRETE_INPUTS_SETTINGS4 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write DISCRETE_INPUTS_SETTINGS4 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS4 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS4 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,6, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write DISCRETE_INPUTS_SETTINGS5 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,6, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write DISCRETE_INPUTS_SETTINGS5 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,6, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS5 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DISCRETE_INPUTS_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGSInfo->parameter_index,6, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write DISCRETE_INPUTS_SETTINGS5 for out of range value");
    }
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_MAXIMUM_TORQUEInfo = $o_TBInfo->get_param_info("MAXIMUM_TORQUE");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUEInfo->parameter_index,0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write OPEN_TORQUE_LIMIT for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MAXIMUM_TORQUEInfo = $o_TBInfo->get_param_info("MAXIMUM_TORQUE");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUEInfo->parameter_index,0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write OPEN_TORQUE_LIMIT for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MAXIMUM_TORQUEInfo = $o_TBInfo->get_param_info("MAXIMUM_TORQUE");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUEInfo->parameter_index,0, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OPEN_TORQUE_LIMIT for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MAXIMUM_TORQUEInfo = $o_TBInfo->get_param_info("MAXIMUM_TORQUE");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUEInfo->parameter_index,0, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OPEN_TORQUE_LIMIT for out of range value");
    }	
	
	  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_STROKE_TIMEInfo = $o_TBInfo->get_param_info("STROKE_TIME");
  $i_integer = pack("n", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIMEInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write STROKE_TIME for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_STROKE_TIMEInfo = $o_TBInfo->get_param_info("STROKE_TIME");
  $i_integer = pack("n", 999);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIMEInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write STROKE_TIME for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_STROKE_TIMEInfo = $o_TBInfo->get_param_info("STROKE_TIME");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIMEInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write STROKE_TIME for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_STROKE_TIMEInfo = $o_TBInfo->get_param_info("STROKE_TIME");
  $i_integer = pack("n", 1000);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIMEInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write STROKE_TIME for out of range value");
    }	
	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_1_STATUS for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_1_STATUS for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_1_STATUS for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_1_STATUS for out of range value");
    } 	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_2_STATUS for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_2_STATUS for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_2_STATUS for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_2_STATUS for out of range value");
    } 
	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_5_STATUS for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_5_STATUS for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_5_STATUS for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_5_STATUS for out of range value");
    } 	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_RELAY_3_STATUSInfo = $o_TBInfo->get_param_info("RELAY_3_STATUS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_3_STATUS for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_3_STATUSInfo = $o_TBInfo->get_param_info("RELAY_3_STATUS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_3_STATUS for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_3_STATUSInfo = $o_TBInfo->get_param_info("RELAY_3_STATUS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_3_STATUS for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_3_STATUSInfo = $o_TBInfo->get_param_info("RELAY_3_STATUS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_3_STATUS for out of range value");
    } 	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_RELAY_4_STATUSInfo = $o_TBInfo->get_param_info("RELAY_4_STATUS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_4_STATUS for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_4_STATUSInfo = $o_TBInfo->get_param_info("RELAY_4_STATUS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_4_STATUS for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_4_STATUSInfo = $o_TBInfo->get_param_info("RELAY_4_STATUS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_4_STATUS for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_4_STATUSInfo = $o_TBInfo->get_param_info("RELAY_4_STATUS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_4_STATUS for out of range value");
    } 		
		
	
}

sub Teardown()
{
  Log("Teardown ADVT test script....");
} 	
