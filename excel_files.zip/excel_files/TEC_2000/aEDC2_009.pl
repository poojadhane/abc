#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify RW access each TB block parameter according to the modes defined in 
 #          parameter table.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $i_allowed_mode;
 my $i;
 my @i_allowed_mode;
 my $o_TAGDESCInfo;
 my $o_ALERTKEYInfo;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = 1200;#ff_tools::od::index::sod::get("TRANSDUCER_BLOCK %s mode",0);
   $i_ResourceBlkIndex = 1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK %s mode",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "TEC2000";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE1.xls");
     

}
 sub Run() 
 { 
 
  my $o_ModeblkInfo = $o_RBInfo->get_param_info("MODE_BLK");
  my $o_TBModeblkInfo = $o_TBInfo->get_param_info("MODE_BLK");
  my @i_allowed_mode = (OOS,AUTO,MAN);
  my @i_allow_mode_string = ("OS %s mode","AUTO %s mode","MAN");
  my $o_RBBlkMode = new ff_tools::od::fbap::blocks::mode_blk();
  $o_RBBlkMode = ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, AUTO);
  if (!(ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, AUTO)))
  {
   print("\n-> Test FAILED :Unable to set RB in AUTO mode");
  }
  
  #@i_allowed_mode = $i_allowed_mode;
  for (my $i=0; $i<=length(@i_allowed_mode); $i++)
  {
    if (!(ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_TBBlkIndex + $o_TBModeblkInfo->parameter_index, $i_allowed_mode[$i])))
    {
     print("\n-> Test FAILED :Unable to set TB in  %s mode", $i_allow_mode_string[$i]);
    }

    $o_TAGDESCInfo = $o_TBInfo->get_param_info("TAG_DESC");
    if ($o_TAGDESCInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TAGDESCInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to TAG DESC in  %s mode", $i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TAGDESCInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to TAG DESC %s mode", $i_allowed_mode[$i]);
      }
    }

    my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
    if ($o_STRATEGYInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to STRATEGY  %s mode", $i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to STRATEGY %s mode", $i_allowed_mode[$i]);
      }
    }

    my $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
    if ($o_ALERTKEYInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ALERT KEY %s mode", $i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ALERT KEY %s mode", $i_allowed_mode[$i]);
      }
    }
	
    my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    if ($o_ACTUATOR_MODEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ACTUATOR_MODE %s mode",$i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ACTUATOR_MODE %s mode",$i_allowed_mode[$i]);
      }
    }	

    my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
    if ($o_CONTROL_MODEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to CONTROL_MODE %s mode",$i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to CONTROL_MODE %s mode", $i_allowed_mode[$i]);
      }
    }


    my $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
    if ($o_ESD_DELAYInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read toESD_DELAY %s mode", $i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write toESD_DELAY %s mode", $i_allowed_mode[$i]);
      }
    }


    my $o_ESD_OVERRIDESInfo = $o_TBInfo->get_param_info("ESD_OVERRIDES");
    if ($o_ESD_OVERRIDESInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_OVERRIDESInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read toESD_OVERRIDES %s mode",$i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_OVERRIDESInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write toESD_OVERRIDES %s mode",$i_allowed_mode[$i]);
      }
    }


    my $o_ENABLE_PSTInfo = $o_TBInfo->get_param_info("ENABLE_PST");
    if ($o_ENABLE_PSTInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PSTInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_PST %s mode",$i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PSTInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_PST %s mode",$i_allowed_mode[$i]);
      }
    }


    my $o_ANALOG_CONTROL_SOURCEInfo = $o_TBInfo->get_param_info("ANALOG_CONTROL_SOURCE");
    if ($o_ANALOG_CONTROL_SOURCEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_CONTROL_SOURCE %s mode",$i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_CONTROL_SOURCE %s mode",$i_allowed_mode[$i]);
      }
    }


    my $o_MAXIMUM_TORQUEInfo = $o_TBInfo->get_param_info("MAXIMUM_TORQUE");
    if ($o_MAXIMUM_TORQUEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to MAXIMUM_TORQUE %s mode",$i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to MAXIMUM_TORQUE %s mode",$i_allowed_mode[$i]);
      }
    }


    my $o_STROKE_TIMEInfo = $o_TBInfo->get_param_info("STROKE_TIME");
    if ($o_STROKE_TIMEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIMEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to STROKE_TIME %s mode",$i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIMEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to STROKE_TIME %s mode",$i_allowed_mode[$i]);
      }
    }


    my $o_ENABLE_RDMSInfo = $o_TBInfo->get_param_info("ENABLE_RDMS");
    if ($o_ENABLE_RDMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_RDMSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_RDMS %s mode",$i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_RDMSInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_RDMS %s mode",$i_allowed_mode[$i]);
      }
    }



    my $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
    if ($o_CONFIGURATION_COMMANDSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to CONFIGURATION_COMMANDS %s mode",$i_allowed_mode[$i]);
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to CONFIGURATION_COMMANDS %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOG_JAM %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOG_JAM %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to REMOTE_CONTROL_SIGNAL %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to REMOTE_CONTROL_SIGNAL %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to LOCAL_CONTROL_SIGNAL %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to LOCAL_CONTROL_SIGNAL %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to BACKSEAT %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to BACKSEAT %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to SEATING %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to SEATING %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
    if ($o_CONTROL_PARAM_2Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to LED_COLOR %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to LED_COLOR %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
    if ($o_CONTROL_PARAM_2Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOW_BATTERY_ALARM %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOW_BATTERY_ALARM %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
    if ($o_MODULATION_PARAMETERSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to POSITION_CONTROL_BANDWIDTH %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to POSITION_CONTROL_BANDWIDTH %s mode",$i_allowed_mode[$i]);
      }
    }

     $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
    if ($o_MODULATION_PARAMETERSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to SPEED_CONTROL_BANDWIDTH %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to SPEED_CONTROL_BANDWIDTH %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
    if ($o_MODULATION_PARAMETERSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to MODULATION_DELAY %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to MODULATION_DELAY %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to LOST_ANALOG_INPUT_ACTION %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to LOST_ANALOG_INPUT_ACTION %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOST_ANALOG_INPUT_1_ALARM %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOST_ANALOG_INPUT_1_ALARM %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOST_ANALOG_INPUT_2_ALARM %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOST_ANALOG_INPUT_2_ALARM %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_OUTPUT_1_SOURCE %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_1_SOURCE %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_OUTPUT_2_SOURCE %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_2_SOURCE %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
    if ($o_LIMIT_SWITCH_TRIGGER_POINTSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to LIMIT_SWITCH_A_TRIGGER_POINT %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to LIMIT_SWITCH_A_TRIGGER_POINT %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
    if ($o_LIMIT_SWITCH_TRIGGER_POINTSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to LIMIT_SWITCH_B_TRIGGER_POINT %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to LIMIT_SWITCH_B_TRIGGER_POINT %s mode",$i_allowed_mode[$i]);
      }
    }




    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS0 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS0 %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS1 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS1 %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS2 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS2 %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS3 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS3 %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS4 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS4 %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS0 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS0 %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS1 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS1 %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS2 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS2 %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS3 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS3 %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS4 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS4 %s mode",$i_allowed_mode[$i]);
      }
    }


    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to OPEN_SPEED_CONTROL ENABLE_SPEED_CONTROL %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to OPEN_SPEED_CONTROL ENABLE_SPEED_CONTROL %s mode",$i_allowed_mode[$i]);
      }
    }


     $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to OPEN_SPEED_CONTROL START_POSITION %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to OPEN_SPEED_CONTROL START_POSITION %s mode",$i_allowed_mode[$i]);
      }
    }


    $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to OPEN_SPEED_CONTROL STOP_POSITION %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to OPEN_SPEED_CONTROL STOP_POSITION %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to OPEN_SPEED_CONTROL ON_TIME %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to OPEN_SPEED_CONTROL ON_TIME %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to OPEN_SPEED_CONTROL OFF_TIME %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to OPEN_SPEED_CONTROL OFF_TIME %s mode",$i_allowed_mode[$i]);
      }
    }


    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to CLOSE_SPEED_CONTROL ENABLE_SPEED_CONTROL %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to CLOSE_SPEED_CONTROL ENABLE_SPEED_CONTROL %s mode",$i_allowed_mode[$i]);
      }
    }


    $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to CLOSE_SPEED_CONTROL START_POSITION %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to CLOSE_SPEED_CONTROL START_POSITION %s mode",$i_allowed_mode[$i]);
      }
    }


    $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to CLOSE_SPEED_CONTROL STOP_POSITION %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to CLOSE_SPEED_CONTROL STOP_POSITION %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to CLOSE_SPEED_CONTROL ON_TIME %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to CLOSE_SPEED_CONTROL ON_TIME %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to CLOSE_SPEED_CONTROL OFF_TIME %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to CLOSE_SPEED_CONTROL OFF_TIME %s mode",$i_allowed_mode[$i]);
      }
    }


    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
    if ($o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ANTI_WATER_HAMMER_SPEED_CONTROL ENABLE_SPEED_CONTROL %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ANTI_WATER_HAMMER_SPEED_CONTROL ENABLE_SPEED_CONTROL %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
    if ($o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ANTI_WATER_HAMMER_SPEED_CONTROL START_POSITION %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ANTI_WATER_HAMMER_SPEED_CONTROL START_POSITION %s mode",$i_allowed_mode[$i]);
      }
    }


    $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
    if ($o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ANTI_WATER_HAMMER_SPEED_CONTROL  ON_TIME %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ANTI_WATER_HAMMER_SPEED_CONTROL ON_TIME %s mode",$i_allowed_mode[$i]);
      }
    }


    $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
    if ($o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ANTI_WATER_HAMMER_SPEED_CONTROL OFF_TIME %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ANTI_WATER_HAMMER_SPEED_CONTROL OFF_TIME %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
    if ($o_DEFAULT_SETPOINTInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to DEFAULT_SETPOINT_1 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to DEFAULT_SETPOINT_1 %s mode",$i_allowed_mode[$i]);
      }
    }


    my $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
    if ($o_FACTORY_SOFTWAREInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to TAG %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to TAG %s mode",$i_allowed_mode[$i]);
      }
    }


    $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
    if ($o_FACTORY_SOFTWAREInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to SERIAL_NUMBER %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to SERIAL_NUMBER %s mode",$i_allowed_mode[$i]);
      }
    }


    $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
    if ($o_FACTORY_SOFTWAREInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to MODEL %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to MODEL %s mode",$i_allowed_mode[$i]);
      }
    }


    $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
    if ($o_FACTORY_SOFTWAREInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to MANUFACTURE_DATE %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to MANUFACTURE_DATE %s mode",$i_allowed_mode[$i]);
      }
    }


    my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
    if ($o_TORQUE_LIMITInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to CLOSE_TORQUE_LIMIT %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to CLOSE_TORQUE_LIMIT %s mode",$i_allowed_mode[$i]);
      }
    }

    $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
    if ($o_TORQUE_LIMITInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to OPEN_TORQUE_LIMIT %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to OPEN_TORQUE_LIMIT %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
    if ($o_HOST_COMMAND_ESDInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to HOST_COMMAND_ESD %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to HOST_COMMAND_ESD %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
    if ($o_RELAY_1_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_1_STATUS %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_1_STATUS %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
    if ($o_RELAY_2_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_2_STATUS %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_2_STATUS %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_RELAY_3_STATUSInfo = $o_TBInfo->get_param_info("RELAY_3_STATUS");
    if ($o_RELAY_3_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_3_STATUS %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_3_STATUS %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_RELAY_4_STATUSInfo = $o_TBInfo->get_param_info("RELAY_4_STATUS");
    if ($o_RELAY_4_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_4_STATUS %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_4_STATUS %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
    if ($o_RELAY_5_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to RELAY_5_STATUS %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to RELAY_5_STATUS %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
    if ($o_ANALOG_OUTPUT_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_OUTPUT_1 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_1 %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_ANALOG_OUTPUT_2Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_2");
    if ($o_ANALOG_OUTPUT_2Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_2Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_OUTPUT_2 %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_2Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_2 %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
    if ($o_SETPOINTInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to SETPOINT %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to SETPOINT %s mode",$i_allowed_mode[$i]);
      }
    }

    my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
    if ($o_ACTUATOR_COMMANDInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for read to ACTUATOR_COMMAND %s mode",$i_allowed_mode[$i]);
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
       print("\n-> Test FAILED :Expected confirm positive for write to ACTUATOR_COMMAND %s mode",$i_allowed_mode[$i]);
      }
    }
 }
}


sub Teardown()
{
  Log("Teardown ADVT test script....");
}