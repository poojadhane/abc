#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify that each TEC 2000 actuator block parameters are initialized with an initial value defined
 #          in Parameter Table when RESTART with Defaults parameter in resource Blocks is selected.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

 use constant RESTART_WITH_DEFAULT               => 3;
 use constant MIB_PROFILE_NO                     => 0x4D47;
 use constant FBAP_PROFILE_NO                    => 0;
 use constant OD_VERSION                         => 1;
 use constant ABORT_REASON                       => 0x01;
 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
#================================== Test case =================================#
sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex = ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "TEC_2000";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_SifAIFBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE.xls");
     
   my $o_RBRestartParamInfo = $o_RBInfo->get_param_info("RESTART"); 
   my $s_ProcRestart = pack("C", RESTART_WITH_DEFAULT);
   ff_tools::hostapi::api::Write($i_DutFbapVcrId,$o_RBInfo->od_index + $o_RBRestartParamInfo->parameter_index,0,length($s_ProcRestart),$s_ProcRestart);
   ff_tools::hostapi::api::Abort($i_DutFbapVcrId,   ABORT_REASON);
   ff_tools::hostapi::api::Abort($i_DutMibVcrId,    ABORT_REASON);
   
   ff_tools::hostapi::api::WaitForInd($ff_tools::hostapi::SERVICE_CODE_SM_NEW_NODE_EVENT, 1000);
 
   ff_tools::hostapi::api::Initiate($i_DutFbapVcrId,  OD_VERSION, MIB_PROFILE_NO);
   ff_tools::hostapi::api::Initiate($i_DutMibVcrId, OD_VERSION, FBAP_PROFILE_NO);
 }
 sub Run() 
 { 
 
   my $o_ST REV= $o_TBInfo->get_param_info("ST REV"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ST REV->parameter_index, 0);
   my  $i_ST REV = unpack("n", $rh_Result->{"Confirm"}->Data);
   if ($i_ST REV != $o_ST REV->default_value)
   {
     fail("Wrong default value for ST REV"); 

   }


   my $o_TAG DESC= $o_TBInfo->get_param_info("TAG DESC"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TAG DESC->parameter_index, 0);
   my  $i_TAG DESC = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_TAG DESC != $o_TAG DESC->default_value)
   {
     fail("Wrong default value for TAG DESC"); 

   }


   my $o_STRATEGY= $o_TBInfo->get_param_info("STRATEGY"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGY->parameter_index, 0);
   my  $i_STRATEGY = unpack("n", $rh_Result->{"Confirm"}->Data);
   if ($i_STRATEGY != $o_STRATEGY->default_value)
   {
     fail("Wrong default value for STRATEGY"); 

   }


   my $o_ALERT KEY= $o_TBInfo->get_param_info("ALERT KEY"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT KEY->parameter_index, 0);
   my  $i_ALERT KEY = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ALERT KEY != $o_ALERT KEY->default_value)
   {
     fail("Wrong default value for ALERT KEY"); 

   }


   my $o_FF_FUNCTION_TYPE= $o_TBInfo->get_param_info("FF_FUNCTION_TYPE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FF_FUNCTION_TYPE->parameter_index, 0);
   my  $i_FF_FUNCTION_TYPE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_FF_FUNCTION_TYPE != $o_FF_FUNCTION_TYPE->default_value)
   {
     fail("Wrong default value for FF_FUNCTION_TYPE"); 

   }


   my $o_COMPATIBILITY_NUMBER= $o_TBInfo->get_param_info("COMPATIBILITY_NUMBER"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_COMPATIBILITY_NUMBER->parameter_index, 0);
   my  $i_COMPATIBILITY_NUMBER = unpack("n", $rh_Result->{"Confirm"}->Data);
   if ($i_COMPATIBILITY_NUMBER != $o_COMPATIBILITY_NUMBER->default_value)
   {
     fail("Wrong default value for COMPATIBILITY_NUMBER"); 

   }


   my $o_CONTROL_MODE= $o_TBInfo->get_param_info("CONTROL_MODE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODE->parameter_index, 0);
   my  $i_CONTROL_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_CONTROL_MODE != $o_CONTROL_MODE->default_value)
   {
     fail("Wrong default value for CONTROL_MODE"); 

   }


   my $o_ACTUATOR_MODE= $o_TBInfo->get_param_info("ACTUATOR_MODE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODE->parameter_index, 0);
   my  $i_ACTUATOR_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ACTUATOR_MODE != $o_ACTUATOR_MODE->default_value)
   {
     fail("Wrong default value for ACTUATOR_MODE"); 

   }


   my $o_ESD_DELAY= $o_TBInfo->get_param_info("ESD_DELAY"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAY->parameter_index, 0);
   my  $i_ESD_DELAY = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ESD_DELAY != $o_ESD_DELAY->default_value)
   {
     fail("Wrong default value for ESD_DELAY"); 

   }


   my $o_MAXIMUM_TORQUE= $o_TBInfo->get_param_info("MAXIMUM_TORQUE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUE->parameter_index, 0);
   my  $f_MAXIMUM_TORQUE = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_MAXIMUM_TORQUE != $o_MAXIMUM_TORQUE->default_value)
   {
     fail("Wrong default value for MAXIMUM_TORQUE"); 

   }


   my $o_TORQUE_OUT_OF_RANGE= $o_TBInfo->get_param_info("TORQUE_OUT_OF_RANGE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_OUT_OF_RANGE->parameter_index, 0);
   my  $i_TORQUE_OUT_OF_RANGE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_TORQUE_OUT_OF_RANGE != $o_TORQUE_OUT_OF_RANGE->default_value)
   {
     fail("Wrong default value for TORQUE_OUT_OF_RANGE"); 

   }


   my $o_STROKE_TIME= $o_TBInfo->get_param_info("STROKE_TIME"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STROKE_TIME->parameter_index, 0);
   my  $i_STROKE_TIME = unpack("n", $rh_Result->{"Confirm"}->Data);
   if ($i_STROKE_TIME != $o_STROKE_TIME->default_value)
   {
     fail("Wrong default value for STROKE_TIME"); 

   }


   my $o_POSITION= $o_TBInfo->get_param_info("POSITION"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_POSITION->parameter_index, 1);
   my  $i_POSITION = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_POSITION != $o_POSITION->default_value)
   {
     fail("Wrong default value for POSITION"); 

   }


   my $o_CONFIGURATION_COMMANDS= $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDS->parameter_index, 0);
   my  $i_CONFIGURATION_COMMANDS = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_CONFIGURATION_COMMANDS != $o_CONFIGURATION_COMMANDS->default_value)
   {
     fail("Wrong default value for CONFIGURATION_COMMANDS"); 

   }


   my $o_CONTROL_PARAM_1Info= $o_TBInfo->get_param_info("CONTROL_PARAM_1"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1);
   my  $i_ENABLE_LOG_JAM = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ENABLE_LOG_JAM != 0)
 
   {
     fail("Wrong default value for ENABLE_LOG_JAM"); 

   }


   my $o_CONTROL_PARAM_1Info= $o_TBInfo->get_param_info("CONTROL_PARAM_1"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2);
   my  $i_REMOTE_CONTROL_SIGNAL = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_REMOTE_CONTROL_SIGNAL != 0)
 
   {
     fail("Wrong default value for REMOTE_CONTROL_SIGNAL"); 

   }


   my $o_CONTROL_PARAM_1Info= $o_TBInfo->get_param_info("CONTROL_PARAM_1"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3);
   my  $i_LOCAL_CONTROL_SIGNAL = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_LOCAL_CONTROL_SIGNAL != 0)
 
   {
     fail("Wrong default value for LOCAL_CONTROL_SIGNAL"); 

   }


   my $o_CONTROL_PARAM_1Info= $o_TBInfo->get_param_info("CONTROL_PARAM_1"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4);
   my  $i_BACKSEAT = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_BACKSEAT != 0)
 
   {
     fail("Wrong default value for BACKSEAT"); 

   }


   my $o_CONTROL_PARAM_1Info= $o_TBInfo->get_param_info("CONTROL_PARAM_1"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5);
   my  $i_SEATING = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_SEATING != 0)
 
   {
     fail("Wrong default value for SEATING"); 

   }


   my $o_CONTROL_PARAM_2Info= $o_TBInfo->get_param_info("CONTROL_PARAM_2"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1);
   my  $i_LED_COLOR = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_LED_COLOR != 1)
 
   {
     fail("Wrong default value for LED_COLOR"); 

   }


   my $o_CONTROL_PARAM_2Info= $o_TBInfo->get_param_info("CONTROL_PARAM_2"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2);
   my  $i_ENABLE_LOW_BATTERY_ALARM = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ENABLE_LOW_BATTERY_ALARM != 0)
 
   {
     fail("Wrong default value for ENABLE_LOW_BATTERY_ALARM"); 

   }


   my $o_MODULATION_PARAMETERSInfo= $o_TBInfo->get_param_info("MODULATION_PARAMETERS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1);
   my  $f_POSITION_CONTROL_BANDWIDTH = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_POSITION_CONTROL_BANDWIDTH != 10)
 
   {
     fail("Wrong default value for POSITION_CONTROL_BANDWIDTH"); 

   }


   my $o_MODULATION_PARAMETERSInfo= $o_TBInfo->get_param_info("MODULATION_PARAMETERS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2);
   my  $f_SPEED_CONTROL_BANDWIDTH = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_SPEED_CONTROL_BANDWIDTH != 10)
 
   {
     fail("Wrong default value for SPEED_CONTROL_BANDWIDTH"); 

   }


   my $o_MODULATION_PARAMETERSInfo= $o_TBInfo->get_param_info("MODULATION_PARAMETERS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3);
   my  $f_MODULATION_DELAY = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_MODULATION_DELAY != 4)
 
   {
     fail("Wrong default value for MODULATION_DELAY"); 

   }


   my $o_ANALOG_PARAMSInfo= $o_TBInfo->get_param_info("ANALOG_PARAMS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1);
   my  $i_LOST_ANALOG_INPUT_ACTION = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_LOST_ANALOG_INPUT_ACTION != 0)
 
   {
     fail("Wrong default value for LOST_ANALOG_INPUT_ACTION"); 

   }


   my $o_ANALOG_PARAMSInfo= $o_TBInfo->get_param_info("ANALOG_PARAMS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3);
   my  $i_ENABLE_LOST_ANALOG_INPUT_1_ALARM = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ENABLE_LOST_ANALOG_INPUT_1_ALARM != 0)
 
   {
     fail("Wrong default value for ENABLE_LOST_ANALOG_INPUT_1_ALARM"); 

   }


   my $o_ANALOG_PARAMSInfo= $o_TBInfo->get_param_info("ANALOG_PARAMS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4);
   my  $i_ENABLE_LOST_ANALOG_INPUT_2_ALARM = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ENABLE_LOST_ANALOG_INPUT_2_ALARM != 0)
 
   {
     fail("Wrong default value for ENABLE_LOST_ANALOG_INPUT_2_ALARM"); 

   }


   my $o_ANALOG_PARAMSInfo= $o_TBInfo->get_param_info("ANALOG_PARAMS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5);
   my  $i_ANALOG_OUTPUT_1_SOURCE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ANALOG_OUTPUT_1_SOURCE != 0)
 
   {
     fail("Wrong default value for ANALOG_OUTPUT_1_SOURCE"); 

   }


   my $o_ANALOG_PARAMSInfo= $o_TBInfo->get_param_info("ANALOG_PARAMS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 6);
   my  $i_ANALOG_OUTPUT_2_SOURCE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ANALOG_OUTPUT_2_SOURCE != 0)
 
   {
     fail("Wrong default value for ANALOG_OUTPUT_2_SOURCE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 1);
   my  $i_VOLTAGE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_VOLTAGE != 460)
 
   {
     fail("Wrong default value for VOLTAGE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 2);
   my  $i_FREQUENCY = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_FREQUENCY != 60)
 
   {
     fail("Wrong default value for FREQUENCY"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 3);
   my  $i_THREE_PHASE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_THREE_PHASE != 1)
 
   {
     fail("Wrong default value for THREE_PHASE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 4);
   my  $i_AUXILIARY_CONTROL_MODULE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_AUXILIARY_CONTROL_MODULE != 1)
 
   {
     fail("Wrong default value for AUXILIARY_CONTROL_MODULE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 5);
   my  $i_NETWORK_ADAPTER = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_NETWORK_ADAPTER != 7)
 
   {
     fail("Wrong default value for NETWORK_ADAPTER"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 6);
   my  $i_STARTER_TYPE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_STARTER_TYPE != 2)
 
   {
     fail("Wrong default value for STARTER_TYPE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 7);
   my  $i_TORQUE_SPRING = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_TORQUE_SPRING != 8)
 
   {
     fail("Wrong default value for TORQUE_SPRING"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 8);
   my  $i_MOTOR_TYPE_(MPA)_MOTOR = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_MOTOR_TYPE_(MPA)_MOTOR != 0x20202020202020202020)
 
   {
     fail("Wrong default value for MOTOR_TYPE_(MPA)_MOTOR"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 9);
   my  $i_HORSE_POWER = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_HORSE_POWER != 0x2020202020)
 
   {
     fail("Wrong default value for HORSE_POWER"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 10);
   my  $i_RPM = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_RPM != 0x20202020)
 
   {
     fail("Wrong default value for RPM"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 11);
   my  $i_RUNNING_AMPS = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_RUNNING_AMPS != 0x20202020)
 
   {
     fail("Wrong default value for RUNNING_AMPS"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 12);
   my  $i_STALLED_AMPS = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_STALLED_AMPS != 0x20202020)
 
   {
     fail("Wrong default value for STALLED_AMPS"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 13);
   my  $i_WORM_GEAR = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_WORM_GEAR != 1)
 
   {
     fail("Wrong default value for WORM_GEAR"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 14);
   my  $i_DRIVE_SLEEVE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DRIVE_SLEEVE != 0)
 
   {
     fail("Wrong default value for DRIVE_SLEEVE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 15);
   my  $i_ENABLE_AUXILIARY_RELAY_MODULE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ENABLE_AUXILIARY_RELAY_MODULE != 0)
 
   {
     fail("Wrong default value for ENABLE_AUXILIARY_RELAY_MODULE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 16);
   my  $i_ENABLE_REVERSE_MOTOR_ROTATION = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ENABLE_REVERSE_MOTOR_ROTATION != 0)
 
   {
     fail("Wrong default value for ENABLE_REVERSE_MOTOR_ROTATION"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 17);
   my  $i_ACTUATOR_TYPE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ACTUATOR_TYPE != 1)
 
   {
     fail("Wrong default value for ACTUATOR_TYPE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 18);
   my  $i_APD_GEAR_RATIO = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_APD_GEAR_RATIO != 1)
 
   {
     fail("Wrong default value for APD_GEAR_RATIO"); 

   }


   my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo= $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1);
   my  $f_LIMIT_SWITCH_A_TRIGGER_POINT = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_LIMIT_SWITCH_A_TRIGGER_POINT != 25)
 
   {
     fail("Wrong default value for LIMIT_SWITCH_A_TRIGGER_POINT"); 

   }


   my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo= $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2);
   my  $f_LIMIT_SWITCH_B_TRIGGER_POINT = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_LIMIT_SWITCH_B_TRIGGER_POINT != 75)
 
   {
     fail("Wrong default value for LIMIT_SWITCH_B_TRIGGER_POINT"); 

   }


   my $o_DISCRETE_INPUT_FUNCTIONSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 1);
   my  $i_DISCRETE_INPUT_FUNCTIONS0 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_FUNCTIONS0 != 1)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_FUNCTIONS0"); 

   }


   my $o_DISCRETE_INPUT_FUNCTIONSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 2);
   my  $i_DISCRETE_INPUT_FUNCTIONS1 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_FUNCTIONS1 != 2)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_FUNCTIONS1"); 

   }


   my $o_DISCRETE_INPUT_FUNCTIONSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 3);
   my  $i_DISCRETE_INPUT_FUNCTIONS2 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_FUNCTIONS2 != 3)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_FUNCTIONS2"); 

   }


   my $o_DISCRETE_INPUT_FUNCTIONSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 4);
   my  $i_DISCRETE_INPUT_FUNCTIONS3 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_FUNCTIONS3 != 4)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_FUNCTIONS3"); 

   }


   my $o_DISCRETE_INPUT_FUNCTIONSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 5);
   my  $i_DISCRETE_INPUT_FUNCTIONS4 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_FUNCTIONS4 != 5)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_FUNCTIONS4"); 

   }


   my $o_DISCRETE_INPUT_FUNCTIONSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 6);
   my  $i_DISCRETE_INPUT_FUNCTIONS5 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_FUNCTIONS5 != 6)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_FUNCTIONS5"); 

   }


   my $o_DISCRETE_INPUT_SETTINGSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 1);
   my  $i_DISCRETE_INPUT_SETTINGS0 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_SETTINGS0 != 0)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_SETTINGS0"); 

   }


   my $o_DISCRETE_INPUT_SETTINGSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 2);
   my  $i_DISCRETE_INPUT_SETTINGS1 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_SETTINGS1 != 0)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_SETTINGS1"); 

   }


   my $o_DISCRETE_INPUT_SETTINGSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 3);
   my  $i_DISCRETE_INPUT_SETTINGS2 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_SETTINGS2 != 1)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_SETTINGS2"); 

   }


   my $o_DISCRETE_INPUT_SETTINGSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 4);
   my  $i_DISCRETE_INPUT_SETTINGS3 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_SETTINGS3 != 0)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_SETTINGS3"); 

   }


   my $o_DISCRETE_INPUT_SETTINGSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 5);
   my  $i_DISCRETE_INPUT_SETTINGS4 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_SETTINGS4 != 0)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_SETTINGS4"); 

   }


   my $o_DISCRETE_INPUT_SETTINGSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 6);
   my  $i_DISCRETE_INPUT_SETTINGS5 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_SETTINGS5 != 1)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_SETTINGS5"); 

   }


   my $o_RELAY_SETTINGSInfo= $o_TBInfo->get_param_info("RELAY_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1);
   my  $i_RELAY_SETTINGS0 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_SETTINGS0 != 2)
 
   {
     fail("Wrong default value for RELAY_SETTINGS0"); 

   }


   my $o_RELAY_SETTINGSInfo= $o_TBInfo->get_param_info("RELAY_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2);
   my  $i_RELAY_SETTINGS1 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_SETTINGS1 != 2)
 
   {
     fail("Wrong default value for RELAY_SETTINGS1"); 

   }


   my $o_RELAY_SETTINGSInfo= $o_TBInfo->get_param_info("RELAY_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3);
   my  $i_RELAY_SETTINGS2 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_SETTINGS2 != 2)
 
   {
     fail("Wrong default value for RELAY_SETTINGS2"); 

   }


   my $o_RELAY_SETTINGSInfo= $o_TBInfo->get_param_info("RELAY_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4);
   my  $i_RELAY_SETTINGS3 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_SETTINGS3 != 2)
 
   {
     fail("Wrong default value for RELAY_SETTINGS3"); 

   }


   my $o_RELAY_SETTINGSInfo= $o_TBInfo->get_param_info("RELAY_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5);
   my  $i_RELAY_SETTINGS4 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_SETTINGS4 != 0)
 
   {
     fail("Wrong default value for RELAY_SETTINGS4"); 

   }


   my $o_RELAY_FUNCTIONSInfo= $o_TBInfo->get_param_info("RELAY_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1);
   my  $i_RELAY_FUNCTIONS0 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_FUNCTIONS0 != 0)
 
   {
     fail("Wrong default value for RELAY_FUNCTIONS0"); 

   }


   my $o_RELAY_FUNCTIONSInfo= $o_TBInfo->get_param_info("RELAY_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2);
   my  $i_RELAY_FUNCTIONS1 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_FUNCTIONS1 != 1)
 
   {
     fail("Wrong default value for RELAY_FUNCTIONS1"); 

   }


   my $o_RELAY_FUNCTIONSInfo= $o_TBInfo->get_param_info("RELAY_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3);
   my  $i_RELAY_FUNCTIONS2 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_FUNCTIONS2 != 0)
 
   {
     fail("Wrong default value for RELAY_FUNCTIONS2"); 

   }


   my $o_RELAY_FUNCTIONSInfo= $o_TBInfo->get_param_info("RELAY_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4);
   my  $i_RELAY_FUNCTIONS3 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_FUNCTIONS3 != 1)
 
   {
     fail("Wrong default value for RELAY_FUNCTIONS3"); 

   }


   my $o_RELAY_FUNCTIONSInfo= $o_TBInfo->get_param_info("RELAY_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5);
   my  $i_RELAY_FUNCTIONS4 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_FUNCTIONS4 != 39)
 
   {
     fail("Wrong default value for RELAY_FUNCTIONS4"); 

   }


   my $o_OPEN_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 1);
   my  $i_ENABLE_SPEED_CONTROL = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ENABLE_SPEED_CONTROL != 1)
 
   {
     fail("Wrong default value for ENABLE_SPEED_CONTROL"); 

   }


   my $o_OPEN_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 2);
   my  $f_START_POSITION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_START_POSITION != 70)
 
   {
     fail("Wrong default value for START_POSITION"); 

   }


   my $o_OPEN_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 3);
   my  $f_STOP_POSITION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_STOP_POSITION != 99)
 
   {
     fail("Wrong default value for STOP_POSITION"); 

   }


   my $o_OPEN_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4);
   my  $f_ON_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_ON_TIME != 14)
 
   {
     fail("Wrong default value for ON_TIME"); 

   }


   my $o_OPEN_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5);
   my  $f_OFF_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_OFF_TIME != 20)
 
   {
     fail("Wrong default value for OFF_TIME"); 

   }


   my $o_CLOSE_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 1);
   my  $i_ENABLE_SPEED_CONTROL = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ENABLE_SPEED_CONTROL != 1)
 
   {
     fail("Wrong default value for ENABLE_SPEED_CONTROL"); 

   }


   my $o_CLOSE_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 2);
   my  $f_START_POSITION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_START_POSITION != 30)
 
   {
     fail("Wrong default value for START_POSITION"); 

   }


   my $o_CLOSE_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 3);
   my  $f_STOP_POSITION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_STOP_POSITION != 1)
 
   {
     fail("Wrong default value for STOP_POSITION"); 

   }


   my $o_CLOSE_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4);
   my  $f_ON_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_ON_TIME != 14)
 
   {
     fail("Wrong default value for ON_TIME"); 

   }


   my $o_CLOSE_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5);
   my  $f_OFF_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_OFF_TIME != 20)
 
   {
     fail("Wrong default value for OFF_TIME"); 

   }


   my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 1);
   my  $i_ENABLE_SPEED_CONTROL = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ENABLE_SPEED_CONTROL != 1)
 
   {
     fail("Wrong default value for ENABLE_SPEED_CONTROL"); 

   }


   my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2);
   my  $f_START_POSITION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_START_POSITION != 10)
 
   {
     fail("Wrong default value for START_POSITION"); 

   }


   my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 3);
   my  $f_STOP_POSITION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_STOP_POSITION != 0)
 
   {
     fail("Wrong default value for STOP_POSITION"); 

   }


   my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4);
   my  $f_ON_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_ON_TIME != 14)
 
   {
     fail("Wrong default value for ON_TIME"); 

   }


   my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5);
   my  $f_OFF_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_OFF_TIME != 20)
 
   {
     fail("Wrong default value for OFF_TIME"); 

   }


   my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 6);
   my  $f_DUTY_CYCLE = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_DUTY_CYCLE != 50)
 
   {
     fail("Wrong default value for DUTY_CYCLE"); 

   }


   my $o_OPERATION_LOGSInfo= $o_TBInfo->get_param_info("OPERATION_LOGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATION_LOGSInfo->parameter_index, 1);
   my  $i_CURRENT_RUN_TIME = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_CURRENT_RUN_TIME != 0x00000000000000000000)
 
   {
     fail("Wrong default value for CURRENT_RUN_TIME"); 

   }


   my $o_OPERATION_LOGSInfo= $o_TBInfo->get_param_info("OPERATION_LOGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATION_LOGSInfo->parameter_index, 2);
   my  $i_CURRENT_STARTS = unpack("N", $rh_Result->{"Confirm"}->Data);
   if ($i_CURRENT_STARTS != 0)
 
   {
     fail("Wrong default value for CURRENT_STARTS"); 

   }


   my $o_OPERATION_LOGSInfo= $o_TBInfo->get_param_info("OPERATION_LOGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATION_LOGSInfo->parameter_index, 3);
   my  $i_CURRENT_STROKES = unpack("N", $rh_Result->{"Confirm"}->Data);
   if ($i_CURRENT_STROKES != 0)
 
   {
     fail("Wrong default value for CURRENT_STROKES"); 

   }


   my $o_OPERATION_LOGSInfo= $o_TBInfo->get_param_info("OPERATION_LOGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATION_LOGSInfo->parameter_index, 4);
   my  $i_ARCHIVED_RUN_TIME = unpack("N", $rh_Result->{"Confirm"}->Data);
   if ($i_ARCHIVED_RUN_TIME != 0)
 
   {
     fail("Wrong default value for ARCHIVED_RUN_TIME"); 

   }


   my $o_OPERATION_LOGSInfo= $o_TBInfo->get_param_info("OPERATION_LOGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATION_LOGSInfo->parameter_index, 5);
   my  $i_ARCHIVED_STARTS = unpack("N", $rh_Result->{"Confirm"}->Data);
   if ($i_ARCHIVED_STARTS != 0)
 
   {
     fail("Wrong default value for ARCHIVED_STARTS"); 

   }


   my $o_OPERATION_LOGSInfo= $o_TBInfo->get_param_info("OPERATION_LOGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATION_LOGSInfo->parameter_index, 6);
   my  $i_ARCHIVED_STROKES = unpack("N", $rh_Result->{"Confirm"}->Data);
   if ($i_ARCHIVED_STROKES != 0)
 
   {
     fail("Wrong default value for ARCHIVED_STROKES"); 

   }


   my $o_DEFAULT_SETPOINTInfo= $o_TBInfo->get_param_info("DEFAULT_SETPOINT"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1);
   my  $f_DEFAULT_SETPOINT_1 = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_DEFAULT_SETPOINT_1 != 0)
 
   {
     fail("Wrong default value for DEFAULT_SETPOINT_1"); 

   }


   my $o_FACTORY_SOFTWAREInfo= $o_TBInfo->get_param_info("FACTORY_SOFTWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1);
   my  $i_TAG = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_TAG != 0x20202020202020202020202020202020)
 
   {
     fail("Wrong default value for TAG"); 

   }


   my $o_FACTORY_SOFTWAREInfo= $o_TBInfo->get_param_info("FACTORY_SOFTWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2);
   my  $i_SERIAL_NUMBER = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_SERIAL_NUMBER != 0x20202020202020202020)
 
   {
     fail("Wrong default value for SERIAL_NUMBER"); 

   }


   my $o_FACTORY_SOFTWAREInfo= $o_TBInfo->get_param_info("FACTORY_SOFTWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 3);
   my  $i_MODEL = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_MODEL != 0x20202020202020)
 
   {
     fail("Wrong default value for MODEL"); 

   }


   my $o_FACTORY_SOFTWAREInfo= $o_TBInfo->get_param_info("FACTORY_SOFTWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 4);
   my  $i_MANUFACTURE_DATE = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_MANUFACTURE_DATE != 0x20202020202020202020)
 
   {
     fail("Wrong default value for MANUFACTURE_DATE"); 

   }


   my $o_TORQUE_LIMITInfo= $o_TBInfo->get_param_info("TORQUE_LIMIT"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 1);
   my  $f_CLOSE_TORQUE_LIMIT = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_CLOSE_TORQUE_LIMIT != 50)
 
   {
     fail("Wrong default value for CLOSE_TORQUE_LIMIT"); 

   }


   my $o_TORQUE_LIMITInfo= $o_TBInfo->get_param_info("TORQUE_LIMIT"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2);
   my  $f_OPEN_TORQUE_LIMIT = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_OPEN_TORQUE_LIMIT != 50)
 
   {
     fail("Wrong default value for OPEN_TORQUE_LIMIT"); 

   }


   my $o_POSITIONInfo= $o_TBInfo->get_param_info("POSITION"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_POSITIONInfo->parameter_index, 1);
   my  $i_STATUS = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_STATUS != 0)
 
   {
     fail("Wrong default value for STATUS"); 

   }


   my $o_POSITIONInfo= $o_TBInfo->get_param_info("POSITION"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_POSITIONInfo->parameter_index, 2);
   my  $f_VALUE = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_VALUE != 0)
 
   {
     fail("Wrong default value for VALUE"); 

   }


}


sub Teardown()
{
  Log("Teardown ADVT test script....");
}