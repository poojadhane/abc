#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify RW access each TB block parameter according to the modes defined in 
 #          parameter table.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;
 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $i_allow_mode_string;
 my @i_allow_mode_string;
 my $i_allowed_mode;
 my @i_allowed_mode;
 my $i_integer;
 my $f_float;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = 1200; #ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex = 1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "EHO";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_EHO.xls");
     
}
 sub Run() 
 { 
 
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_ST_REVInfo = $o_TBInfo->get_param_info("ST_REV");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ST_REVInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ST_REV");
      }
      $i_integer = pack("n", $o_ST_REVInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ST_REVInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ST_REV");
      }

      my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to STRATEGY");
      }
      $i_integer = pack("n", $o_STRATEGYInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to STRATEGY");
      }

      my $o_ALERT_KEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT_KEYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ALERT_KEY");
      }
      $i_integer = pack("C", $o_ALERT_KEYInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT_KEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ALERT_KEY");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_TRANSDUCER_DIRECTORYInfo = $o_TBInfo->get_param_info("TRANSDUCER_DIRECTORY");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TRANSDUCER_DIRECTORYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to TRANSDUCER_DIRECTORY");
      }
      $i_integer = pack("n", $o_TRANSDUCER_DIRECTORYInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TRANSDUCER_DIRECTORYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to TRANSDUCER_DIRECTORY");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_TRANSDUCER_TYPEInfo = $o_TBInfo->get_param_info("TRANSDUCER_TYPE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TRANSDUCER_TYPEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to TRANSDUCER_TYPE");
      }
      $i_integer = pack("n", $o_TRANSDUCER_TYPEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TRANSDUCER_TYPEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to TRANSDUCER_TYPE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_COLLECTION_DIRECTORYInfo = $o_TBInfo->get_param_info("COLLECTION_DIRECTORY");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_COLLECTION_DIRECTORYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to COLLECTION_DIRECTORY");
      }
      $i_integer = pack("N", $o_COLLECTION_DIRECTORYInfo->test_value);
 $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_COLLECTION_DIRECTORYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to COLLECTION_DIRECTORY");
      }

      my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CONTROL_MODE");
      }
      $i_integer = pack("C", $o_CONTROL_MODEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CONTROL_MODE");
      }

      my $o_ENABLE_RDMSInfo = $o_TBInfo->get_param_info("ENABLE_RDMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_RDMSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ENABLE_RDMS");
      }
      $i_integer = pack("C", $o_ENABLE_RDMSInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_RDMSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ENABLE_RDMS");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_FF_FUNCTION_TYPEInfo = $o_TBInfo->get_param_info("FF_FUNCTION_TYPE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FF_FUNCTION_TYPEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to FF_FUNCTION_TYPE");
      }
      $i_integer = pack("C", $o_FF_FUNCTION_TYPEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FF_FUNCTION_TYPEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to FF_FUNCTION_TYPE");
      }

      my $o_CUSTOM_CHARACTERIZATION_TYPEInfo = $o_TBInfo->get_param_info("CUSTOM_CHARACTERIZATION_TYPE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CUSTOM_CHARACTERIZATION_TYPEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CUSTOM_CHARACTERIZATION_TYPE");
      }
      $i_integer = pack("C", $o_CUSTOM_CHARACTERIZATION_TYPEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CUSTOM_CHARACTERIZATION_TYPEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CUSTOM_CHARACTERIZATION_TYPE");
      }

      my $o_TARGET_TRAVELInfo = $o_TBInfo->get_param_info("TARGET_TRAVEL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TARGET_TRAVELInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to TARGET_TRAVEL");
      }
      $i_integer = pack("C", $o_TARGET_TRAVELInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TARGET_TRAVELInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to TARGET_TRAVEL");
      }

      my $o_ESD_OVERRIDESInfo = $o_TBInfo->get_param_info("ESD_OVERRIDES");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_OVERRIDESInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ESD_OVERRIDES");
      }
      $i_integer = pack("C", $o_ESD_OVERRIDESInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_OVERRIDESInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ESD_OVERRIDES");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_SOFTWARE_VERSION_IDInfo = $o_TBInfo->get_param_info("SOFTWARE_VERSION_ID");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SOFTWARE_VERSION_IDInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to SOFTWARE_VERSION_ID");
      }
      $i_integer = pack("n", $o_SOFTWARE_VERSION_IDInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SOFTWARE_VERSION_IDInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to SOFTWARE_VERSION_ID");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_COMPATIBILITY_NUMBERInfo = $o_TBInfo->get_param_info("COMPATIBILITY_NUMBER");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_COMPATIBILITY_NUMBERInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to COMPATIBILITY_NUMBER");
      }
      $i_integer = pack("n", $o_COMPATIBILITY_NUMBERInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_COMPATIBILITY_NUMBERInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to COMPATIBILITY_NUMBER");
      }

      my $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ESD_DELAY");
      }
      $i_integer = pack("C", $o_ESD_DELAYInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ESD_DELAY");
      }

      my $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to VALVE_STALL_DELAY_TIME");
      }
      $f_float = pack("C", unpack("V", pack("f",  $o_VALVE_STALL_DELAY_TIMEInfo->test_value)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to VALVE_STALL_DELAY_TIME");
      }

      my $o_ENABLE_PSTInfo = $o_TBInfo->get_param_info("ENABLE_PST");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PSTInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ENABLE_PST");
      }
      $i_integer = pack("C", $o_ENABLE_PSTInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_PSTInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ENABLE_PST");
      }

      my $o_ANALOG_CONTROL_SOURCEInfo = $o_TBInfo->get_param_info("ANALOG_CONTROL_SOURCE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ANALOG_CONTROL_SOURCE");
      }
      $i_integer = pack("C", $o_ANALOG_CONTROL_SOURCEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ANALOG_CONTROL_SOURCE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_MAXIMUM_TORQUEInfo = $o_TBInfo->get_param_info("MAXIMUM_TORQUE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to MAXIMUM_TORQUE");
      }
      $f_float = pack("C", unpack("V", pack("f",  $o_MAXIMUM_TORQUEInfo->test_value)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_TORQUEInfo->parameter_index, 0, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to MAXIMUM_TORQUE");
      }

      my $o_ENABLE_ACCUMULATORInfo = $o_TBInfo->get_param_info("ENABLE_ACCUMULATOR");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_ACCUMULATORInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ENABLE_ACCUMULATOR");
      }
      $i_integer = pack("C", $o_ENABLE_ACCUMULATORInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ENABLE_ACCUMULATORInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ENABLE_ACCUMULATOR");
      }

      my $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo = $o_TBInfo->get_param_info("MAXIMUM_HYDRAULIC_CIRCUIT_PRESSURE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to MAXIMUM_HYDRAULIC_CIRCUIT_PRESSURE");
      }
      $f_float = pack("C", unpack("V", pack("f",  $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo->test_value)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to MAXIMUM_HYDRAULIC_CIRCUIT_PRESSURE");
      }

      my $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo = $o_TBInfo->get_param_info("MAXIMUM_SELF_CALIBRATION_PRESSURE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to MAXIMUM_SELF_CALIBRATION_PRESSURE");
      }
      $f_float = pack("C", unpack("V", pack("f",  $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->test_value)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to MAXIMUM_SELF_CALIBRATION_PRESSURE");
      }

      my $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo = $o_TBInfo->get_param_info("SELF_CALIBRATION_STROKE_COUNT_RANGE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to SELF_CALIBRATION_STROKE_COUNT_RANGE");
      }
      $i_integer = pack("C", $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to SELF_CALIBRATION_STROKE_COUNT_RANGE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_ACTUATOR_FULLY_OPEN_TIMEInfo = $o_TBInfo->get_param_info("ACTUATOR_FULLY_OPEN_TIME");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_FULLY_OPEN_TIMEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ACTUATOR_FULLY_OPEN_TIME");
      }
      $i_integer = pack("C", $o_ACTUATOR_FULLY_OPEN_TIMEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_FULLY_OPEN_TIMEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ACTUATOR_FULLY_OPEN_TIME");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_ACTUATOR_FULLY_CLOSE_TIMEInfo = $o_TBInfo->get_param_info("ACTUATOR_FULLY_CLOSE_TIME");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_FULLY_CLOSE_TIMEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ACTUATOR_FULLY_CLOSE_TIME");
      }
      $i_integer = pack("C", $o_ACTUATOR_FULLY_CLOSE_TIMEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_FULLY_CLOSE_TIMEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ACTUATOR_FULLY_CLOSE_TIME");
      }

      my $o_PRESSURE_UNITInfo = $o_TBInfo->get_param_info("PRESSURE_UNIT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PRESSURE_UNITInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to PRESSURE_UNIT");
      }
      $i_integer = pack("C", $o_PRESSURE_UNITInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PRESSURE_UNITInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to PRESSURE_UNIT");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_BLOCK_ERRInfo = $o_TBInfo->get_param_info("BLOCK_ERR");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLOCK_ERRInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to BLOCK_ERR");
      }
      $i_integer = pack("n", $o_BLOCK_ERRInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLOCK_ERRInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to BLOCK_ERR");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_XD_ERRORInfo = $o_TBInfo->get_param_info("XD_ERROR");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_XD_ERRORInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to XD_ERROR");
      }
      $i_integer = pack("C", $o_XD_ERRORInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_XD_ERRORInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to XD_ERROR");
      }

      my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ACTUATOR_MODE");
      }
      $i_integer = pack("C", $o_ACTUATOR_MODEInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ACTUATOR_MODE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_LIMIT_SWITCH_STATUSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_STATUSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to LIMIT_SWITCH_STATUS");
      }
      $i_integer = pack("C", $o_LIMIT_SWITCH_STATUSInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_STATUSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to LIMIT_SWITCH_STATUS");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_OPEN_TORQUE_PROFILEInfo = $o_TBInfo->get_param_info("OPEN_TORQUE_PROFILE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_TORQUE_PROFILEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPEN_TORQUE_PROFILE");
      }
      $i_integer = pack("C", $o_OPEN_TORQUE_PROFILEInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_TORQUE_PROFILEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to OPEN_TORQUE_PROFILE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_CLOSE_TORQUE_PROFILEInfo = $o_TBInfo->get_param_info("CLOSE_TORQUE_PROFILE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_TORQUE_PROFILEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CLOSE_TORQUE_PROFILE");
      }
      $i_integer = pack("C", $o_CLOSE_TORQUE_PROFILEInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_TORQUE_PROFILEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to CLOSE_TORQUE_PROFILE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_ARCHIVED_OPEN_TORQUE_PROFILEInfo = $o_TBInfo->get_param_info("ARCHIVED_OPEN_TORQUE_PROFILE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ARCHIVED_OPEN_TORQUE_PROFILEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ARCHIVED_OPEN_TORQUE_PROFILE");
      }
      $i_integer = pack("C", $o_ARCHIVED_OPEN_TORQUE_PROFILEInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ARCHIVED_OPEN_TORQUE_PROFILEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ARCHIVED_OPEN_TORQUE_PROFILE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_ARCHIVED_CLOSE_TORQUE_PROFILEInfo = $o_TBInfo->get_param_info("ARCHIVED_CLOSE_TORQUE_PROFILE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ARCHIVED_CLOSE_TORQUE_PROFILEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ARCHIVED_CLOSE_TORQUE_PROFILE");
      }
      $i_integer = pack("C", $o_ARCHIVED_CLOSE_TORQUE_PROFILEInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ARCHIVED_CLOSE_TORQUE_PROFILEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ARCHIVED_CLOSE_TORQUE_PROFILE");
      }

      my $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CONFIGURATION_COMMANDS");
      }
      $i_integer = pack("C", $o_CONFIGURATION_COMMANDSInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CONFIGURATION_COMMANDS");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_FIELD_DIAGNOSTIC_CODEInfo = $o_TBInfo->get_param_info("FIELD_DIAGNOSTIC_CODE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIELD_DIAGNOSTIC_CODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to FIELD_DIAGNOSTIC_CODE");
      }
      $f_float = pack("N", unpack("V", pack("f", $o_FIELD_DIAGNOSTIC_CODEInfo->test_value)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIELD_DIAGNOSTIC_CODEInfo->parameter_index, 0, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to FIELD_DIAGNOSTIC_CODE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_TORQUE_OUT_OF_RANGEInfo = $o_TBInfo->get_param_info("TORQUE_OUT_OF_RANGE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_OUT_OF_RANGEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to TORQUE_OUT_OF_RANGE");
      }
      $i_integer = pack("C", $o_TORQUE_OUT_OF_RANGEInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_OUT_OF_RANGEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to TORQUE_OUT_OF_RANGE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_PROGNOSTICSInfo = $o_TBInfo->get_param_info("PROGNOSTICS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PROGNOSTICSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to PROGNOSTICS");
      }
      $i_integer = pack("n", $o_PROGNOSTICSInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PROGNOSTICSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to PROGNOSTICS");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_SELF_CALIBRATION_STATUSInfo = $o_TBInfo->get_param_info("SELF_CALIBRATION_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STATUSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to SELF_CALIBRATION_STATUS");
      }
      $i_integer = pack("C", $o_SELF_CALIBRATION_STATUSInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STATUSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to SELF_CALIBRATION_STATUS");
      }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CONTROL_PARAM_1 ENABLE_LOG_JAM");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CONTROL_PARAM_1 ENABLE_LOG_JAM");
      }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CONTROL_PARAM_1 REMOTE_CONTROL_SIGNAL");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CONTROL_PARAM_1 REMOTE_CONTROL_SIGNAL");
      }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CONTROL_PARAM_1 LOCAL_CONTROL_SIGNAL");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CONTROL_PARAM_1 LOCAL_CONTROL_SIGNAL");
      }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CONTROL_PARAM_1 BACKSEAT");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CONTROL_PARAM_1 BACKSEAT");
      }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CONTROL_PARAM_1 SEATING");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CONTROL_PARAM_1 SEATING");
      }

    my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CONTROL_PARAM_2 LED_COLOR");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CONTROL_PARAM_2 LED_COLOR");
      }

    my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CONTROL_PARAM_2 ENABLE_LOW_BATTERY_ALARM");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CONTROL_PARAM_2 ENABLE_LOW_BATTERY_ALARM");
      }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to MODULATION_PARAMETERS POSITION_CONTROL_BANDWIDTH");
      }
      $f_float = pack("N", unpack("V", pack("f", 4)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to MODULATION_PARAMETERS POSITION_CONTROL_BANDWIDTH");
      }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to MODULATION_PARAMETERS SPEED_CONTROL_BANDWIDTH");
      }
      $f_float = pack("N", unpack("V", pack("f", 5)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to MODULATION_PARAMETERS SPEED_CONTROL_BANDWIDTH");
      }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ANALOG_PARAMS LOST_ANALOG_INPUT_ACTION");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ANALOG_PARAMS LOST_ANALOG_INPUT_ACTION");
      }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ANALOG_PARAMS ENABLE_LOST_ANALOG_INPUT_1_ALARM");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ANALOG_PARAMS ENABLE_LOST_ANALOG_INPUT_1_ALARM");
      }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ANALOG_PARAMS ANALOG_OUTPUT_1_SOURCE");
      }
      $i_integer = pack("C", 3);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ANALOG_PARAMS ANALOG_OUTPUT_1_SOURCE");
      }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ANALOG_PARAMS ANALOG_OUTPUT_2_SOURCE");
      }
      $i_integer = pack("C", 3);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 6, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ANALOG_PARAMS ANALOG_OUTPUT_2_SOURCE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to FACTORY_HARDWARE VOLTAGE");
      }
      $i_integer = pack("C", 2);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to FACTORY_HARDWARE VOLTAGE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to FACTORY_HARDWARE FREQUENCY");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to FACTORY_HARDWARE FREQUENCY");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to FACTORY_HARDWARE THREE_PHASE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to FACTORY_HARDWARE THREE_PHASE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to FACTORY_HARDWARE NETWORK_ADAPTER");
      }
      $i_integer = pack("C", 10);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to FACTORY_HARDWARE NETWORK_ADAPTER");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to FACTORY_HARDWARE STARTER_TYPE");
      }
      $i_integer = pack("C", 2);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 6, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to FACTORY_HARDWARE STARTER_TYPE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 7);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to FACTORY_HARDWARE TORQUE_SPRING");
      }
      $i_integer = pack("C", 5);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 7, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to FACTORY_HARDWARE TORQUE_SPRING");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 14);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to FACTORY_HARDWARE DRIVE_SLEEVE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 14, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to FACTORY_HARDWARE DRIVE_SLEEVE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 17);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to FACTORY_HARDWARE ACTUATOR_TYPE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 17, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to FACTORY_HARDWARE ACTUATOR_TYPE");
      }

    my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to HOST_COMMAND_ESD VALUE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to HOST_COMMAND_ESD VALUE");
      }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to LIMIT_SWITCH_A_(LSA)_TRIGGER_POINT");
      }
      $f_float = pack("N", unpack("V", pack("f", 20)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to LIMIT_SWITCH_A_(LSA)_TRIGGER_POINT");
      }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to LIMIT_SWITCH_B_(LSB)_TRIGGER_POINT");
      }
      $f_float = pack("N", unpack("V", pack("f", 30)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to LIMIT_SWITCH_B_(LSB)_TRIGGER_POINT");
      }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to LIMIT_SWITCH_OPEN_(LSO)_TRIGGER_POINT");
      }
      $f_float = pack("N", unpack("V", pack("f", 40)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to LIMIT_SWITCH_OPEN_(LSO)_TRIGGER_POINT");
      }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to LIMIT_SWITCH_CLOSE_(LSC)_TRIGGER_POINT");
      }
      $f_float = pack("N", unpack("V", pack("f", 50)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 4, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to LIMIT_SWITCH_CLOSE_(LSC)_TRIGGER_POINT");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_FUNCTIONS0");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS0");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_FUNCTIONS1");
      }
      $i_integer = pack("C", 2);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS1");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_FUNCTIONS2");
      }
      $i_integer = pack("C", 3);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS2");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_FUNCTIONS3");
      }
      $i_integer = pack("C", 4);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS3");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_FUNCTIONS4");
      }
      $i_integer = pack("C", 5);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS4");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_DISCRETE_INPUT_FUNCTIONSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_FUNCTIONS5");
      }
      $i_integer = pack("C", 6);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 6, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_FUNCTIONS5");
      }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_SETTINGS0");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to DISCRETE_INPUT_SETTINGS0");
      }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_SETTINGS1");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to DISCRETE_INPUT_SETTINGS1");
      }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_SETTINGS2");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to DISCRETE_INPUT_SETTINGS2");
      }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_SETTINGS3");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to DISCRETE_INPUT_SETTINGS3");
      }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_SETTINGS4");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to DISCRETE_INPUT_SETTINGS4");
      }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_SETTINGS5");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 6, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to DISCRETE_INPUT_SETTINGS5");
      }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_SETTINGS0");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_SETTINGS0");
      }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_SETTINGS1");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_SETTINGS1");
      }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_SETTINGS2");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_SETTINGS2");
      }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_SETTINGS3");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_SETTINGS3");
      }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_SETTINGS4");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_SETTINGS4");
      }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_FUNCTIONS0");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_FUNCTIONS0");
      }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_FUNCTIONS1");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_FUNCTIONS1");
      }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_FUNCTIONS2");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_FUNCTIONS2");
      }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_FUNCTIONS3");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_FUNCTIONS3");
      }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_FUNCTIONS4");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_FUNCTIONS4");
      }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPEN_SPEED_CONTROL ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to OPEN_SPEED_CONTROL ENABLE_SPEED_CONTROL");
      }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPEN_SPEED_CONTROL START_POSITION");
      }
      $f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to OPEN_SPEED_CONTROL START_POSITION");
      }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPEN_SPEED_CONTROL STOP_POSITION");
      }
      $f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to OPEN_SPEED_CONTROL STOP_POSITION");
      }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPEN_SPEED_CONTROL ON_TIME");
      }
      $f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to OPEN_SPEED_CONTROL ON_TIME");
      }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPEN_SPEED_CONTROLOFF_TIME");
      }
      $f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to OPEN_SPEED_CONTROLOFF_TIME");
      }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPEN_SPEED_CONTROL DUTY_CYCLE");
      }
      $f_float = pack("N", unpack("V", pack("f", 50)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 6, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to OPEN_SPEED_CONTROL DUTY_CYCLE");
      }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CLOSE_SPEED_CONTROL ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CLOSE_SPEED_CONTROL ENABLE_SPEED_CONTROL");
      }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CLOSE_SPEED_CONTROL START_POSITION");
      }
      $f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CLOSE_SPEED_CONTROL START_POSITION");
      }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CLOSE_SPEED_CONTROL STOP_POSITION");
      }
      $f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CLOSE_SPEED_CONTROL STOP_POSITION");
      }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CLOSE_SPEED_CONTROL ON_TIME");
      }
      $f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CLOSE_SPEED_CONTROL ON_TIME");
      }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CLOSE_SPEED_CONTROL OFF_TIME");
      }
      $f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CLOSE_SPEED_CONTROL OFF_TIME");
      }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CLOSE_SPEED_CONTROL DUTY_CYCLE");
      }
      $f_float = pack("N", unpack("V", pack("f", 50)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 6, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CLOSE_SPEED_CONTROL DUTY_CYCLE");
      }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ANTI_WATER_HAMMER_SPEED_CONTROL ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ANTI_WATER_HAMMER_SPEED_CONTROL ENABLE_SPEED_CONTROL");
      }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ANTI_WATER_HAMMER_SPEED_CONTROL START_POSITION");
      }
      $f_float = pack("N", unpack("V", pack("f", 5)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ANTI_WATER_HAMMER_SPEED_CONTROL START_POSITION");
      }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ANTI_WATER_HAMMER_SPEED_CONTROL STOP_POSITION");
      }
      $f_float = pack("N", unpack("V", pack("f", 0)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ANTI_WATER_HAMMER_SPEED_CONTROL STOP_POSITION");
      }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ANTI_WATER_HAMMER_SPEED_CONTROL ON_TIME");
      }
      $f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ANTI_WATER_HAMMER_SPEED_CONTROL ON_TIME");
      }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ANTI_WATER_HAMMER_SPEED_CONTROL OFF_TIME");
      }
      $f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ANTI_WATER_HAMMER_SPEED_CONTROL OFF_TIME");
      }

    my $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ESD_ENABLES_AND_ACTION ESD_ACTION");
      }
      $i_integer = pack("C", 3);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to ESD_ENABLES_AND_ACTION ESD_ACTION");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_PST_PARAMETERSInfo = $o_TBInfo->get_param_info("PST_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to PST_PARAMETERS START_POSITION");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to PST_PARAMETERS START_POSITION");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_PST_PARAMETERSInfo = $o_TBInfo->get_param_info("PST_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to  PST_PARAMETERS END_POSITION");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to  PST_PARAMETERS END_POSITION");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_PST_PARAMETERSInfo = $o_TBInfo->get_param_info("PST_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to PST_PARAMETERS TRAVEL_LIMIT");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to PST_PARAMETERS TRAVEL_LIMIT");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

    my $o_PST_PARAMETERSInfo = $o_TBInfo->get_param_info("PST_PARAMETERS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to PST_PARAMETERS PAUSE_TIME");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PST_PARAMETERSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to PST_PARAMETERS PAUSE_TIME");
      }

    my $o_BLUETOOTH_PARAMSInfo = $o_TBInfo->get_param_info("BLUETOOTH_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to BLUETOOTH_PARAMS BLUETOOTH_NAME");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to BLUETOOTH_PARAMS BLUETOOTH_NAME");
      }

    my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to CLOSE_TORQUE_LIMIT");
      }
      $f_float = pack("N", unpack("V", pack("f", 85)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to CLOSE_TORQUE_LIMIT");
      }

    my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPEN_TORQUE_LIMIT");
      }
      $f_float = pack("N", unpack("V", pack("f", 85)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to OPEN_TORQUE_LIMIT");
      }

      my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toACTUATOR_COMMAND VALUE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toACTUATOR_COMMAND VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_ACTUATOR_COMMAND_STATUSInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMAND_STATUSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ACTUATOR_COMMAND_STATUS VALUE");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMAND_STATUSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ACTUATOR_COMMAND_STATUS VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_ESD_PARAMSInfo = $o_TBInfo->get_param_info("ESD_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_PARAMSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ESD_PARAMS PST_STATUS");
      }
      $i_integer = pack("C", 2);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_PARAMSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ESD_PARAMS PST_STATUS");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_ESD_PARAMSInfo = $o_TBInfo->get_param_info("ESD_PARAMS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_PARAMSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ESD_PARAMS ESD_STATUS");
      }
      $i_integer = pack("C", 3);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_PARAMSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ESD_PARAMS ESD_STATUS");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_OPERATIONS_LOGInfo = $o_TBInfo->get_param_info("OPERATIONS_LOG");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATIONS_LOGInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPERATIONS_LOG CURRENT_STARTS");
      }
      $i_integer = pack("N", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATIONS_LOGInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to OPERATIONS_LOG CURRENT_STARTS");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_OPERATIONS_LOGInfo = $o_TBInfo->get_param_info("OPERATIONS_LOG");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATIONS_LOGInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPERATIONS_LOG CURRENT_STROKES");
      }
      $i_integer = pack("N", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATIONS_LOGInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to OPERATIONS_LOG CURRENT_STROKES");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_OPERATIONS_LOGInfo = $o_TBInfo->get_param_info("OPERATIONS_LOG");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATIONS_LOGInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPERATIONS_LOG ARCHIVED_RUN_TIME");
      }
      $i_integer = pack("N", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATIONS_LOGInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to OPERATIONS_LOG ARCHIVED_RUN_TIME");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_OPERATIONS_LOGInfo = $o_TBInfo->get_param_info("OPERATIONS_LOG");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATIONS_LOGInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPERATIONS_LOG ARCHIVED_STARTS");
      }
      $i_integer = pack("N", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATIONS_LOGInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to OPERATIONS_LOG ARCHIVED_STARTS");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_OPERATIONS_LOGInfo = $o_TBInfo->get_param_info("OPERATIONS_LOG");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATIONS_LOGInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OPERATIONS_LOG ARCHIVED_STROKES");
      }
      $i_integer = pack("N", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPERATIONS_LOGInfo->parameter_index, 6, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to OPERATIONS_LOG ARCHIVED_STROKES");
      }

      my $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toDEFAULT_SETPOINT_1");
      }
      $f_float = pack("N", unpack("V", pack("f",  87)));
  $rh_Result =    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toDEFAULT_SETPOINT_1");
      }

      my $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toSETPOINT VALUE");
      }
      $f_float = pack("N", unpack("V", pack("f",  100)));
  $rh_Result =    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toSETPOINT VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_POSITIONInfo = $o_TBInfo->get_param_info("POSITION");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_POSITIONInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toPOSITION VALUE");
      }
      $f_float = pack("N", unpack("V", pack("f",  50)));
$rh_Result =      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_POSITIONInfo->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to POSITION VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_TORQUEInfo = $o_TBInfo->get_param_info("TORQUE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUEInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toTORQUE VALUE");
      }
      $f_float = pack("N", unpack("V", pack("f",  100)));
$rh_Result =      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUEInfo->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to TORQUE VALUE");
      }

      my $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toANALOG_OUTPUT_1 VALUE");
      }
      $f_float = pack("N", unpack("V", pack("f",  100)));
$rh_Result =      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toANALOG_OUTPUT_1 VALUE");
      }

      my $o_ANALOG_OUTPUT_2Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_2Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toANALOG_OUTPUT_2 VALUE");
      }
      $f_float = pack("N", unpack("V", pack("f",  100)));
$rh_Result =      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_2Info->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toANALOG_OUTPUT_2 VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_ANALOG_INPUT_1Info = $o_TBInfo->get_param_info("ANALOG_INPUT_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_INPUT_1Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toANALOG_INPUT_1 VALUE");
      }
      $f_float = pack("N", unpack("V", pack("f",  100)));
$rh_Result =      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_INPUT_1Info->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ANALOG_INPUT_1 VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_HYDRAULIC_PRESSUREInfo = $o_TBInfo->get_param_info("HYDRAULIC_PRESSURE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HYDRAULIC_PRESSUREInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toHYDRAULIC_PRESSURE VALUE");
      }
      $f_float = pack("N", unpack("V", pack("f",  NA)));
$rh_Result =      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HYDRAULIC_PRESSUREInfo->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to HYDRAULIC_PRESSURE VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_ACCUMULATOR_PRESSUREInfo = $o_TBInfo->get_param_info("ACCUMULATOR_PRESSURE");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCUMULATOR_PRESSUREInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toACCUMULATOR_PRESSURE VALUE");
      }
      $f_float = pack("N", unpack("V", pack("f",  NA)));
$rh_Result =      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACCUMULATOR_PRESSUREInfo->parameter_index, 2, length($f_float) ,$f_float);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to ACCUMULATOR_PRESSURE VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_DISCRETE_INPUT_1Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_1");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_1Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_1 VALUE");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_1Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_1 VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_DISCRETE_INPUT_2Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_2");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_2Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_2 VALUE");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_2Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_2 VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_DISCRETE_INPUT_3Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_3");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_3Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_3 VALUE");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_3Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_3 VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_DISCRETE_INPUT_4Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_4");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_4Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_4 VALUE");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_4Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_4 VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_DISCRETE_INPUT_5Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_5");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_5Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_5 VALUE");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_5Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_5 VALUE");
      }
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

      my $o_DISCRETE_INPUT_6Info = $o_TBInfo->get_param_info("DISCRETE_INPUT_6");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_6Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to DISCRETE_INPUT_6 VALUE");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_6Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
      {
        fail("Expected confirm negative for write to DISCRETE_INPUT_6 VALUE");
      }

      my $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_1_STATUS VALUE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_1_STATUS VALUE");
      }

      my $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_2_STATUS VALUE");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_2_STATUS VALUE");
      }

      my $o_RELAY_3_STATUSInfo = $o_TBInfo->get_param_info("RELAY_3_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_3_STATUS VALUE");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_3_STATUS VALUE");
      }

      my $o_RELAY_4_STATUSInfo = $o_TBInfo->get_param_info("RELAY_4_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_4_STATUS VALUE");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_4_STATUS VALUE");
      }

      my $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to RELAY_5_STATUS VALUE");
      }
      $i_integer = pack("C", NA);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to RELAY_5_STATUS VALUE");
      }

}


sub Teardown()
{
  Log("Teardown ADVT test script....");
}