#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify all boundaries for parameters that are
 #          having range of valid values.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;
 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $f_float;
 my $i_integer;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = 1200; #ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex = 1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "EHO";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_EHO.xls");
     
 }
 sub Run() 
 { 
 
   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write STRATEGY for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("n", $o_STRATEGYInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write STRATEGY for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", $o_STRATEGYInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write STRATEGY for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", $o_STRATEGYInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write STRATEGY for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_ALERT_KEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("C", $o_ALERT_KEYInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT_KEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ALERT_KEY for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_ALERT_KEYInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT_KEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ALERT_KEY for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", $o_ALERT_KEYInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT_KEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ALERT_KEY for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", $o_ALERT_KEYInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT_KEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ALERT_KEY for out of range value");
    }
	
	
  my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR_MODE for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR_MODE for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", $o_ACTUATOR_MODEInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ACTUATOR_MODE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ACTUATOR_MODE for out of range value");
    }	

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CONTROL_MODE for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_CONTROL_MODEInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CONTROL_MODE for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", $o_CONTROL_MODEInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CONTROL_MODE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_CONTROL_MODEInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CONTROL_MODE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_CUSTOM_CHARACTERIZATION_TYPEInfo = $o_TBInfo->get_param_info("CUSTOM_CHARACTERIZATION_TYPE");
  $i_integer = pack("C", $o_CUSTOM_CHARACTERIZATION_TYPEInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CUSTOM_CHARACTERIZATION_TYPEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CUSTOM_CHARACTERIZATION_TYPE for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_CUSTOM_CHARACTERIZATION_TYPEInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CUSTOM_CHARACTERIZATION_TYPEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CUSTOM_CHARACTERIZATION_TYPE for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", $o_CUSTOM_CHARACTERIZATION_TYPEInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CUSTOM_CHARACTERIZATION_TYPEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CUSTOM_CHARACTERIZATION_TYPE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_CUSTOM_CHARACTERIZATION_TYPEInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CUSTOM_CHARACTERIZATION_TYPEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CUSTOM_CHARACTERIZATION_TYPE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_TARGET_TRAVELInfo = $o_TBInfo->get_param_info("TARGET_TRAVEL");
  $i_integer = pack("C", $o_TARGET_TRAVELInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TARGET_TRAVELInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write TARGET_TRAVEL for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_TARGET_TRAVELInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TARGET_TRAVELInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write TARGET_TRAVEL for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", $o_TARGET_TRAVELInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TARGET_TRAVELInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write TARGET_TRAVEL for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_TARGET_TRAVELInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TARGET_TRAVELInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write TARGET_TRAVEL for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
  $f_float = pack("N", unpack("V", pack("f", $o_VALVE_STALL_DELAY_TIMEInfo->min_range_value)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write VALVE_STALL_DELAY_TIME for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", $o_VALVE_STALL_DELAY_TIMEInfo->max_range_value)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write VALVE_STALL_DELAY_TIME for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", $o_VALVE_STALL_DELAY_TIMEInfo->min_range_value - 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write VALVE_STALL_DELAY_TIME for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", $o_VALVE_STALL_DELAY_TIMEInfo->max_range_value + 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write VALVE_STALL_DELAY_TIME for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo = $o_TBInfo->get_param_info("MAXIMUM_HYDRAULIC_CIRCUIT_PRESSURE");
  $f_float = pack("N", unpack("V", pack("f", $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo->min_range_value)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write MAXIMUM_HYDRAULIC_CIRCUIT_PRESSURE for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo->max_range_value)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write MAXIMUM_HYDRAULIC_CIRCUIT_PRESSURE for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo->min_range_value - 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write MAXIMUM_HYDRAULIC_CIRCUIT_PRESSURE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo->max_range_value + 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_HYDRAULIC_CIRCUIT_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write MAXIMUM_HYDRAULIC_CIRCUIT_PRESSURE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo = $o_TBInfo->get_param_info("MAXIMUM_SELF_CALIBRATION_PRESSURE");
  $f_float = pack("N", unpack("V", pack("f", $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->min_range_value)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write MAXIMUM_SELF_CALIBRATION_PRESSURE for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->max_range_value)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write MAXIMUM_SELF_CALIBRATION_PRESSURE for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->min_range_value - 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write MAXIMUM_SELF_CALIBRATION_PRESSURE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->max_range_value + 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MAXIMUM_SELF_CALIBRATION_PRESSUREInfo->parameter_index, 0, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write MAXIMUM_SELF_CALIBRATION_PRESSURE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo = $o_TBInfo->get_param_info("SELF_CALIBRATION_STROKE_COUNT_RANGE");
  $i_integer = pack("C", $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SELF_CALIBRATION_STROKE_COUNT_RANGE for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SELF_CALIBRATION_STROKE_COUNT_RANGE for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SELF_CALIBRATION_STROKE_COUNT_RANGE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SELF_CALIBRATION_STROKE_COUNT_RANGEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SELF_CALIBRATION_STROKE_COUNT_RANGE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_PRESSURE_UNITInfo = $o_TBInfo->get_param_info("PRESSURE_UNIT");
  $i_integer = pack("C", $o_PRESSURE_UNITInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PRESSURE_UNITInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write PRESSURE_UNIT for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_PRESSURE_UNITInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PRESSURE_UNITInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write PRESSURE_UNIT for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", $o_PRESSURE_UNITInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PRESSURE_UNITInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write PRESSURE_UNIT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", $o_PRESSURE_UNITInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_PRESSURE_UNITInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write PRESSURE_UNIT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ENABLE_LOG_JAM for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ENABLE_LOG_JAM for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOG_JAM for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOG_JAM for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write REMOTE_CONTROL_SIGNAL for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write REMOTE_CONTROL_SIGNAL for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write REMOTE_CONTROL_SIGNAL for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write REMOTE_CONTROL_SIGNAL for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LOCAL_CONTROL_SIGNAL for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LOCAL_CONTROL_SIGNAL for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOCAL_CONTROL_SIGNAL for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOCAL_CONTROL_SIGNAL for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write BACKSEAT for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write BACKSEAT for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write BACKSEAT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write BACKSEAT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write SEATING for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SEATING for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SEATING for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SEATING for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LED_COLOR for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LED_COLOR for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LED_COLOR for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LED_COLOR for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ENABLE_LOW_BATTERY_ALARM for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ENABLE_LOW_BATTERY_ALARM for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOW_BATTERY_ALARM for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOW_BATTERY_ALARM for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 0.1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write POSITION_CONTROL_BANDWIDTH for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write POSITION_CONTROL_BANDWIDTH for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("d", -0.9);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write POSITION_CONTROL_BANDWIDTH for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 6)));;
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write POSITION_CONTROL_BANDWIDTH for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 0.5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write SPEED_CONTROL_BANDWIDTH for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 10)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SPEED_CONTROL_BANDWIDTH for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("d", -0.5);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SPEED_CONTROL_BANDWIDTH for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 11)));;
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SPEED_CONTROL_BANDWIDTH for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LOST_ANALOG_INPUT_ACTION for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LOST_ANALOG_INPUT_ACTION for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOST_ANALOG_INPUT_ACTION for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOST_ANALOG_INPUT_ACTION for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ENABLE_LOST_ANALOG_INPUT_1_ALARM for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ENABLE_LOST_ANALOG_INPUT_1_ALARM for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOST_ANALOG_INPUT_1_ALARM for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,3, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOST_ANALOG_INPUT_1_ALARM for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_1_SOURCE for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_1_SOURCE for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ANALOG_OUTPUT_1_SOURCE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 5);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ANALOG_OUTPUT_1_SOURCE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,6, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_2_SOURCE for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,6, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_2_SOURCE for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,6, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ANALOG_OUTPUT_2_SOURCE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 5);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,6, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ANALOG_OUTPUT_2_SOURCE for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_A_(LSA)_TRIGGER_POINT for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_A_(LSA)_TRIGGER_POINT for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_A_(LSA)_TRIGGER_POINT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 101)));;
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_A_(LSA)_TRIGGER_POINT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_B_(LSB)_TRIGGER_POINT for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_B_(LSB)_TRIGGER_POINT for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_B_(LSB)_TRIGGER_POINT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 101)));;
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_B_(LSB)_TRIGGER_POINT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,3, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_OPEN_(LSO)_TRIGGER_POINT for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,3, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_OPEN_(LSO)_TRIGGER_POINT for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,3, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_OPEN_(LSO)_TRIGGER_POINT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 101)));;
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,3, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_OPEN_(LSO)_TRIGGER_POINT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_CLOSE_(LSC)_TRIGGER_POINT for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_CLOSE_(LSC)_TRIGGER_POINT for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_CLOSE_(LSC)_TRIGGER_POINT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 101)));;
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_CLOSE_(LSC)_TRIGGER_POINT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ESD_ACTION for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ESD_ACTION for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ESD_ACTION for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ESD_ACTION for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_BLUETOOTH_PARAMSInfo = $o_TBInfo->get_param_info("BLUETOOTH_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write BLUETOOTH_NAME for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write BLUETOOTH_NAME for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write BLUETOOTH_NAME for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write BLUETOOTH_NAME for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write CLOSE_TORQUE_LIMIT for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CLOSE_TORQUE_LIMIT for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CLOSE_TORQUE_LIMIT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 101)));;
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write CLOSE_TORQUE_LIMIT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write OPEN_TORQUE_LIMIT for minimum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write OPEN_TORQUE_LIMIT for maximum range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OPEN_TORQUE_LIMIT for out of range value");
    }

   $ff_tools::hostapi::api::InclOnCnfNeg = 0;

  $f_float = pack("N", unpack("V", pack("f", 101)));;
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OPEN_TORQUE_LIMIT for out of range value");
    }

}
sub Teardown()
{
  Log("Teardown ADVT test script....");
}