#=================================================================================================[
# Author: Anuja Dhane
#
# Purpose: To verify if OD index value mentioned in Parameter Table corresponding 
#          to each HQDCM33 parameter.
#
# Requirement:
#      1) HOST as non LAS device.
#      2) DUT as LAS and publisher.
#      3) REMOTE DEVICE as basic device and subscriber.
#
# Copyright (c) 2014 Emerson Process Management, LLLP.
#=================================================================================================]
use strict;
use warnings;

use advt::testcase::ff::lm::sis::sis_device_network;
use ff_tools::od::index::sod;
use excel_db::info;
use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

#================================ Test Data ====================================#

my $i_HostAddr;
my $i_DutAddr;
my $i_ResourceBlkIndex;
my $i_HostInternalVcrId;
my $i_DutMibVcrId;
my $i_DutFbapVcrId;
my $i_TBBlkIndex;
my $rh_Result;
my $o_RBInfo;
my $o_TBInfo;
my @i_ODOFFSET;

#================================== Test case =================================#


sub Setup()
{
  $i_HostAddr           = device_configuration()->identity->node_address;

  $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;

  $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;

  $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;

  $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
    
  $i_TBBlkIndex   = 1200; 
  $i_ResourceBlkIndex = 1000; 
    
  $o_RBInfo = new excel_db::info();
  $o_TBInfo = new excel_db::info();
    
  $o_RBInfo->blk_name = "RB";
  $o_RBInfo->od_index = $i_ResourceBlkIndex;
  $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
  $o_RBInfo->parse_execel_db("CRB_DB1.xls");
    
  $o_TBInfo->blk_name = "HQ";
  $o_TBInfo->od_index = $i_TBBlkIndex;
  $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
  $o_TBInfo->parse_execel_db("DATABASE_HQ.xls");
  @i_ODOFFSET   = (1..96);
}

sub Run()
{
  my $o_StatRevInfo = $o_TBInfo->get_param_info("ST_REV");
  if ($i_TBBlkIndex + $o_StatRevInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[0] )
  {
    fail("Wrong OD index for ST_REV");
  }
    
  my $o_TagdescInfo = $o_TBInfo->get_param_info("TAG_DESC");
  if ($i_TBBlkIndex + $o_TagdescInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[1] )
  {
    fail("Wrong OD index for Tag_DESC");
  }
        
  my $o_StrategyInfo = $o_TBInfo->get_param_info("STRATEGY");
  if ($i_TBBlkIndex + $o_StrategyInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[2] )
  {
    fail("Wrong OD index for Strategy");
  }
    
  my $o_AlertkeyInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  if ($i_TBBlkIndex + $o_AlertkeyInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[3] )
  {
    fail("Wrong OD index for Alert_key");
  }
     
  my $o_ModeblkInfo = $o_TBInfo->get_param_info("MODE_BLK");
  if ($i_TBBlkIndex + $o_ModeblkInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[4] )
  {
    fail("Wrong OD index for MODE_BLK");
  }
    
  my $o_BlkerrInfo = $o_TBInfo->get_param_info("BLOCK_ERR");
  if ($i_TBBlkIndex + $o_BlkerrInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[5] )
  {
    fail("Wrong OD index for BLOCK_ERR");
  }
     
  my $o_UPDATE_EVT = $o_TBInfo->get_param_info("UPDATE_EVT");
  if ($i_TBBlkIndex + $o_UPDATE_EVT->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[6] )
  {
    fail("Wrong OD index for UPDATE_EVT");
  }
     
  my $o_BLOCK_ALMInfo = $o_TBInfo->get_param_info("BLOCK_ALM");
  if ($i_TBBlkIndex + $o_BLOCK_ALMInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[7] )
  {
    fail("Wrong OD index for BLOCK_ALM");
  }
    
  my $o_TRANSDUCER_DIRECTORYInfo = $o_TBInfo->get_param_info("TRANSDUCER_DIRECTORY");
  if ($i_TBBlkIndex + $o_TRANSDUCER_DIRECTORYInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[8] )
  {
    fail("Wrong OD index for TRANSDUCER_DIRECTORY");
  }
    
  my $o_TRANSDUCER_TYPEInfo = $o_TBInfo->get_param_info("TRANSDUCER_TYPE");
  if ($i_TBBlkIndex + $o_TRANSDUCER_TYPEInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[9] )
  {
    fail("Wrong OD index for TRANSDUCER_TYPE");
  }
    
  my $o_XD_ERRORInfo = $o_TBInfo->get_param_info("XD_ERROR");
  if ($i_TBBlkIndex + $o_XD_ERRORInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[10] )
  {
    fail("Wrong OD index for XD_ERROR");
  }
    
  my $o_COLLECTION_DIRECTORYInfo = $o_TBInfo->get_param_info("COLLECTION_DIRECTORY");
  if ($i_TBBlkIndex + $o_COLLECTION_DIRECTORYInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[11] )
  {
    fail("Wrong OD index for COLLECTION_DIRECTORY");
  }
     
  my $o_FACTORY_HARDWAREInfo = $o_TBInfo->get_param_info("FACTORY_HARDWARE");
  if ($i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[12] )
  {
    fail("Wrong OD index for FACTORY_HARDWARE");
  }
       
  my $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  if ($i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[13])
  {
    fail("Wrong OD index for FACTORY_SOFTWARE");
  }
     
  my $o_FIRMWARE_REVISIONInfo = $o_TBInfo->get_param_info("FIRMWARE_REVISION");
  if ($i_TBBlkIndex + $o_FIRMWARE_REVISIONInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[14] )
  {
    fail("Wrong OD index for FIRMWARE_REVISION");
  }
    
  my $o_FIRMWARE_DATEInfo = $o_TBInfo->get_param_info("FIRMWARE_DATE");
  if ($i_TBBlkIndex + $o_FIRMWARE_DATEInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[15] )
  {
    fail("Wrong OD index for FIRMWARE_DATE");
  }
      
  my $o_FF_FUNCTION_TYPEInfo = $o_TBInfo->get_param_info("FF_FUNCTION_TYPE");
  if ($i_TBBlkIndex + $o_FF_FUNCTION_TYPEInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[16] )
  {
    fail("Wrong OD index for FF_FUNCTION_TYPE");
  }
  
  my $o_SOFTWARE_VERSION_IDInfo = $o_TBInfo->get_param_info("SOFTWARE_VERSION_ID");
  if ($i_TBBlkIndex + $o_SOFTWARE_VERSION_IDInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[17] )
  {
    fail("Wrong OD index for SOFTWARE_VERSION_ID");
  }
  
  my $o_COMPATIBILITY_NUMBERInfo = $o_TBInfo->get_param_info("COMPATIBILITY_NUMBER");
  if ($i_TBBlkIndex + $o_COMPATIBILITY_NUMBERInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[18] )
  {
    fail("Wrong OD index for COMPATIBILITY_NUMBER");
  }

  my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  if ($i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[19] )
  {
    fail("Wrong OD index for CONTROL_MODE");
  }

  my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  if ($i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[20] )
  {
    fail("Wrong OD index for ACTUATOR_MODE");
  }

  my $o_FIELD_DIAGNOSTIC_CODE = $o_TBInfo->get_param_info("FIELD_DIAGNOSTIC_CODE");
  if ($i_TBBlkIndex + $o_FIELD_DIAGNOSTIC_CODE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[21] )
  {
    fail("Wrong OD index for FIELD_DIAGNOSTIC_CODE");
  }

  my $o_CUSTOM_CHARACTERIZATION_TYPE = $o_TBInfo->get_param_info("CUSTOM_CHARACTERIZATION_TYPE");
  if ($i_TBBlkIndex + $o_CUSTOM_CHARACTERIZATION_TYPE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[22] )
  {
    fail("Wrong OD index for CUSTOM_CHARACTERIZATION_TYPE");
  }

  my $o_TARGET_TRAVEL = $o_TBInfo->get_param_info("TARGET_TRAVEL");
  if ($i_TBBlkIndex + $o_TARGET_TRAVEL->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[23] )
  {
    fail("Wrong OD index for TARGET_TRAVEL");
  }

  my $o_LIMIT_SWITCH_STATUS = $o_TBInfo->get_param_info("LIMIT_SWITCH_STATUS");
  if ($i_TBBlkIndex + $o_LIMIT_SWITCH_STATUS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[24] )
  {
    fail("Wrong OD index for LIMIT_SWITCH_STATUS");
  }

  my $o_LIMIT_SWITCH_TRIGGER_POINTS = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  if ($i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[25] )
  {
    fail("Wrong OD index for LIMIT_SWITCH_TRIGGER_POINTS");
  }

  my $o_ESD_DELAY = $o_TBInfo->get_param_info("ESD_DELAY");
  if ($i_TBBlkIndex + $o_ESD_DELAY->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[26] )
  {
    fail("Wrong OD index for ESD_DELAY");
  }

  my $o_ESD_PARAMS = $o_TBInfo->get_param_info("ESD_PARAMS");
  if ($i_TBBlkIndex + $o_ESD_PARAMS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[27] )
  {
    fail("Wrong OD index for ESD_PARAMS");
  }

  my $o_ESD_OVERRIDES = $o_TBInfo->get_param_info("ESD_OVERRIDES");
  if ($i_TBBlkIndex + $o_ESD_OVERRIDES->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[28] )
  {
    fail("Wrong OD index for ESD_OVERRIDES");
  }

  my $o_ESD_ENABLES_AND_ACTION = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  if ($i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTION->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[29] )
  {
    fail("Wrong OD index for ESD_ENABLES_AND_ACTION");
  }

  my $o_HOST_COMMAND_ESD = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  if ($i_TBBlkIndex + $o_HOST_COMMAND_ESD->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[30] )
  {
    fail("Wrong OD index for HOST_COMMAND_ESD");
  }

  my $o_ENABLE_PST = $o_TBInfo->get_param_info("ENABLE_PST");
  if ($i_TBBlkIndex + $o_ENABLE_PST->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[31] )
  {
    fail("Wrong OD index for ENABLE_PST");
  }

  my $o_PST_PARAMETERS = $o_TBInfo->get_param_info("PST_PARAMETERS");
  if ($i_TBBlkIndex + $o_PST_PARAMETERS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[32] )
  {
    fail("Wrong OD index for PST_PARAMETERS");
  }

  my $o_CONTROL_PARAM_1 = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  if ($i_TBBlkIndex + $o_CONTROL_PARAM_1->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[33] )
  {
    fail("Wrong OD index for CONTROL_PARAM_1");
  }

  my $o_CONTROL_PARAM_2 = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
  if ($i_TBBlkIndex + $o_CONTROL_PARAM_2->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[34] )
  {
    fail("Wrong OD index for CONTROL_PARAM_2");
  }

  my $o_ENABLE_RDMS = $o_TBInfo->get_param_info("ENABLE_RDMS");
  if ($i_TBBlkIndex + $o_ENABLE_RDMS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[35] )
  {
    fail("Wrong OD index for ENABLE_RDMS");
  }

  my $o_MODULATION_PARAMETERS = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  if ($i_TBBlkIndex + $o_MODULATION_PARAMETERS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[36] )
  {
    fail("Wrong OD index for MODULATION_PARAMETERS");
  }

  my $o_ANALOG_CONTROL_SOURCE = $o_TBInfo->get_param_info("ANALOG_CONTROL_SOURCE");
  if ($i_TBBlkIndex + $o_ANALOG_CONTROL_SOURCE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[37] )
  {
    fail("Wrong OD index for ANALOG_CONTROL_SOURCE");
  }
  
  my $o_ANALOG_PARAMS = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  if ($i_TBBlkIndex + $o_ANALOG_PARAMS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[38] )
  {
    fail("Wrong OD index for ANALOG_PARAMS");
  }  

  my $o_DISCRETE_INPUTS_SETTINGS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_SETTINGS");
  if ($i_TBBlkIndex + $o_DISCRETE_INPUTS_SETTINGS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[39] )
  {
    fail("Wrong OD index for DISCRETE_INPUTS_SETTINGS");
  }

  my $o_DISCRETE_INPUTS_FUNCTIONS = $o_TBInfo->get_param_info("DISCRETE_INPUTS_FUNCTIONS");
  if ($i_TBBlkIndex + $o_DISCRETE_INPUTS_FUNCTIONS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[40] )
  {
    fail("Wrong OD index for DISCRETE_INPUTS_FUNCTIONS");
  }

  my $o_RELAY_FUNCTIONS = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  if ($i_TBBlkIndex + $o_RELAY_FUNCTIONS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[41] )
  {
    fail("Wrong OD index for RELAY_FUNCTIONS");
  }

  my $o_RELAY_SETTINGS = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  if ($i_TBBlkIndex + $o_RELAY_SETTINGS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[42] )
  {
    fail("Wrong OD index for RELAY_SETTINGS");
  }

  my $o_OPEN_SPEED_CONTROL = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  if ($i_TBBlkIndex + $o_OPEN_SPEED_CONTROL->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[43] )
  {
    fail("Wrong OD index for OPEN_SPEED_CONTROL");
  }

  my $o_CLOSE_SPEED_CONTROL = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  if ($i_TBBlkIndex + $o_CLOSE_SPEED_CONTROL->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[44] )
  {
    fail("Wrong OD index for CLOSE_SPEED_CONTROL");
  }

  my $o_ANTI_WATER_HAMMER_SPEED_CONTROL = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  if ($i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROL->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[45] )
  {
    fail("Wrong OD index for ANTI_WATER_HAMMER_SPEED_CONTROL");
  }

  my $o_BLUETOOTH_PARAMS = $o_TBInfo->get_param_info("BLUETOOTH_PARAMS");
  if ($i_TBBlkIndex + $o_BLUETOOTH_PARAMS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[46] )
  {
    fail("Wrong OD index for BLUETOOTH_PARAMS");
  }

  my $o_TORQUE_LIMIT = $o_TBInfo->get_param_info("TORQUE_LIMIT");
  if ($i_TBBlkIndex + $o_TORQUE_LIMIT->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[47] )
  {
    fail("Wrong OD index for TORQUE_LIMIT");
  }

  my $o_MAXIMUM_TORQUE = $o_TBInfo->get_param_info("MAXIMUM_TORQUE");
  if ($i_TBBlkIndex + $o_MAXIMUM_TORQUE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[48] )
  {
    fail("Wrong OD index for MAXIMUM_TORQUE");
  }  

  my $o_TORQUE_OUT_OF_RANGE = $o_TBInfo->get_param_info("TORQUE_OUT_OF_RANGE");
  if ($i_TBBlkIndex + $o_TORQUE_OUT_OF_RANGE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[49] )
  {
    fail("Wrong OD index for TORQUE_OUT_OF_RANGE");
  }  

  my $o_PRESSURE_UNIT = $o_TBInfo->get_param_info("PRESSURE_UNIT");
  if ($i_TBBlkIndex + $o_PRESSURE_UNIT->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[50] )
  {
    fail("Wrong OD index for PRESSURE_UNIT");
  }  

  my $o_ENABLE_ACCUMULATOR = $o_TBInfo->get_param_info("ENABLE_ACCUMULATOR");
  if ($i_TBBlkIndex + $o_ENABLE_ACCUMULATOR->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[51] )
  {
    fail("Wrong OD index for ENABLE_ACCUMULATOR");
  }  

  my $o_ENABLE_SELF_CALIBRATION = $o_TBInfo->get_param_info("ENABLE_SELF_CALIBRATION");
  if ($i_TBBlkIndex + $o_ENABLE_SELF_CALIBRATION->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[52] )
  {
    fail("Wrong OD index for ENABLE_SELF_CALIBRATION");
  }  

  my $o_SELF_CALIBRATION_STATUS = $o_TBInfo->get_param_info("SELF_CALIBRATION_STATUS");
  if ($i_TBBlkIndex + $o_SELF_CALIBRATION_STATUS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[53] )
  {
    fail("Wrong OD index for SELF_CALIBRATION_STATUS");
  }  

  my $o_MAXIMUM__HYDRAULIC_CIRCUIT_PRESSURE = $o_TBInfo->get_param_info("MAXIMUM__HYDRAULIC_CIRCUIT_PRESSURE");
  if ($i_TBBlkIndex + $o_MAXIMUM__HYDRAULIC_CIRCUIT_PRESSURE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[54] )
  {
    fail("Wrong OD index for MAXIMUM__HYDRAULIC_CIRCUIT_PRESSURE");
  }  

  my $o_MAXIMUM_SELF_CALIBRATION_PRESSURE = $o_TBInfo->get_param_info("MAXIMUM_SELF_CALIBRATION_PRESSURE");
  if ($i_TBBlkIndex + $o_MAXIMUM_SELF_CALIBRATION_PRESSURE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[55] )
  {
    fail("Wrong OD index for MAXIMUM_SELF_CALIBRATION_PRESSURE");
  }  

  my $o_SELF_CALIBRATION_STROKE_COUNT_RANGE = $o_TBInfo->get_param_info("SELF_CALIBRATION_STROKE_COUNT_RANGE");
  if ($i_TBBlkIndex + $o_SELF_CALIBRATION_STROKE_COUNT_RANGE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[56] )
  {
    fail("Wrong OD index for SELF_CALIBRATION_STROKE_COUNT_RANGE");
  }  

  my $o_STROKE_TIME = $o_TBInfo->get_param_info("STROKE_TIME");
  if ($i_TBBlkIndex + $o_STROKE_TIME->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[57] )
  {
    fail("Wrong OD index for STROKE_TIME");
  }  

  my $o_ACTUATOR_FULLY_OPEN_TIME = $o_TBInfo->get_param_info("ACTUATOR_FULLY_OPEN_TIME");
  if ($i_TBBlkIndex + $o_ACTUATOR_FULLY_OPEN_TIME->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[58] )
  {
    fail("Wrong OD index for ACTUATOR_FULLY_OPEN_TIME");
  }  

  my $o_ACTUATOR_FULLY_CLOSE_TIME = $o_TBInfo->get_param_info("ACTUATOR_FULLY_CLOSE_TIME");
  if ($i_TBBlkIndex + $o_ACTUATOR_FULLY_CLOSE_TIME->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[59] )
  {
    fail("Wrong OD index for ACTUATOR_FULLY_CLOSE_TIME");
  }  

  my $o_OPERATIONS_LOG = $o_TBInfo->get_param_info("OPERATIONS_LOG");
  if ($i_TBBlkIndex + $o_OPERATIONS_LOG->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[60] )
  {
    fail("Wrong OD index for OPERATIONS_LOG");
  }  

  my $o_PORT_INFO = $o_TBInfo->get_param_info("PORT_INFO");
  if ($i_TBBlkIndex + $o_PORT_INFO->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[61] )
  {
    fail("Wrong OD index for PORT_INFO");
  }  

  my $o_DEFAULT_SETPOINT = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  if ($i_TBBlkIndex + $o_DEFAULT_SETPOINT->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[62] )
  {
    fail("Wrong OD index for DEFAULT_SETPOINT");
  }  

  my $o_VALVE_STALL_DELAY_TIME = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
  if ($i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIME->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[63] )
  {
    fail("Wrong OD index for VALVE_STALL_DELAY_TIME");
  }  

  my $o_ACTUATOR_COMMAND = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  if ($i_TBBlkIndex + $o_ACTUATOR_COMMAND->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[64] )
  {
    fail("Wrong OD index for ACTUATOR_COMMAND");
  }  

  my $o_ACTUATOR_COMMAND_STATUS = $o_TBInfo->get_param_info("ACTUATOR_COMMAND_STATUS");
  if ($i_TBBlkIndex + $o_ACTUATOR_COMMAND_STATUS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[65] )
  {
    fail("Wrong OD index for ACTUATOR_COMMAND_STATUS");
  }  

  my $o_SETPOINT = $o_TBInfo->get_param_info("SETPOINT");
  if ($i_TBBlkIndex + $o_SETPOINT->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[66] )
  {
    fail("Wrong OD index for SETPOINT");
  }  

  my $o_POSITION = $o_TBInfo->get_param_info("POSITION");
  if ($i_TBBlkIndex + $o_POSITION->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[67] )
  {
    fail("Wrong OD index for POSITION");
  }  

  my $o_TORQUE = $o_TBInfo->get_param_info("TORQUE");
  if ($i_TBBlkIndex + $o_TORQUE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[68] )
  {
    fail("Wrong OD index for TORQUE");
  }  

  my $o_ACCUMULATOR_PRESSURE = $o_TBInfo->get_param_info("ACCUMULATOR_PRESSURE");
  if ($i_TBBlkIndex + $o_ACCUMULATOR_PRESSURE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[69] )
  {
    fail("Wrong OD index for ACCUMULATOR_PRESSURE");
  }

  my $o_HYDRAULIC_PRESSURE = $o_TBInfo->get_param_info("HYDRAULIC_PRESSURE");
  if ($i_TBBlkIndex + $o_HYDRAULIC_PRESSURE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[70] )
  {
    fail("Wrong OD index for HYDRAULIC_PRESSURE");
  }

  my $o_DISCRETE_INPUT_1 = $o_TBInfo->get_param_info("DISCRETE_INPUT_1");
  if ($i_TBBlkIndex + $o_DISCRETE_INPUT_1->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[71] )
  {
    fail("Wrong OD index for DISCRETE_INPUT_1");
  }

  my $o_DISCRETE_INPUT_2 = $o_TBInfo->get_param_info("DISCRETE_INPUT_2");
  if ($i_TBBlkIndex + $o_DISCRETE_INPUT_2->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[72] )
  {
    fail("Wrong OD index for DISCRETE_INPUT_2");
  }

  my $o_DISCRETE_INPUT_3 = $o_TBInfo->get_param_info("DISCRETE_INPUT_3");
  if ($i_TBBlkIndex + $o_DISCRETE_INPUT_3->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[73] )
  {
    fail("Wrong OD index for DISCRETE_INPUT_3");
  }

  my $o_DISCRETE_INPUT_4 = $o_TBInfo->get_param_info("DISCRETE_INPUT_4");
  if ($i_TBBlkIndex + $o_DISCRETE_INPUT_4->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[74] )
  {
    fail("Wrong OD index for DISCRETE_INPUT_4");
  }

  my $o_DISCRETE_INPUT_5 = $o_TBInfo->get_param_info("DISCRETE_INPUT_5");
  if ($i_TBBlkIndex + $o_DISCRETE_INPUT_5->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[75] )
  {
    fail("Wrong OD index for DISCRETE_INPUT_5");
  }

  my $o_DISCRETE_INPUT_6 = $o_TBInfo->get_param_info("DISCRETE_INPUT_6");
  if ($i_TBBlkIndex + $o_DISCRETE_INPUT_6->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[76] )
  {
    fail("Wrong OD index for DISCRETE_INPUT_6");
  }

  my $o_RELAY_1_STATUS = $o_TBInfo->get_param_info("RELAY_1_STATUS");
  if ($i_TBBlkIndex + $o_RELAY_1_STATUS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[77] )
  {
    fail("Wrong OD index for RELAY_1_STATUS");
  }

  my $o_RELAY_2_STATUS = $o_TBInfo->get_param_info("RELAY_2_STATUS");
  if ($i_TBBlkIndex + $o_RELAY_2_STATUS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[78] )
  {
    fail("Wrong OD index for RELAY_2_STATUS");
  }

  my $o_RELAY_3_STATUS = $o_TBInfo->get_param_info("RELAY_3_STATUS");
  if ($i_TBBlkIndex + $o_RELAY_3_STATUS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[79] )
  {
    fail("Wrong OD index for RELAY_3_STATUS");
  }

  my $o_RELAY_4_STATUS = $o_TBInfo->get_param_info("RELAY_4_STATUS");
  if ($i_TBBlkIndex + $o_RELAY_4_STATUS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[80] )
  {
    fail("Wrong OD index for RELAY_4_STATUS");
  }

  my $o_RELAY_5_STATUS = $o_TBInfo->get_param_info("RELAY_5_STATUS");
  if ($i_TBBlkIndex + $o_RELAY_5_STATUS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[81] )
  {
    fail("Wrong OD index for RELAY_5_STATUS");
  }

  my $o_PVftimeInfo = $o_TBInfo->get_param_info("ANALOG_INPUT_1");
  if ($i_TBBlkIndex + $o_PVftimeInfo->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[82] )
  {
    fail("Wrong OD index for ANALOG_INPUT_1");
  }

  my $o_ANALOG_INPUT_2 = $o_TBInfo->get_param_info("ANALOG_INPUT_2");
  if ($i_TBBlkIndex + $o_ANALOG_INPUT_2->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[83] )
  {
    fail("Wrong OD index for ANALOG_INPUT_2");
  }

  my $o_ANALOG_OUTPUT_1 = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
  if ($i_TBBlkIndex + $o_ANALOG_OUTPUT_1->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[84] )
  {
    fail("Wrong OD index for ANALOG_OUTPUT_1");
  }

  my $o_ANALOG_OUTPUT_2 = $o_TBInfo->get_param_info("ANALOG_OUTPUT_2");
  if ($i_TBBlkIndex + $o_ANALOG_OUTPUT_2->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[85] )
  {
    fail("Wrong OD index for ANALOG_OUTPUT_2");
  }  
  
  my $o_MPA_PORT_CAL_DATA = $o_TBInfo->get_param_info("MPA_PORT_CAL_DATA");
  if ($i_TBBlkIndex + $o_MPA_PORT_CAL_DATA->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[86] )
  {
    fail("Wrong OD index for MPA_PORT_CAL_DATA");
  }  
  
  my $o_CONFIGURATION_COMMANDS = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
  if ($i_TBBlkIndex + $o_CONFIGURATION_COMMANDS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[87] )
  {
    fail("Wrong OD index for CONFIGURATION_COMMANDS");
  }  
  
  my $o_LANGUAGE_SELECTION = $o_TBInfo->get_param_info("LANGUAGE_SELECTION");
  if ($i_TBBlkIndex + $o_LANGUAGE_SELECTION->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[88] )
  {
    fail("Wrong OD index for LANGUAGE_SELECTION");
  }  
  
  my $o_OPEN_TORQUE_PROFILE = $o_TBInfo->get_param_info("OPEN_TORQUE_PROFILE");
  if ($i_TBBlkIndex + $o_OPEN_TORQUE_PROFILE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[89] )
  {
    fail("Wrong OD index for OPEN_TORQUE_PROFILE");
  }  
  
  my $o_CLOSE_TORQUE_PROFILE = $o_TBInfo->get_param_info("CLOSE_TORQUE_PROFILE");
  if ($i_TBBlkIndex + $o_CLOSE_TORQUE_PROFILE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[90] )
  {
    fail("Wrong OD index for CLOSE_TORQUE_PROFILE");
  }  
  
  my $o_ARCHIVED_OPEN_TORQUE_PROFILE = $o_TBInfo->get_param_info("ARCHIVED_OPEN_TORQUE_PROFILE");
  if ($i_TBBlkIndex + $o_ARCHIVED_OPEN_TORQUE_PROFILE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[91] )
  {
    fail("Wrong OD index for ARCHIVED_OPEN_TORQUE_PROFILE");
  }  
  
  my $o_ARCHIVED_CLOSE_TORQUE_PROFILE = $o_TBInfo->get_param_info("ARCHIVED_CLOSE_TORQUE_PROFILE");
  if ($i_TBBlkIndex + $o_ARCHIVED_CLOSE_TORQUE_PROFILE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[92] )
  {
    fail("Wrong OD index for ARCHIVED_CLOSE_TORQUE_PROFILE");
  }  
  
  my $o_ACCESS_PRIVILLEGE = $o_TBInfo->get_param_info("ACCESS_PRIVILLEGE");
  if ($i_TBBlkIndex + $o_ACCESS_PRIVILLEGE->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[93] )
  {
    fail("Wrong OD index for ACCESS_PRIVILLEGE");
  }  

  my $o_PROGNOSTICS = $o_TBInfo->get_param_info("PROGNOSTICS");
  if ($i_TBBlkIndex + $o_PROGNOSTICS->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[94] )
  {
    fail("Wrong OD index for PROGNOSTICS");
  }    
  
  my $o_RESERVED_A = $o_TBInfo->get_param_info("RESERVED_A");
  if ($i_TBBlkIndex + $o_RESERVED_A->parameter_index != $i_TBBlkIndex + $i_ODOFFSET[95] )
  {
    fail("Wrong OD index for RESERVED_A");
  }    
  
         
}
sub Teardown()
{
  Log("Teardown ADVT test script....");
}


      