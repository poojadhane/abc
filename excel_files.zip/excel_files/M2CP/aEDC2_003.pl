#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify that each M2CP actuator block parameters are initialized with an initial value defined
 #          in Parameter Table when RESTART with Defaults parameter in resource Blocks is selected.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

 use constant RESTART_WITH_DEFAULT               => 3;
 use constant MIB_PROFILE_NO                     => 0x4D47;
 use constant FBAP_PROFILE_NO                    => 0;
 use constant OD_VERSION                         => 1;
 use constant ABORT_REASON                       => 0x01;
 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
#================================== Test case =================================#
sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = 1200; #ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex = 1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "M2CP";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_M2CP.xls");
     
   my $o_RBRestartParamInfo = $o_RBInfo->get_param_info("RESTART"); 
   my $s_ProcRestart = pack("C", RESTART_WITH_DEFAULT);
   ff_tools::hostapi::api::Write($i_DutFbapVcrId,$o_RBInfo->od_index + $o_RBRestartParamInfo->parameter_index,0,length($s_ProcRestart),$s_ProcRestart);
   ff_tools::hostapi::api::Abort($i_DutFbapVcrId,   ABORT_REASON);
   ff_tools::hostapi::api::Abort($i_DutMibVcrId,    ABORT_REASON);
   
   ff_tools::hostapi::api::WaitForInd($ff_tools::hostapi::SERVICE_CODE_SM_NEW_NODE_EVENT, 1000);
 
   ff_tools::hostapi::api::Initiate($i_DutFbapVcrId,  OD_VERSION, MIB_PROFILE_NO);
   ff_tools::hostapi::api::Initiate($i_DutMibVcrId, OD_VERSION, FBAP_PROFILE_NO);
 }
 sub Run() 
 { 
 
   my $o_STREV= $o_TBInfo->get_param_info("ST REV"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STREV->parameter_index, 0);
   my  $i_STREV = unpack("n", $rh_Result->{"Confirm"}->Data);
   if ($i_STREV != $o_ST REV->default_value)
   {
     fail("Wrong default value for ST REV"); 

   }


   my $o_TAG DESC= $o_TBInfo->get_param_info("TAG DESC"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TAG DESC->parameter_index, 0);
   my  $i_TAG DESC = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_TAG DESC != $o_TAG DESC->default_value)
   {
     fail("Wrong default value for TAG DESC"); 

   }


   my $o_STRATEGY= $o_TBInfo->get_param_info("STRATEGY"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGY->parameter_index, 0);
   my  $i_STRATEGY = unpack("n", $rh_Result->{"Confirm"}->Data);
   if ($i_STRATEGY != $o_STRATEGY->default_value)
   {
     fail("Wrong default value for STRATEGY"); 

   }


   my $o_ALERT KEY= $o_TBInfo->get_param_info("ALERT KEY"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT KEY->parameter_index, 0);
   my  $i_ALERT KEY = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ALERT KEY != $o_ALERT KEY->default_value)
   {
     fail("Wrong default value for ALERT KEY"); 

   }


   my $o_FIRMWARE_DATE= $o_TBInfo->get_param_info("FIRMWARE_DATE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FIRMWARE_DATE->parameter_index, 0);
   my  $i_FIRMWARE_DATE = unpack("N*", $rh_Result->{"Confirm"}->Data);
   if ($i_FIRMWARE_DATE != $o_FIRMWARE_DATE->default_value)
   {
     fail("Wrong default value for FIRMWARE_DATE"); 

   }


   my $o_FF_FUNCTION_TYPE= $o_TBInfo->get_param_info("FF_FUNCTION_TYPE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FF_FUNCTION_TYPE->parameter_index, 0);
   my  $i_FF_FUNCTION_TYPE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_FF_FUNCTION_TYPE != $o_FF_FUNCTION_TYPE->default_value)
   {
     fail("Wrong default value for FF_FUNCTION_TYPE"); 

   }


   my $o_COMPATIBILITY_NUMBER= $o_TBInfo->get_param_info("COMPATIBILITY_NUMBER"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_COMPATIBILITY_NUMBER->parameter_index, 0);
   my  $i_COMPATIBILITY_NUMBER = unpack("n", $rh_Result->{"Confirm"}->Data);
   if ($i_COMPATIBILITY_NUMBER != $o_COMPATIBILITY_NUMBER->default_value)
   {
     fail("Wrong default value for COMPATIBILITY_NUMBER"); 

   }


   my $o_CONTROL_MODE= $o_TBInfo->get_param_info("CONTROL_MODE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODE->parameter_index, 0);
   my  $i_CONTROL_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_CONTROL_MODE != $o_CONTROL_MODE->default_value)
   {
     fail("Wrong default value for CONTROL_MODE"); 

   }


   my $o_ACTUATOR_MODE= $o_TBInfo->get_param_info("ACTUATOR_MODE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODE->parameter_index, 0);
   my  $i_ACTUATOR_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ACTUATOR_MODE != $o_ACTUATOR_MODE->default_value)
   {
     fail("Wrong default value for ACTUATOR_MODE"); 

   }


   my $o_ESD_DELAY= $o_TBInfo->get_param_info("ESD_DELAY"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAY->parameter_index, 0);
   my  $i_ESD_DELAY = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ESD_DELAY != $o_ESD_DELAY->default_value)
   {
     fail("Wrong default value for ESD_DELAY"); 

   }


   my $o_TORQUE_OUT_OF_RANGE= $o_TBInfo->get_param_info("TORQUE_OUT_OF_RANGE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_OUT_OF_RANGE->parameter_index, 0);
   my  $i_TORQUE_OUT_OF_RANGE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_TORQUE_OUT_OF_RANGE != $o_TORQUE_OUT_OF_RANGE->default_value)
   {
     fail("Wrong default value for TORQUE_OUT_OF_RANGE"); 

   }


   my $o_VALVE_STALL_DELAY_TIME= $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIME->parameter_index, 0);
   my  $f_VALVE_STALL_DELAY_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_VALVE_STALL_DELAY_TIME != $o_VALVE_STALL_DELAY_TIME->default_value)
   {
     fail("Wrong default value for VALVE_STALL_DELAY_TIME"); 

   }


   my $o_POSITION= $o_TBInfo->get_param_info("POSITION"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_POSITION->parameter_index, 1);
   my  $i_POSITION = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_POSITION != $o_POSITION->default_value)
   {
     fail("Wrong default value for POSITION"); 

   }


   my $o_CONFIGURATION_COMMANDS= $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDS->parameter_index, 0);
   my  $i_CONFIGURATION_COMMANDS = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_CONFIGURATION_COMMANDS != $o_CONFIGURATION_COMMANDS->default_value)
   {
     fail("Wrong default value for CONFIGURATION_COMMANDS"); 

   }


   my $o_CONTROL_PARAM_1Info= $o_TBInfo->get_param_info("CONTROL_PARAM_1"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1);
   my  $i_ENABLE_LOG_JAM = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ENABLE_LOG_JAM != 0)
 
   {
     fail("Wrong default value for ENABLE_LOG_JAM"); 

   }


   my $o_CONTROL_PARAM_1Info= $o_TBInfo->get_param_info("CONTROL_PARAM_1"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4);
   my  $i_BACKSEAT = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_BACKSEAT != 0)
 
   {
     fail("Wrong default value for BACKSEAT"); 

   }


   my $o_CONTROL_PARAM_1Info= $o_TBInfo->get_param_info("CONTROL_PARAM_1"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5);
   my  $i_SEATING = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_SEATING != 0)
 
   {
     fail("Wrong default value for SEATING"); 

   }


   my $o_MODULATION_PARAMETERSInfo= $o_TBInfo->get_param_info("MODULATION_PARAMETERS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1);
   my  $f_POSITION_CONTROL_BANDWIDTH = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_POSITION_CONTROL_BANDWIDTH != 10)
 
   {
     fail("Wrong default value for POSITION_CONTROL_BANDWIDTH"); 

   }


   my $o_MODULATION_PARAMETERSInfo= $o_TBInfo->get_param_info("MODULATION_PARAMETERS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2);
   my  $f_SPEED_CONTROL_BANDWIDTH = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_SPEED_CONTROL_BANDWIDTH != 50)
 
   {
     fail("Wrong default value for SPEED_CONTROL_BANDWIDTH"); 

   }


   my $o_MODULATION_PARAMETERSInfo= $o_TBInfo->get_param_info("MODULATION_PARAMETERS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3);
   my  $f_MODULATION_DELAY = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_MODULATION_DELAY != 1)
 
   {
     fail("Wrong default value for MODULATION_DELAY"); 

   }


   my $o_ANALOG_PARAMSInfo= $o_TBInfo->get_param_info("ANALOG_PARAMS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1);
   my  $i_LOST_ANALOG_INPUT_ACTION = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_LOST_ANALOG_INPUT_ACTION != 0)
 
   {
     fail("Wrong default value for LOST_ANALOG_INPUT_ACTION"); 

   }


   my $o_ANALOG_PARAMSInfo= $o_TBInfo->get_param_info("ANALOG_PARAMS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2);
   my  $i_LOST_ANALOG_INPUT_2_ACTION = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_LOST_ANALOG_INPUT_2_ACTION != 0)
 
   {
     fail("Wrong default value for LOST_ANALOG_INPUT_2_ACTION"); 

   }


   my $o_ANALOG_PARAMSInfo= $o_TBInfo->get_param_info("ANALOG_PARAMS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5);
   my  $i_ANALOG_OUTPUT_1_SOURCE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_ANALOG_OUTPUT_1_SOURCE != 0)
 
   {
     fail("Wrong default value for ANALOG_OUTPUT_1_SOURCE"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 5);
   my  $i_NETWORK_ADAPTER = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_NETWORK_ADAPTER != 7)
 
   {
     fail("Wrong default value for NETWORK_ADAPTER"); 

   }


   my $o_FACTORY_HARDWAREInfo= $o_TBInfo->get_param_info("FACTORY_HARDWARE"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_HARDWAREInfo->parameter_index, 6);
   my  $i_STARTER_TYPE = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_STARTER_TYPE != 2)
 
   {
     fail("Wrong default value for STARTER_TYPE"); 

   }


   my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo= $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1);
   my  $f_LIMIT_SWITCH_A_TRIGGER_POINT = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_LIMIT_SWITCH_A_TRIGGER_POINT != 25)
 
   {
     fail("Wrong default value for LIMIT_SWITCH_A_TRIGGER_POINT"); 

   }


   my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo= $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2);
   my  $f_LIMIT_SWITCH_B_TRIGGER_POINT = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_LIMIT_SWITCH_B_TRIGGER_POINT != 75)
 
   {
     fail("Wrong default value for LIMIT_SWITCH_B_TRIGGER_POINT"); 

   }


   my $o_DISCRETE_INPUT_FUNCTIONSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 1);
   my  $i_DISCRETE_INPUT_FUNCTIONS0 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_FUNCTIONS0 != 1)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_FUNCTIONS0"); 

   }


   my $o_DISCRETE_INPUT_FUNCTIONSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 2);
   my  $i_DISCRETE_INPUT_FUNCTIONS1 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_FUNCTIONS1 != 2)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_FUNCTIONS1"); 

   }


   my $o_DISCRETE_INPUT_FUNCTIONSInfo= $o_TBInfo->get_param_info("DISCRETE_INPUT_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_FUNCTIONSInfo->parameter_index, 3);
   my  $i_DISCRETE_INPUT_FUNCTIONS2 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_DISCRETE_INPUT_FUNCTIONS2 != 3)
 
   {
     fail("Wrong default value for DISCRETE_INPUT_FUNCTIONS2"); 

   }


   my $o_RELAY_SETTINGSInfo= $o_TBInfo->get_param_info("RELAY_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1);
   my  $i_RELAY_SETTINGS0 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_SETTINGS0 != 2)
 
   {
     fail("Wrong default value for RELAY_SETTINGS0"); 

   }


   my $o_RELAY_SETTINGSInfo= $o_TBInfo->get_param_info("RELAY_SETTINGS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2);
   my  $i_RELAY_SETTINGS1 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_SETTINGS1 != 2)
 
   {
     fail("Wrong default value for RELAY_SETTINGS1"); 

   }


   my $o_RELAY_FUNCTIONSInfo= $o_TBInfo->get_param_info("RELAY_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1);
   my  $i_RELAY_FUNCTIONS0 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_FUNCTIONS0 != 0)
 
   {
     fail("Wrong default value for RELAY_FUNCTIONS0"); 

   }


   my $o_RELAY_FUNCTIONSInfo= $o_TBInfo->get_param_info("RELAY_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2);
   my  $i_RELAY_FUNCTIONS1 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_FUNCTIONS1 != 1)
 
   {
     fail("Wrong default value for RELAY_FUNCTIONS1"); 

   }


   my $o_RELAY_FUNCTIONSInfo= $o_TBInfo->get_param_info("RELAY_FUNCTIONS"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5);
   my  $i_RELAY_FUNCTIONS4 = unpack("C", $rh_Result->{"Confirm"}->Data);
   if ($i_RELAY_FUNCTIONS4 != 40)
 
   {
     fail("Wrong default value for RELAY_FUNCTIONS4"); 

   }


   my $o_OPEN_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4);
   my  $f_ON_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_ON_TIME != 0)
 
   {
     fail("Wrong default value for ON_TIME"); 

   }


   my $o_OPEN_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5);
   my  $f_OFF_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_OFF_TIME != 0)
 
   {
     fail("Wrong default value for OFF_TIME"); 

   }


   my $o_CLOSE_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4);
   my  $f_ON_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_ON_TIME != 0)
 
   {
     fail("Wrong default value for ON_TIME"); 

   }


   my $o_CLOSE_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5);
   my  $f_OFF_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_OFF_TIME != 0)
 
   {
     fail("Wrong default value for OFF_TIME"); 

   }


   my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2);
   my  $f_START_POSITION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_START_POSITION != 0)
 
   {
     fail("Wrong default value for START_POSITION"); 

   }


   my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 3);
   my  $f_STOP_POSITION = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_STOP_POSITION != 0)
 
   {
     fail("Wrong default value for STOP_POSITION"); 

   }


   my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4);
   my  $f_ON_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_ON_TIME != 1)
 
   {
     fail("Wrong default value for ON_TIME"); 

   }


   my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5);
   my  $f_OFF_TIME = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_OFF_TIME != 1)
 
   {
     fail("Wrong default value for OFF_TIME"); 

   }


   my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo= $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL"); 
   $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 6);
   my  $f_DUTY_CYCLE = unpack("f", pack("N", unpack("V",$rh_Result->{"Confirm"}->Data)));
   if ($f_DUTY_CYCLE != 50)
 
   {
     fail("Wrong default value for DUTY_CYCLE"); 

   }


}


sub Teardown()
{
  Log("Teardown ADVT test script....");
}