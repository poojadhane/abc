#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify that all Static & Non-volatile parameters retains
 #          there previously written value after power reset.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;
 use ff_tools::od::fbap::fb_schedule;
 use constant RESTART_WITH_PROCESSOR             => 4;
 use constant MIB_PROFILE_NO                     => 0x4D47;
 use constant FBAP_PROFILE_NO                    => 0;
 use constant OD_VERSION                         => 1;
 use constant ABORT_REASON                       => 0x01; 

 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $o_STRATEGYInfo;
 my $o_ALERTKEYInfo;
 my $s_string;
 my $o_FACTORY_SOFTWAREInfo;
 my $o_CONTROL_MODEInfo;
 my $o_ACTUATOR_MODEInfo;
 my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo;
 my $o_ESD_DELAYInfo;
 my $o_ESD_ENABLES_AND_ACTIONInfo;
 my $o_HOST_COMMAND_ESDInfo;
 my $o_CONTROL_PARAM_1Info;
 my $o_MODULATION_PARAMETERSInfo;
 my $o_ANALOG_PARAMSInfo;
 my $o_RELAY_SETTINGSInfo;
 my $o_OPEN_SPEED_CONTROLInfo;
 my $o_CLOSE_SPEED_CONTROLInfo;
 my $o_VALVE_STALL_DELAY_TIMEInfo;
 my $o_RELAY_1_STATUSInfo;
 my $o_RELAY_2_STATUSInfo;
 my $o_RELAY_5_STATUSInfo; 
 my $o_ANALOG_OUTPUT_1Info;
 my $o_CONFIGURATION_COMMANDSInfo;
 my $o_DEFAULT_SETPOINTInfo;
 my $o_ACTUATOR_COMMANDInfo;
 my $o_SETPOINTInfo;
 my $i_integer;
 my $f_float;
 my $o_RELAY_FUNCTIONSInfo;
 my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo;
 
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex         = 1200; #ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex   = 1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "M2CP";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_M2CP.xls");
     
   my $o_ModeblkInfo = $o_RBInfo->get_param_info("MODE_BLK");
   my $o_RBlkMode = new ff_tools::od::fbap::blocks::mode_blk();
   $o_RBlkMode    = ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, OOS);
   if (!(ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, OOS)))
   {
     print("\n-> Test FAILED :Unable to set RB in OOS mode");
   }

  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to STRATEGY");
  }

  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("C", $o_ALERTKEYInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ALERT KEY");
  }

    $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  $s_string = "FF_EIM          ";
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1, length($s_string) ,$s_string);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to FACTORY_SOFTWARE TAG");
  }  
  
    $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  $s_string = "00200_edc2";
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2, length($s_string) ,$s_string);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to FACTORY_SOFTWARE serial number");
  }  
  
    $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCONTROL_MODE");
  }

  $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
  $f_float = pack("N", unpack("V", pack("f", $o_VALVE_STALL_DELAY_TIMEInfo->test_value)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toVALVE_STALL_DELAY_TIME");
  }

  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ACTUATOR_MODE");
  }

    $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
  $i_integer = pack("C", $o_CONFIGURATION_COMMANDSInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCONFIGURATION_COMMANDS");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to Enable Log Jam");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to Backseat");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to Seating");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 3.7)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMODULATION_PARAMETERS");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 7.8)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMODULATION_PARAMETERS");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 17)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toMODULATION_PARAMETERS");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toANALOG_PARAMS");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toANALOG_PARAMS");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toANALOG_PARAMS");
  }

  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toHOST_COMMAND_ESD");
  }

  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 85)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toLIMIT_SWITCH_TRIGGER_POINTS");
  }

  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 85)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toLIMIT_SWITCH_TRIGGER_POINTS");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_SETTINGS");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_SETTINGS");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 17);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 17);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 17);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_FUNCTIONS");
  }

  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 35)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toOPEN_SPEED_CONTROL");
  }

  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 35)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toOPEN_SPEED_CONTROL");
  }

  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 35)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCLOSE_SPEED_CONTROL");
  }

  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 35)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toCLOSE_SPEED_CONTROL");
  }

  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 75)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toANTI_WATER_HAMMER_SPEED_CONTROL");
  }

  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toANTI_WATER_HAMMER_SPEED_CONTROL");
  }

  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toANTI_WATER_HAMMER_SPEED_CONTROL");
  }

  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toESD_ENABLES_AND_ACTION");
  }

  $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
  $i_integer = pack("C", 50);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toANALOG_OUTPUT_1");
  }

  $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_1_STATUS");
  }

  $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_2_STATUS");
  }

  $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write toRELAY_5_STATUS");
  }
  
  $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $i_integer = pack("C", 50);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ESD_DELAY");
  }  
  
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 50)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to DEFAULT_SETPOINT1");
  }  
  
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 50)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to DEFAULT_SETPOINT2");
  }   
  
  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to ACTUATOR_COMMAND value");
  }   
  
  $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $i_integer = pack("C", 100);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Expected confirm positive for write to SETPOINT value");
  }   
 
#======================================================Power Cycle=====================================================================================
  my $o_RBRestartParamInfo = $o_RBInfo->get_param_info("RESTART");
  my $s_ProcRestart = pack("C", RESTART_WITH_PROCESSOR);
  ff_tools::hostapi::api::Write($i_DutFbapVcrId,$o_RBInfo->od_index + $o_RBRestartParamInfo->parameter_index,0,length($s_ProcRestart),$s_ProcRestart);

  ff_tools::hostapi::api::Abort($i_DutFbapVcrId,   ABORT_REASON);
  ff_tools::hostapi::api::Abort($i_DutMibVcrId,    ABORT_REASON);
  ff_tools::hostapi::api::WaitForInd($ff_tools::hostapi::SERVICE_CODE_SM_NEW_NODE_EVENT, 1000);
  ff_tools::hostapi::api::Initiate($i_DutFbapVcrId,  OD_VERSION, MIB_PROFILE_NO);
  ff_tools::hostapi::api::Initiate($i_DutMibVcrId, OD_VERSION, FBAP_PROFILE_NO);
#=======================================================================================================================================================
}
 sub Run() 
 { 
 

  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0);
  my $i_STRATEGY = unpack("n", $rh_Result->{"Confirm"}->Data);
  if ($i_STRATEGY != $o_STRATEGYInfo->test_value)
  {
    print("\n-> Test FAILED :Parameter STRATEGY Could not Retain value");
  }

  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0);
  my $i_ALERTKEY = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ALERTKEY != $o_ALERTKEYInfo->test_value)
  {
    print("\n-> Test FAILED :Parameter ALERT KEY Could not Retain value");
  }

  $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1);
  if ($rh_Result->{"Confirm"}->Data ne "FF_EIM          ")
  {
    print("\n-> Test FAILED :Parameter FACTORY_SOFTWARE TAG Could not Retain value");
  } 

  $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2);
  if ($rh_Result->{"Confirm"}->Data ne "00200_edc2")
  {
    print("\n-> Test FAILED :Parameter FACTORY_SOFTWARE serial number Could not Retain value");
  }  
  
  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0);
  my $i_CONTROL_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_MODE != $o_CONTROL_MODEInfo->test_value)
  {
    print("\n-> Test FAILED :Parameter CONTROL_MODE Could not Retain value");
  }

  $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0);
  my $f_VALVE_STALL_DELAY_TIME = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_VALVE_STALL_DELAY_TIME != $o_VALVE_STALL_DELAY_TIMEInfo->test_value)
  {
    print("\n-> Test FAILED :Parameter VALVE_STALL_DELAY_TIME Could not Retain value");
  }

  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0);
  my $i_ACTUATOR_MODE = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ACTUATOR_MODE == $o_ACTUATOR_MODEInfo->test_value)
  {
    print("\n-> Test FAILED :Dynamic Parameter ACTUATOR_MODE Could Retain value");
  }

  $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0);
  my $i_CONFIGURATION_COMMANDS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONFIGURATION_COMMANDS == $o_CONFIGURATION_COMMANDSInfo->test_value)
  {
    print("\n-> Test FAILED :Dynamic Parameter CONFIGURATION_COMMANDS Could Retain value");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,1);
  my $i_CONTROL_PARAM_1 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_1 != 1)
  {
    print("\n-> Test FAILED :Parameter ENABLE_LOG_JAM Could not Retain value");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,4);
  $i_CONTROL_PARAM_1 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_1 != 1)
  {
    print("\n-> Test FAILED :Parameter BACKSEAT Could not Retain value");
  }

  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index,5);
  $i_CONTROL_PARAM_1 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_CONTROL_PARAM_1 != 1)
  {
    print("\n-> Test FAILED :Parameter SEATING Could not Retain value");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,1);
  my $f_MODULATION_PARAMETERS = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_MODULATION_PARAMETERS!= 3.7)
  {
    print("\n-> Test FAILED :Parameter POSITION_CONTROL_BANDWIDTH Could not Retain value");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,2);
  $f_MODULATION_PARAMETERS = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_MODULATION_PARAMETERS!= 7.8)
  {
    print("\n-> Test FAILED :Parameter SPEED_CONTROL_BANDWIDTH Could not Retain value");
  }

  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index,3);
  $f_MODULATION_PARAMETERS = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_MODULATION_PARAMETERS!= 17)
  {
    print("\n-> Test FAILED :Parameter MODULATION_DELAY Could not Retain value");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1);
  my $i_ANALOG_PARAMS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ANALOG_PARAMS != 1)
  {
    print("\n-> Test FAILED :Parameter LOST_ANALOG_INPUT_ACTION Could not Retain value");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,2);
  $i_ANALOG_PARAMS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ANALOG_PARAMS != 1)
  {
    print("\n-> Test FAILED :Parameter LOST_ANALOG_INPUT_2_ACTION Could not Retain value");
  }

  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5);
  $i_ANALOG_PARAMS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ANALOG_PARAMS != 1)
  {
    print("\n-> Test FAILED :Parameter ANALOG_OUTPUT_1_SOURCE Could not Retain value");
  }

  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index,1);
  my $i_HOST_COMMAND_ESD = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_HOST_COMMAND_ESD != 1)
  {
    print("\n-> Test FAILED :Parameter VALUE Could not Retain value");
  }

  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,1);
  my $f_LIMIT_SWITCH_TRIGGER_POINTS = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_LIMIT_SWITCH_TRIGGER_POINTS != 85)
  {
    print("\n-> Test FAILED :Parameter LIMIT_SWITCH_A_(LSA)_TRIGGER_POINT Could not Retain value");
  }

  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index,2);
  $f_LIMIT_SWITCH_TRIGGER_POINTS = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_LIMIT_SWITCH_TRIGGER_POINTS != 85)
  {
    print("\n-> Test FAILED :Parameter LIMIT_SWITCH_B_(LSB)_TRIGGER_POINT Could not Retain value");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,1);
  my $i_RELAY_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_SETTINGS != 4)
  {
    print("\n-> Test FAILED :Parameter RELAY_SETTINGS[0] Could not Retain value");
  }

  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,2);
  $i_RELAY_SETTINGS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_SETTINGS != 4)
  {
    print("\n-> Test FAILED :Parameter RELAY_SETTINGS[1] Could not Retain value");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,1);
  my $i_RELAY_FUNCTIONS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_FUNCTIONS!= 17)
  {
    print("\n-> Test FAILED :Parameter RELAY_FUNCTIONS[0] Could not Retain value");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,2);
  $i_RELAY_FUNCTIONS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_FUNCTIONS!= 17)
  {
    print("\n-> Test FAILED :Parameter RELAY_FUNCTIONS[1] Could not Retain value");
  }

  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,5);
  $i_RELAY_FUNCTIONS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_FUNCTIONS!= 17)
  {
    print("\n-> Test FAILED :Parameter RELAY_FUNCTIONS[4] Could not Retain value");
  }

  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,4);
  my $f_OPEN_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_OPEN_SPEED_CONTROL != 35)
  {
    print("\n-> Test FAILED :Parameter ON_TIME Could not Retain value");
  }

  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,5);
  $f_OPEN_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_OPEN_SPEED_CONTROL != 35)
  {
    print("\n-> Test FAILED :Parameter OFF_TIME Could not Retain value");
  }

  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,4);
  my $f_CLOSE_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_CLOSE_SPEED_CONTROL != 35)
  {
    print("\n-> Test FAILED :Parameter ON_TIME Could not Retain value");
  }

  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,5);
  $f_CLOSE_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_CLOSE_SPEED_CONTROL != 35)
  {
    print("\n-> Test FAILED :Parameter OFF_TIME Could not Retain value");
  }

  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,2);
  my $f_ANTI_WATER_HAMMER_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_ANTI_WATER_HAMMER_SPEED_CONTROL!= 75)
  {
    print("\n-> Test FAILED :Parameter START_POSITION Could not Retain value");
  }

  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,4);
  $f_ANTI_WATER_HAMMER_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_ANTI_WATER_HAMMER_SPEED_CONTROL != 1)
  {
    print("\n-> Test FAILED :Parameter ON_TIME Could not Retain value");
  }

  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,5);
  $f_ANTI_WATER_HAMMER_SPEED_CONTROL = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_ANTI_WATER_HAMMER_SPEED_CONTROL != 1)
  {
    print("\n-> Test FAILED :Parameter OFF_TIME Could not Retain value");
  }

  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index,2);
  my $i_ESD_ENABLES_AND_ACTION = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ESD_ENABLES_AND_ACTION != 2)
  {
    print("\n-> Test FAILED :Parameter ESD_ACTION Could not Retain value");
  }

  $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index,1);
  my $i_ANALOG_OUTPUT_1 = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ANALOG_OUTPUT_1 == 50)
  {
    print("\n-> Test FAILED :Parameter VALUE Could Retain value");
  }

  $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index,1);
  my $i_RELAY_1_STATUS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_1_STATUS == 1)
  {
    print("\n-> Test FAILED :Dynamic Parameter RELAY_1_STATUS VALUE Could Retain value");
  }

  $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index,1);
  my $i_RELAY_2_STATUS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_2_STATUS == 1)
  {
    print("\n-> Test FAILED :Dynamic Parameter RELAY_2_STATUS VALUE Could Retain value");
  }

  $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index,1);
  my $i_RELAY_5_STATUS = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_5_STATUS == 1)
  {
    print("\n-> Test FAILED :Dynamic RELAY_5_STATUS Parameter VALUE Could Retain value");
  }
  
  $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index,0);
  my $i_ESD_DELAY = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_ESD_DELAY != 50)
  {
    print("\n-> Test FAILED :Parameter ESD_DELAY Could not Retain value");
  } 

  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,1);
  my $f_DEFAULT_SETPOINT = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_DEFAULT_SETPOINT != 50)
  {
    print("\n-> Test FAILED :Parameter DEFAULT_SETPOINT1 Could not Retain value");
  }  
  
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,2);
  $f_DEFAULT_SETPOINT = unpack("f", pack("N", unpack("V", $rh_Result->{"Confirm"}->Data)));
  if ($f_DEFAULT_SETPOINT != 50)
  {
    print("\n-> Test FAILED :Parameter DEFAULT_SETPOINT2 Could not Retain value");
  }  

  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index,1);
  my $i_ACTUATOR_COMMAND = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_5_STATUS != 0)
  {
    print("\n-> Test FAILED : ACTUATOR_COMMAND Parameter VALUE Could not Retain value");
  }

  $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index,1);
  my $i_SETPOINT = unpack("C", $rh_Result->{"Confirm"}->Data);
  if ($i_RELAY_5_STATUS != 100)
  {
    print("\n-> Test FAILED : SETPOINT Parameter VALUE Could not Retain value");
  }  
 }
 
 
sub Teardown()
{
  Log("Teardown ADVT test script....");
}  