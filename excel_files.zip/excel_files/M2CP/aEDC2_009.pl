#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify RW access each TB block parameter according to the modes defined in 
 #          parameter table.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex         = 1200; #ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex   = 1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "M2CP";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_M2CP.xls");
     
}
 sub Run() 
 { 
 
  my $o_ModeblkInfo = $o_RBInfo->get_param_info("MODE_BLK");
  my $o_TBModeblkInfo = $o_TBInfo->get_param_info("MODE_BLK");
  my @i_allowed_mode = (OOS,AUTO,MAN);
  my @i_allow_mode_string = ("OS","AUTO","MAN");
  my $o_RBBlkMode = new ff_tools::od::fbap::blocks::mode_blk();
  $o_RBBlkMode = ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, AUTO);
  if (!(ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, AUTO)))
  {
    print("\n-> Test FAILED :Unable to set RB in AUTO mode \n");
  }
  
  
  for (my $i=0; $i<=length(@i_allowed_mode); $i++)
  {
    if (!(ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_TBBlkIndex + $o_TBModeblkInfo->parameter_index, $i_allowed_mode[$i])))
    {
      print("\n-> Test FAILED :Unable to set TB in %s mode", $i_allow_mode_string[$i]);
    }

    my $o_TAGDESCInfo = $o_TBInfo->get_param_info("TAG_DESC");
    if ($o_TAGDESCInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TAGDESCInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to TAG DESC \n");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TAGDESCInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to TAG DESC \n");
      }
    }

    my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
    if ($o_STRATEGYInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to STRATEGY \n");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to STRATEGY \n");
      }
    }

    my $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
    if ($o_ALERTKEYInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ALERT KEY \n");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ALERT KEY \n");
      }
    }

    my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
    if ($o_CONTROL_MODEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to CONTROL_MODE \n");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to CONTROL_MODE \n");
      }
    }
	

    my $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
    if ($o_ESD_DELAYInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ESD_DELAY \n");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ESD_DELAY \n");
      }
    }

    my $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
    if ($o_VALVE_STALL_DELAY_TIMEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toVALVE_STALL_DELAY_TIME \n");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toVALVE_STALL_DELAY_TIME \n");
      }
    }

    my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    if ($o_ACTUATOR_MODEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ACTUATOR_MODE \n");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ACTUATOR_MODE \n");
      }
    }

    my $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
    if ($o_CONFIGURATION_COMMANDSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toCONFIGURATION_COMMANDS \n");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toCONFIGURATION_COMMANDS \n");
      }
    }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOG_JAM \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toCONTROL_PARAM_1 \n");
      }
    }

    $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to BACKSEAT \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toCONTROL_PARAM_1 \n");
      }
    }

    $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to SEATING \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toCONTROL_PARAM_1 \n");
      }
    }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
    if ($o_MODULATION_PARAMETERSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to POSITION_CONTROL_BANDWIDTH \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toMODULATION_PARAMETERS \n");
      }
    }

    $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
    if ($o_MODULATION_PARAMETERSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to SPEED_CONTROL_BANDWIDTH \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toMODULATION_PARAMETERS \n");
      }
    }

    $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
    if ($o_MODULATION_PARAMETERSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to MODULATION_DELAY \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toMODULATION_PARAMETERS \n");
      }
    }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LOST_ANALOG_INPUT_ACTION \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LOST_ANALOG_INPUT_ACTION \n");
      }
    }

    $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LOST_ANALOG_INPUT_2_ACTION \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LOST_ANALOG_INPUT_2_ACTION \n");
      }
    }

    $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_OUTPUT_1_SOURCE \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_1_SOURCE \n");
      }
    }

    my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
    if ($o_HOST_COMMAND_ESDInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to VALUE \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toHOST_COMMAND_ESD \n");
      }
    }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
    if ($o_LIMIT_SWITCH_TRIGGER_POINTSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LIMIT_SWITCH_A_(LSA)_TRIGGER_POINT \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toLIMIT_SWITCH_TRIGGER_POINTS \n");
      }
    }

    $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
    if ($o_LIMIT_SWITCH_TRIGGER_POINTSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LIMIT_SWITCH_B_(LSB)_TRIGGER_POINT \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toLIMIT_SWITCH_TRIGGER_POINTS \n");
      }
    }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS[0] \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS[0] \n");
      }
    }

    $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS[1] \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS[1] \n");
      }
    }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS[0] \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS[0] \n");
      }
    }

    $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS[1] \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS[1] \n");
      }
    }

    $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS[4] \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS[4] \n");
      }
    }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ON_TIME \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ON_TIME \n");
      }
    }

    $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to OFF_TIME \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to OFF_TIME \n");
      }
    }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ON_TIME \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ON_TIME \n");
      }
    }

    $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to OFF_TIME \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to OFF_TIME \n");
      }
    }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
    if ($o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to START_POSITION \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to START_POSITION \n");
      }
    }

    $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
    if ($o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ON_TIME \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ON_TIME \n");
      }
    }

    $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
    if ($o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to OFF_TIME \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to OFF_TIME \n");
      }
    }


    my $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
    if ($o_ESD_ENABLES_AND_ACTIONInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ESD_ACTION \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ESD_ENABLES_AND_ACTION \n");
      }
    }

    #my $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
    #if ($o_FACTORY_SOFTWAREInfo->mode_for_write =~ $i_allow_mode_string[$i])
    #{
  #$rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1);
  #    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
  #    {
  #      print("\n-> Test FAILED :Expected confirm positive for read to TAG \n");
  #    }
  #ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
  #    if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  #    {
  #      print("\n-> Test FAILED :Expected confirm positive for write toFACTORY_SOFTWARE \n");
  #    }
  #  }

 #   $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE");
 #   if ($o_FACTORY_SOFTWAREInfo->mode_for_write =~ $i_allow_mode_string[$i])
 #   {
 # $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2);
 #     if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
 #     {
 #       print("\n-> Test FAILED :Expected confirm positive for read to SERIAL_NUMBER \n");
 #     }
 # ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
 #     if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
 #     {
 #       print("\n-> Test FAILED :Expected confirm positive for write toFACTORY_SOFTWARE \n");
 #     }
 #   }

    my $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
    if ($o_ANALOG_OUTPUT_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to VALUE \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toANALOG_OUTPUT_1 \n");
      }
    }

    my $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
    if ($o_RELAY_1_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to VALUE \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toRELAY_1_STATUS \n");
      }
    }

    my $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
    if ($o_RELAY_2_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to VALUE \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toRELAY_2_STATUS \n");
      }
    }

    my $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
    if ($o_RELAY_5_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to VALUE \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toRELAY_5_STATUS \n");
      }
    }

    my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
    if ($o_ACTUATOR_COMMANDInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to VALUE \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toACTUATOR_COMMAND \n");
      }
    }

    my $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
    if ($o_SETPOINTInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to VALUE \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toSETPOINT \n");
      }
    }
	
    my $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
    if ($o_DEFAULT_SETPOINTInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DEFAULT_SETPOINT1 \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DEFAULT_SETPOINT1 \n");
      }
    }	
	
    $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
    if ($o_DEFAULT_SETPOINTInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {
  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DEFAULT_SETPOINT2 \n");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DEFAULT_SETPOINT2 \n");
      }
    }	
	
 }
}


sub Teardown()
{
  Log("Teardown ADVT test script....");
}