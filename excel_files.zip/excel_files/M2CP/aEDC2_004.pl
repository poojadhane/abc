#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify all boundaries for parameters that are
 #          having range of valid values for M2CP actuator.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $f_float;
 my $i_integer;
 my $o_CLOSE_SPEED_CONTROLInfo;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex         = 1200; # ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex   = 1000; # ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "M2CP";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_M2CP.xls");
     
 }
 sub Run() 
 { 
 
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write STRATEGY for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("n", $o_STRATEGYInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write STRATEGY for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("N", $o_STRATEGYInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write STRATEGY for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
  $i_integer = pack("N", $o_STRATEGYInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write STRATEGY for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("C", $o_ALERTKEYInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ALERT KEY for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("C", $o_ALERTKEYInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ALERT KEY for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("N", $o_ALERTKEYInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write ALERT KEY for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ALERTKEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
  $i_integer = pack("N", $o_ALERTKEYInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERTKEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write ALERT KEY for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CONTROL_MODE for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write CONTROL_MODE for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("N", $o_CONTROL_MODEInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write CONTROL_MODE for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
  $i_integer = pack("C", $o_CONTROL_MODEInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write CONTROL_MODE for out of range value \n ");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR_MODE for minimum range value \n ");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR_MODE for maximum range value \n ");
    }		
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("N", $o_ACTUATOR_MODEInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ACTUATOR_MODE for OUT range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
  $i_integer = pack("C", $o_ACTUATOR_MODEInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ACTUATOR_MODE for OUT range value \n ");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_TRIGGER_POINTS for minimum range value \n ");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_TRIGGER_POINTS for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", -1)));
  # $f_float = pack ("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_TRIGGER_POINTS for OUT OF range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_TRIGGER_POINTS for OUT OF range value \n ");
    }	
	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_TRIGGER_POINTS for minimum range value \n ");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LIMIT_SWITCH_TRIGGER_POINTS for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", -1)));
  # $f_float = pack ("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write for LIMIT_SWITCH_TRIGGER_POINTS FOR OUT OF range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LIMIT_SWITCH_TRIGGER_POINTS for OUT OF range value \n ");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
  $f_float = pack("N", unpack("V", pack("f", $o_VALVE_STALL_DELAY_TIMEInfo->min_range_value)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write VALVE_STALL_DELAY_TIME for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
  $f_float = pack("N", unpack("V", pack("f", $o_VALVE_STALL_DELAY_TIMEInfo->max_range_value)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write VALVE_STALL_DELAY_TIME for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
  $f_float = pack("N", unpack("V", pack("f", $o_VALVE_STALL_DELAY_TIMEInfo->min_range_value - 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write VALVE_STALL_DELAY_TIME for out of range value \n ");
    }
 
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
  $f_float = pack("N", unpack("V", pack("f", $o_VALVE_STALL_DELAY_TIMEInfo->max_range_value + 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write VALVE_STALL_DELAY_TIME for out of range value \n ");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $i_integer = pack("C", $o_ESD_DELAYInfo->min_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ESD_DELAY for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $i_integer = pack("C", $o_ESD_DELAYInfo->max_range_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ESD_DELAY for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $i_integer = pack("N", $o_ESD_DELAYInfo->min_range_value - 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ESD_DELAY for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY");
  $i_integer = pack("C", $o_ESD_DELAYInfo->max_range_value + 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ESD_DELAY for out of range value \n ");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ESD_ENABLES_AND_ACTION for minimum range value \n ");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ESD_ENABLES_AND_ACTION for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ESD_ENABLES_AND_ACTION for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ESD_ENABLES_AND_ACTION for out of range value \n ");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write HOST_COMMAND_ESD for minimum range value \n ");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write HOST_COMMAND_ESD for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write HOST_COMMAND_ESD for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write HOST_COMMAND_ESD for out of range value \n ");
    }	

	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ENABLE_LOG_JAM for minimum range value \n ");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ENABLE_LOG_JAM for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOG_JAM for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ENABLE_LOG_JAM for out of range value \n ");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write BACKSEAT for minimum range value \n ");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write BACKSEAT for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write BACKSEAT for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write BACKSEAT for out of range value \n ");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SEATING for minimum range value \n ");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SEATING for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SEATING for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write SEATING for out of range value \n ");
    }
	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 0.1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Position Control Bandwidth for minimum range value \n ");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Position Control Bandwidth for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", -0.9)));
  # $f_float = pack ("d", -0.9);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write for Position Control Bandwidth FOR OUT OF range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 6)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Position Control Bandwidth for OUT OF range value \n ");
    }		
	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 0.5)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Speed Control Bandwidth for minimum range value \n ");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 10)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Speed Control Bandwidth for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", -0.5)));
  # $f_float = pack ("d", -0.5);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write for Speed Control Bandwidth FOR OUT OF range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 11)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Speed Control Bandwidth for OUT OF range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 1)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Modulation Delay for minimum range value \n ");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 25)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write Modulation Delay for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  # $f_float = pack ("d", -0.9);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write for Modulation Delay FOR OUT OF range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
  $f_float = pack("N", unpack("V", pack("f", 26)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write Modulation Delay for OUT OF range value \n ");
    }	


  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LOST_ANALOG_INPUT_ACTION for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::writ0e_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LOST_ANALOG_INPUT_ACTION for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOST_ANALOG_INPUT_ACTION for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOST_ANALOG_INPUT_ACTION for out of range value \n ");
    }	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write LOST_ANALOG_INPUT2_ACTION for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::writ0e_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write LOST_ANALOG_INPUT2_ACTION for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOST_ANALOG_INPUT2_ACTION for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write LOST_ANALOG_INPUT2_ACTION for out of range value \n ");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_1_SOURCE for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,4, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_1_SOURCE for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_1_SOURCE for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index,5, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_1_SOURCE for out of range value \n ");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS0 for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 5);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS0 for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS0 for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 6);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS0 for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS1 for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 5);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_SETTINGS1 for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS1 for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
  $i_integer = pack("C", 6);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_SETTINGS1 for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS0 for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 42);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS0 for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS0 for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 43);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS0 for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS1 for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 42);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_FUNCTIONS1 for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS1 for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
  $i_integer = pack("C", 43);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index,2, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write RELAY_FUNCTIONS1 for out of range value \n ");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ON_TIME for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 60)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ON_TIME for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could not Write ON_TIME for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("d", 61);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could not Write ON_TIME for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write OFF_TIME for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 60)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write OFF_TIME for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", -1)));
  #$f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OFF_TIME for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 61)));
  #$f_float = pack("d", 61);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OFF_TIME for out of range value \n ");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write ON_TIME for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 60)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ON_TIME for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", -1)));
  #$f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ON_TIME for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 61)));
  #$f_float = pack("d", 61);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,4, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write ON_TIME for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write OFF_TIME for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 60)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write OFF_TIME for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", -1)));
  #$f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OFF_TIME for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 61)));
  #$f_float = pack("d", 61);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index,5, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could  Write OFF_TIME for out of range value \n ");
    }
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write START_POSITION for minimum range value \n ");
  }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write START_POSITION for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", -1)));
  #$f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
  {
    print("\n-> Test FAILED :Could Write START_POSITION for out of range value \n ");
  }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
  {
    print("\n-> Test FAILED :Could Write START_POSITION for out of range value \n ");
  }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;  
  my $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write DEFAULT_SETPOINT_1 for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,1, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write DEFAULT_SETPOINT_1 for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", -1)));
  #$f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write DEFAULT_SETPOINT_1 for out of range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,1, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write DEFAULT_SETPOINT_1 for out of range value");
    }	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;	
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 0)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
  {
    print("\n-> Test FAILED :Could not Write DEFAULT_SETPOINT_1 for minimum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 100)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,2, length($f_float) ,$f_float);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write DEFAULT_SETPOINT_1 for maximum range value");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", -1)));
  #$f_float = pack("d", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write DEFAULT_SETPOINT_1 for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
  $f_float = pack("N", unpack("V", pack("f", 101)));
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index,2, length($f_float) ,$f_float);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
  {
    print("\n-> Test FAILED :Could Write DEFAULT_SETPOINT_1 for out of range value \n ");
  }	
  
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR_COMMAND for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("C", 3);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ACTUATOR_COMMAND for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write ACTUATOR_COMMAND for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
  $i_integer = pack("C", 4);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write ACTUATOR_COMMAND for out of range value \n ");
    }  
	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SETPOINT for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $i_integer = pack("C", 100);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write SETPOINT for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write SETPOINT for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
  $i_integer = pack("C", 101);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write SETPOINT for out of range value \n ");
    }  	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_1_STATUS for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_1_STATUS for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_1_STATUS for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_1_STATUS for out of range value \n ");
    } 	

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_2_STATUS for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_2_STATUS for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_2_STATUS for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_2_STATUS for out of range value \n ");
    } 
	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_5_STATUS for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
  $i_integer = pack("C", 1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write RELAY_5_STATUS for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_5_STATUS for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
  $i_integer = pack("C", 2);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write RELAY_5_STATUS for out of range value \n ");
    } 	
	
	
  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  my $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
  $i_integer = pack("C", 0);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_1 for minimum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
  $i_integer = pack("C", 100);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
    {
    print("\n-> Test FAILED :Could not Write ANALOG_OUTPUT_1 for maximum range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
  $i_integer = pack("N", -1);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write ANALOG_OUTPUT_1 for out of range value \n ");
    }

  $ff_tools::hostapi::api::InclOnCnfNeg = 0;
  $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
  $i_integer = pack("C", 101);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
  if ($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos'))
    {
    print("\n-> Test FAILED :Could Write ANALOG_OUTPUT_1 for out of range value \n ");
    }	
	
}
sub Teardown()
{
  Log("Teardown ADVT test script....");
}