#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify RW access each TB block parameter as defined in 
 #          parameter table.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;

 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $i_integer;
 my $f_float;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex = ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "HQ";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_HQ.xls");
     
}
 sub Run() 
 { 
 

    my $o_TAG DESCInfo = $o_TBInfo->get_param_info("TAG_DESC")

      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TAG DESCInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to TAG DESC");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TAG DESCInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to TAG DESC");
      }
    

    my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY")

      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to STRATEGY");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write to STRATEGY");
      }
    

    my $o_ALERT KEYInfo = $o_TBInfo->get_param_info("ALERT_KEY")

      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT KEYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toALERT KEY");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT KEYInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toALERT KEY");
      }
    


    my $o_ESD_DELAYInfo = $o_TBInfo->get_param_info("ESD_DELAY")

      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toESD_DELAY");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_DELAYInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toESD_DELAY");
      }
    

    my $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME")

      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toVALVE_STALL_DELAY_TIME");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toVALVE_STALL_DELAY_TIME");
      }
    

    my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE")

      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toCONTROL_MODE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toCONTROL_MODE");
      }
    

    my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE")

      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toACTUATOR_MODE");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toACTUATOR_MODE");
      }
    

    my $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS")

      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read toCONFIGURATION_COMMANDS");
      }
      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toCONFIGURATION_COMMANDS");
      }
    

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to SEATING");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toCONTROL_PARAM_1");
      }
    

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to POSITION_CONTROL_BANDWIDTH");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toMODULATION_PARAMETERS");
      }
    

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to MODULATION_DELAY");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toMODULATION_PARAMETERS");
      }
    

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ANALOG_OUTPUT_1_SOURCE");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toANALOG_PARAMS");
      }
    

    my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to VALUE");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toHOST_COMMAND_ESD");
      }
    

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ON_TIME");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toOPEN_SPEED_CONTROL");
      }
    

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OFF_TIME");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toOPEN_SPEED_CONTROL");
      }
    

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ON_TIME");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toCLOSE_SPEED_CONTROL");
      }
    

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OFF_TIME");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toCLOSE_SPEED_CONTROL");
      }
    

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to START_POSITION");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toANTI_WATER_HAMMER_SPEED_CONTROL");
      }
    

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ON_TIME");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toANTI_WATER_HAMMER_SPEED_CONTROL");
      }
    

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to OFF_TIME");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toANTI_WATER_HAMMER_SPEED_CONTROL");
      }
    
    
	
    my $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to ESD_ACTION");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toESD_ENABLES_AND_ACTION");
      }
    

    my $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to TAG");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toFACTORY_SOFTWARE");
      }
    

    my $o_FACTORY_SOFTWAREInfo = $o_TBInfo->get_param_info("FACTORY_SOFTWARE")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to SERIAL_NUMBER");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_FACTORY_SOFTWAREInfo->parameter_index, 2, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toFACTORY_SOFTWARE");
      }
    

    my $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to VALUE");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toANALOG_OUTPUT_1");
      }
    

    my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to VALUE");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toACTUATOR_COMMAND");
      }
    

    my $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT")

  $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        fail("Expected confirm positive for read to VALUE");
      }
  ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 1, length($rh_Result->{"Confirm"}->Data) ,$rh_Result->{"Confirm"}->Data);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        fail("Expected confirm positive for write toSETPOINT");
      }
    
}


sub Teardown()
{
  Log("Teardown ADVT test script....");
}