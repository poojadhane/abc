#======================================================================================================[
 # Author: Anuja Dhane.
 #
 # Purpose: To verify RW access each TB block parameter according to the modes defined in 
 #          parameter table.
 #
 # Requirement:
 #      1) HOST as non LAS device.
 #      2) DUT as LAS and publisher.
 #      3) REMOTE DEVICE as basic device and subscriber.
 #
 # Copyright (c) 2014 Emerson Process Management, LLLP.
 #======================================================================================================]
 use strict;
 use warnings;
 use advt::testcase::ff::lm::sis::sis_device_network;
 use ff_tools::od::index::sod;
 use excel_db::info;
 use ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk;
 #============================  Testcase Data ==================================
 my $i_HostAddr;
 my $i_DutAddr;
 my $i_ResourceBlkIndex;
 my $i_HostInternalVcrId;
 my $i_DutMibVcrId;
 my $i_DutFbapVcrId;
 my $i_TBBlkIndex;
 my $rh_Result;
 my $o_RBInfo;
 my $o_TBInfo;
 my $i_allow_mode_string;
 my @i_allow_mode_string;
 my $i_allowed_mode;
 my @i_allowed_mode;
 my $i_integer;
 my $f_float;
 #================================== Test case =================================#

 sub Setup()
 {
   $i_HostAddr           = device_configuration()->identity->node_address;
 
   $i_DutAddr            = testing_configuration()->remote_device("ff_sis_device")->identity->node_address;
 
   $i_HostInternalVcrId  = $ff_tools::hostapi::VCR_ID_INTERNAL_ACCESS;
 
   $i_DutMibVcrId        = $advt::testcase::ff::lm::sis::sis_device_network::mib_vcr_id;
 
   $i_DutFbapVcrId       = $advt::testcase::ff::lm::sis::sis_device_network::fbap_vcr_id;
     
   $i_TBBlkIndex   = 1200; #ff_tools::od::index::sod::get("TRANSDUCER_BLOCK",0);
   $i_ResourceBlkIndex = 1000; #ff_tools::od::index::sod::get("RESOURCE_BLOCK",0);
     
   $o_RBInfo = new excel_db::info();
   $o_TBInfo = new excel_db::info();
     
   $o_RBInfo->blk_name = "RB";
   $o_RBInfo->od_index = $i_ResourceBlkIndex;
   $o_RBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_ResourceBlkIndex);
   $o_RBInfo->parse_execel_db("CRB_DB1.xls");
     
   $o_TBInfo->blk_name = "TEC2";
   $o_TBInfo->od_index = $i_TBBlkIndex;
   $o_TBInfo->blk_rec  = ff_tools::od::index::sod::get_blk_rec($i_TBBlkIndex);
   $o_TBInfo->parse_execel_db("DATABASE_TEC2.xls");
     
}
 sub Run() 
 { 
 
  my $o_ModeblkInfo = $o_RBInfo->get_param_info("MODE_BLK");
  my $o_TBModeblkInfo = $o_TBInfo->get_param_info("MODE_BLK");
  my @i_allowed_mode = (OOS,AUTO,MAN);
 # my @i_allow_mode_string = ("OS %s mode","AUTO %s mode","MAN %s mode");
  my @i_allow_mode_string = ("OS","AUTO","MAN");  
  
  my $o_RBBlkMode = new ff_tools::od::fbap::blocks::mode_blk();
  $o_RBBlkMode = ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, AUTO);
  if (!(ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_ResourceBlkIndex + $o_ModeblkInfo->parameter_index, AUTO)))
  {
   print("\n-> Test FAILED :Unable to set RB in AUTO mode");
  }
  $i_allowed_mode = @i_allowed_mode;
  for (my $i=0; $i<= 2; $i++)
  {
  print("TEST for MODE:",$i."\n"); 
    if (!(ff_tools::od::fbap::blocks::mode_blk::get_set_mode_blk::set_mode($i_TBBlkIndex + $o_TBModeblkInfo->parameter_index, $i_allowed_mode[$i])))
    {
      print("\n-> Test FAILED :Unable to set TB in %s mode", $i_allow_mode_string[$i]);
    }

      my $o_STRATEGYInfo = $o_TBInfo->get_param_info("STRATEGY");
    if ($o_STRATEGYInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to STRATEGY");
      }
      $i_integer = pack("n", $o_STRATEGYInfo->test_value);
  $rh_Result = ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_STRATEGYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to STRATEGY");
      }
	  }

      my $o_ALERT_KEYInfo = $o_TBInfo->get_param_info("ALERT_KEY");
    if ($o_ALERT_KEYInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT_KEYInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ALERT_KEY");
      }
      $i_integer = pack("C", $o_ALERT_KEYInfo->test_value);
  $rh_Result =    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ALERT_KEYInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ALERT_KEY");
      }
	  }

      my $o_CONTROL_MODEInfo = $o_TBInfo->get_param_info("CONTROL_MODE");
    if ($o_CONTROL_MODEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to CONTROL_MODE");
      }
      $i_integer = pack("C", $o_CONTROL_MODEInfo->test_value);
  $rh_Result =    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to CONTROL_MODE");
      }
	  }

      my $o_CUSTOM_CHARACTERIZATION_TYPEInfo = $o_TBInfo->get_param_info("CUSTOM_CHARACTERIZATION_TYPE");
    if ($o_CUSTOM_CHARACTERIZATION_TYPEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CUSTOM_CHARACTERIZATION_TYPEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to CUSTOM_CHARACTERIZATION_TYPE");
      }
      $i_integer = pack("C", $o_CUSTOM_CHARACTERIZATION_TYPEInfo->test_value);
  $rh_Result =    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CUSTOM_CHARACTERIZATION_TYPEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to CUSTOM_CHARACTERIZATION_TYPE");
      }
	  }
$ff_tools::hostapi::api::InclOnCnfNeg = 0;
      my $o_TARGET_TRAVELInfo = $o_TBInfo->get_param_info("TARGET_TRAVEL");
    if ($o_TARGET_TRAVELInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TARGET_TRAVELInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to TARGET_TRAVEL");
      }
      $i_integer = pack("C", $o_TARGET_TRAVELInfo->test_value);
  $rh_Result =    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TARGET_TRAVELInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to TARGET_TRAVEL");
      }
	  }

      my $o_VALVE_STALL_DELAY_TIMEInfo = $o_TBInfo->get_param_info("VALVE_STALL_DELAY_TIME");
    if ($o_VALVE_STALL_DELAY_TIMEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to VALVE_STALL_DELAY_TIME");
      }
      $f_float = pack("N", unpack("V", pack("f",  $o_VALVE_STALL_DELAY_TIMEInfo->test_value)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_VALVE_STALL_DELAY_TIMEInfo->parameter_index, 0, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to VALVE_STALL_DELAY_TIME");
      }
	  }

      my $o_ACTUATOR_MODEInfo = $o_TBInfo->get_param_info("ACTUATOR_MODE");
    if ($o_ACTUATOR_MODEInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ACTUATOR_MODE");
      }
      $i_integer = pack("C", $o_ACTUATOR_MODEInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_MODEInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ACTUATOR_MODE");
      }
	  }

      my $o_CONFIGURATION_COMMANDSInfo = $o_TBInfo->get_param_info("CONFIGURATION_COMMANDS");
    if ($o_CONFIGURATION_COMMANDSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to CONFIGURATION_COMMANDS");
      }
      $i_integer = pack("C", $o_CONFIGURATION_COMMANDSInfo->test_value);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONFIGURATION_COMMANDSInfo->parameter_index, 0, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to CONFIGURATION_COMMANDS");
      }
	  }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOG_JAM");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOG_JAM");
      }
	  }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to REMOTE_CONTROL_SIGNAL");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to REMOTE_CONTROL_SIGNAL");
      }
	  }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LOCAL_CONTROL_SIGNAL");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LOCAL_CONTROL_SIGNAL");
      }
	  }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to BACKSEAT");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to BACKSEAT");
      }
	  }

    my $o_CONTROL_PARAM_1Info = $o_TBInfo->get_param_info("CONTROL_PARAM_1");
    if ($o_CONTROL_PARAM_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to SEATING");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_1Info->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to SEATING");
      }
	  }

    my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
    if ($o_CONTROL_PARAM_2Info->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LED_COLOR");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LED_COLOR");
      }
	  }

    my $o_CONTROL_PARAM_2Info = $o_TBInfo->get_param_info("CONTROL_PARAM_2");
    if ($o_CONTROL_PARAM_2Info->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOW_BATTERY_ALARM");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CONTROL_PARAM_2Info->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOW_BATTERY_ALARM");
      }
	  }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
    if ($o_MODULATION_PARAMETERSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to POSITION_CONTROL_BANDWIDTH");
      }
      $ f_float = pack("N", unpack("V", pack("f", 4)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to POSITION_CONTROL_BANDWIDTH");
      }
	  }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
    if ($o_MODULATION_PARAMETERSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to SPEED_CONTROL_BANDWIDTH");
      }
      $ f_float = pack("N", unpack("V", pack("f", 5)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to SPEED_CONTROL_BANDWIDTH");
      }
	  }

    my $o_MODULATION_PARAMETERSInfo = $o_TBInfo->get_param_info("MODULATION_PARAMETERS");
    if ($o_MODULATION_PARAMETERSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to MODULATION_DELAY");
      }
      $ f_float = pack("N", unpack("V", pack("f", 5)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_MODULATION_PARAMETERSInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to MODULATION_DELAY");
      }
	  }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LOST_ANALOG_INPUT_ACTION");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LOST_ANALOG_INPUT_ACTION");
      }
	  }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOST_ANALOG_INPUT_1_ALARM");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOST_ANALOG_INPUT_1_ALARM");
      }
	  }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_LOST_ANALOG_INPUT_2_ALARM");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_LOST_ANALOG_INPUT_2_ALARM");
      }
	  }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_OUTPUT_1_SOURCE");
      }
      $i_integer = pack("C", 2);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_1_SOURCE");
      }
	  }

    my $o_ANALOG_PARAMSInfo = $o_TBInfo->get_param_info("ANALOG_PARAMS");
    if ($o_ANALOG_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ANALOG_OUTPUT_2_SOURCE");
      }
      $i_integer = pack("C", 2);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_PARAMSInfo->parameter_index, 6, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ANALOG_OUTPUT_2_SOURCE");
      }
	  }

    my $o_HOST_COMMAND_ESDInfo = $o_TBInfo->get_param_info("HOST_COMMAND_ESD");
    if ($o_HOST_COMMAND_ESDInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to HOST_COMMAND_ESD VALUE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_HOST_COMMAND_ESDInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to HOST_COMMAND_ESD VALUE");
      }
	  }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
    if ($o_LIMIT_SWITCH_TRIGGER_POINTSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LIMIT_SWITCH_A_TRIGGER_POINT");
      }
      $ f_float = pack("N", unpack("V", pack("f", 20)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LIMIT_SWITCH_A_TRIGGER_POINT");
      }
	  }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
    if ($o_LIMIT_SWITCH_TRIGGER_POINTSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LIMIT_SWITCH_B_TRIGGER_POINT");
      }
      $ f_float = pack("N", unpack("V", pack("f", 30)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LIMIT_SWITCH_B_TRIGGER_POINT");
      }
	  }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
    if ($o_LIMIT_SWITCH_TRIGGER_POINTSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LIMIT_SWITCH_OPEN_TRIGGER_POINT");
      }
      $ f_float = pack("N", unpack("V", pack("f", 40)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LIMIT_SWITCH_OPEN_TRIGGER_POINT");
      }
	  }

    my $o_LIMIT_SWITCH_TRIGGER_POINTSInfo = $o_TBInfo->get_param_info("LIMIT_SWITCH_TRIGGER_POINTS");
    if ($o_LIMIT_SWITCH_TRIGGER_POINTSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to LIMIT_SWITCH_CLOSE_TRIGGER_POINT");
      }
      $ f_float = pack("N", unpack("V", pack("f", 50)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_LIMIT_SWITCH_TRIGGER_POINTSInfo->parameter_index, 4, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to LIMIT_SWITCH_CLOSE_TRIGGER_POINT");
      }
	  }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
    if ($o_DISCRETE_INPUT_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUT_SETTINGS0");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUT_SETTINGS0");
      }
	  }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
    if ($o_DISCRETE_INPUT_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUT_SETTINGS1");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUT_SETTINGS1");
      }
	  }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
    if ($o_DISCRETE_INPUT_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUT_SETTINGS2");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUT_SETTINGS2");
      }
	  }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
    if ($o_DISCRETE_INPUT_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUT_SETTINGS3");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUT_SETTINGS3");
      }
	  }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
    if ($o_DISCRETE_INPUT_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUT_SETTINGS4");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUT_SETTINGS4");
      }
	  }

    my $o_DISCRETE_INPUT_SETTINGSInfo = $o_TBInfo->get_param_info("DISCRETE_INPUT_SETTINGS");
    if ($o_DISCRETE_INPUT_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 6);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to DISCRETE_INPUT_SETTINGS5");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DISCRETE_INPUT_SETTINGSInfo->parameter_index, 6, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to DISCRETE_INPUT_SETTINGS5");
      }
	  }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS0");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS0");
      }
	  }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS1");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS1");
      }
	  }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS2");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS2");
      }
	  }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS3");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS3");
      }
	  }

    my $o_RELAY_SETTINGSInfo = $o_TBInfo->get_param_info("RELAY_SETTINGS");
    if ($o_RELAY_SETTINGSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_SETTINGS4");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_SETTINGSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_SETTINGS4");
      }
	  }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS0");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS0");
      }
	  }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS1");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS1");
      }
	  }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS2");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 3, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS2");
      }
	  }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS3");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 4, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS3");
      }
	  }

    my $o_RELAY_FUNCTIONSInfo = $o_TBInfo->get_param_info("RELAY_FUNCTIONS");
    if ($o_RELAY_FUNCTIONSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_FUNCTIONS4");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_FUNCTIONSInfo->parameter_index, 5, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_FUNCTIONS4");
      }
	  }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_SPEED_CONTROL");
      }
	  }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to START_POSITION");
      }
      $ f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to START_POSITION");
      }
	  }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to STOP_POSITION");
      }
      $ f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to STOP_POSITION");
      }
	  }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ON_TIME");
      }
      $ f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ON_TIME");
      }
	  }

    my $o_OPEN_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("OPEN_SPEED_CONTROL");
    if ($o_OPEN_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to OFF_TIME");
      }
      $ f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_OPEN_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to OFF_TIME");
      }
	  }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_SPEED_CONTROL");
      }
	  }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to START_POSITION");
      }
      $ f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to START_POSITION");
      }
	  }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 3);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to STOP_POSITION");
      }
      $ f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 3, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to STOP_POSITION");
      }
	  }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ON_TIME");
      }
      $ f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ON_TIME");
      }
	  }

    my $o_CLOSE_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("CLOSE_SPEED_CONTROL");
    if ($o_CLOSE_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to OFF_TIME");
      }
      $ f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_CLOSE_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to OFF_TIME");
      }
	  }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
    if ($o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_SPEED_CONTROL");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_SPEED_CONTROL");
      }
	  }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
    if ($o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to START_POSITION");
      }
      $ f_float = pack("N", unpack("V", pack("f", 5)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to START_POSITION");
      }
	  }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
    if ($o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ON_TIME");
      }
      $ f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 4, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ON_TIME");
      }
	  }

    my $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo = $o_TBInfo->get_param_info("ANTI_WATER_HAMMER_SPEED_CONTROL");
    if ($o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to OFF_TIME");
      }
      $ f_float = pack("N", unpack("V", pack("f", 1)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANTI_WATER_HAMMER_SPEED_CONTROLInfo->parameter_index, 5, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to OFF_TIME");
      }
	  }

    my $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
    if ($o_ESD_ENABLES_AND_ACTIONInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ESD_ENABLES");
      }
      $i_integer = pack("n", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ESD_ENABLES");
      }
	  }

    my $o_ESD_ENABLES_AND_ACTIONInfo = $o_TBInfo->get_param_info("ESD_ENABLES_AND_ACTION");
    if ($o_ESD_ENABLES_AND_ACTIONInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ESD_ACTION");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ESD_ENABLES_AND_ACTIONInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ESD_ACTION");
      }
	  }

    my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
    if ($o_TORQUE_LIMITInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to CLOSE_TORQUE_LIMIT");
      }
      $ f_float = pack("N", unpack("V", pack("f", 50)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to CLOSE_TORQUE_LIMIT");
      }
	  }

    my $o_TORQUE_LIMITInfo = $o_TBInfo->get_param_info("TORQUE_LIMIT");
    if ($o_TORQUE_LIMITInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to OPEN_TORQUE_LIMIT");
      }
      $ f_float = pack("N", unpack("V", pack("f", 60)));
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_TORQUE_LIMITInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to OPEN_TORQUE_LIMIT");
      }
	  }

    my $o_BLUETOOTH_PARAMSInfo = $o_TBInfo->get_param_info("BLUETOOTH_PARAMS");
    if ($o_BLUETOOTH_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to ENABLE_BLUETOOTH_PARAMS");
      }
      $i_integer = pack("n", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index, 1, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to ENABLE_BLUETOOTH_PARAMS");
      }
	  }

    my $o_BLUETOOTH_PARAMSInfo = $o_TBInfo->get_param_info("BLUETOOTH_PARAMS");
    if ($o_BLUETOOTH_PARAMSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to BLUETOOTH_NAME");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_BLUETOOTH_PARAMSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to BLUETOOTH_NAME");
      }
	  }

      my $o_ACTUATOR_COMMANDInfo = $o_TBInfo->get_param_info("ACTUATOR_COMMAND");
    if ($o_ACTUATOR_COMMANDInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toACTUATOR_COMMAND VALUE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ACTUATOR_COMMANDInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toACTUATOR_COMMAND VALUE");
      }
	  }

      my $o_DEFAULT_SETPOINTInfo = $o_TBInfo->get_param_info("DEFAULT_SETPOINT");
    if ($o_DEFAULT_SETPOINTInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toDEFAULT_SETPOINT_1");
      }
      $f_float = pack("N", unpack("V", pack("f",  50)));
  $rh_Result =    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_DEFAULT_SETPOINTInfo->parameter_index, 1, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toDEFAULT_SETPOINT_1");
      }
	  }

      my $o_SETPOINTInfo = $o_TBInfo->get_param_info("SETPOINT");
    if ($o_SETPOINTInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toSETPOINT VALUE");
      }
      $f_float = pack("N", unpack("V", pack("f",  100)));
  $rh_Result =    ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_SETPOINTInfo->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toSETPOINT VALUE");
      }
	  }

      my $o_RELAY_1_STATUSInfo = $o_TBInfo->get_param_info("RELAY_1_STATUS");
    if ($o_RELAY_1_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_1_STATUS VALUE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_1_STATUSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_1_STATUS VALUE");
      }
	  }

      my $o_RELAY_2_STATUSInfo = $o_TBInfo->get_param_info("RELAY_2_STATUS");
    if ($o_RELAY_2_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_2_STATUS VALUE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_2_STATUSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_2_STATUS VALUE");
      }
	  }

      my $o_RELAY_3_STATUSInfo = $o_TBInfo->get_param_info("RELAY_3_STATUS");
    if ($o_RELAY_3_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_3_STATUS VALUE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_3_STATUSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_3_STATUS VALUE");
      }
	  }

      my $o_RELAY_4_STATUSInfo = $o_TBInfo->get_param_info("RELAY_4_STATUS");
    if ($o_RELAY_4_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_4_STATUS VALUE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_4_STATUSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_4_STATUS VALUE");
      }
	  }

      my $o_RELAY_5_STATUSInfo = $o_TBInfo->get_param_info("RELAY_5_STATUS");
    if ($o_RELAY_5_STATUSInfo->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read to RELAY_5_STATUS VALUE");
      }
      $i_integer = pack("C", 1);
 $rh_Result =     ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_RELAY_5_STATUSInfo->parameter_index, 2, length($i_integer) ,$i_integer);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write to RELAY_5_STATUS VALUE");
      }
	  }

      my $o_ANALOG_OUTPUT_1Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_1");
    if ($o_ANALOG_OUTPUT_1Info->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toANALOG_OUTPUT_1 VALUE");
      }
      $f_float = pack("N", unpack("V", pack("f",  100)));
$rh_Result =      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_1Info->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toANALOG_OUTPUT_1 VALUE");
      }
	  }

      my $o_ANALOG_OUTPUT_2Info = $o_TBInfo->get_param_info("ANALOG_OUTPUT_2");
    if ($o_ANALOG_OUTPUT_2Info->mode_for_write =~ $i_allow_mode_string[$i])
    {		  
      $rh_Result = ff_tools::hostapi::api::Read($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_2Info->parameter_index, 2);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::read_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for read toANALOG_OUTPUT_2 VALUE");
      }
      $f_float = pack("N", unpack("V", pack("f",  100)));
$rh_Result =      ff_tools::hostapi::api::Write($i_DutFbapVcrId, $i_TBBlkIndex + $o_ANALOG_OUTPUT_2Info->parameter_index, 2, length($f_float) ,$f_float);
      if (!($rh_Result->{"Confirm"}->isa('ff_tools::hostapi::write_cnf_pos')))
      {
        print("\n-> Test FAILED :Expected confirm positive for write toANALOG_OUTPUT_2 VALUE");
      }
	  }
}
}


sub Teardown()
{
  Log("Teardown ADVT test script....");
}